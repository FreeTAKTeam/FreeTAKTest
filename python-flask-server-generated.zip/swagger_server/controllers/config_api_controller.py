import connexion
import six

from swagger_server.models.configuration import Configuration  # noqa: E501
from swagger_server.models.input import Input  # noqa: E501
from swagger_server import util


def get_cached_core_config():  # noqa: E501
    """get_cached_core_config

     # noqa: E501


    :rtype: Configuration
    """
    return 'do some magic!'


def get_cached_input_config():  # noqa: E501
    """get_cached_input_config

     # noqa: E501


    :rtype: List[Input]
    """
    return 'do some magic!'


def get_core_config():  # noqa: E501
    """get_core_config

     # noqa: E501


    :rtype: Configuration
    """
    return 'do some magic!'
