import connexion
import six

from swagger_server.models.api_response_server_config import ApiResponseServerConfig  # noqa: E501
from swagger_server.models.version_info import VersionInfo  # noqa: E501
from swagger_server import util


def get_node_id():  # noqa: E501
    """get_node_id

     # noqa: E501


    :rtype: str
    """
    return 'do some magic!'


def get_version():  # noqa: E501
    """get_version

     # noqa: E501


    :rtype: str
    """
    return 'do some magic!'


def get_version_config():  # noqa: E501
    """get_version_config

     # noqa: E501


    :rtype: ApiResponseServerConfig
    """
    return 'do some magic!'


def get_version_info():  # noqa: E501
    """get_version_info

     # noqa: E501


    :rtype: VersionInfo
    """
    return 'do some magic!'
