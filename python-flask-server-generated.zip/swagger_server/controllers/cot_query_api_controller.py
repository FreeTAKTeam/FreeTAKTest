import connexion
import six

from swagger_server.models.api_response_list_cot_search import ApiResponseListCotSearch  # noqa: E501
from swagger_server import util


def get_all_searches():  # noqa: E501
    """get_all_searches

     # noqa: E501


    :rtype: ApiResponseListCotSearch
    """
    return 'do some magic!'


def get_date():  # noqa: E501
    """get_date

     # noqa: E501


    :rtype: datetime
    """
    return 'do some magic!'


def get_search(id):  # noqa: E501
    """get_search

     # noqa: E501

    :param id: 
    :type id: str

    :rtype: ApiResponseListCotSearch
    """
    return 'do some magic!'
