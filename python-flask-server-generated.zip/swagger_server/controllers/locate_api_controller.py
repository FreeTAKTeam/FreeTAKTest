import connexion
import six

from swagger_server import util


def locate(latitude, longitude, name, remarks):  # noqa: E501
    """locate

     # noqa: E501

    :param latitude: 
    :type latitude: float
    :param longitude: 
    :type longitude: float
    :param name: 
    :type name: str
    :param remarks: 
    :type remarks: str

    :rtype: None
    """
    return 'do some magic!'
