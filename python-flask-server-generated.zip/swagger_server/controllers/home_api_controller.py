import connexion
import six

from swagger_server import util


def get_home():  # noqa: E501
    """get_home

     # noqa: E501


    :rtype: str
    """
    return 'do some magic!'


def get_user_roles():  # noqa: E501
    """get_user_roles

     # noqa: E501


    :rtype: List[str]
    """
    return 'do some magic!'


def get_ver():  # noqa: E501
    """get_ver

     # noqa: E501


    :rtype: str
    """
    return 'do some magic!'


def is_admin():  # noqa: E501
    """is_admin

     # noqa: E501


    :rtype: bool
    """
    return 'do some magic!'
