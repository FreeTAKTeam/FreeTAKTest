import connexion
import six

from swagger_server import util


def get_next_in_sequence(key):  # noqa: E501
    """get_next_in_sequence

     # noqa: E501

    :param key: 
    :type key: str

    :rtype: str
    """
    return 'do some magic!'
