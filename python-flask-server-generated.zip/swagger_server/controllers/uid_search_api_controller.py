import connexion
import six

from swagger_server.models.api_response_list_uid_result import ApiResponseListUIDResult  # noqa: E501
from swagger_server import util


def get_uid_results(start_date, end_date):  # noqa: E501
    """get_uid_results

     # noqa: E501

    :param start_date: 
    :type start_date: str
    :param end_date: 
    :type end_date: str

    :rtype: ApiResponseListUIDResult
    """
    return 'do some magic!'
