package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.InputMetric;
import java.util.List;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class ApiResponseSortedSetInputMetric   {
  private String version = null;  private String type = null;  private List<InputMetric> data = new ArrayList<InputMetric>();  private List<String> messages = new ArrayList<String>();  private String nodeId = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("version")
  public String getVersion() {
    return version;
  }
  public void setVersion(String version) {
    this.version = version;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("type")
  public String getType() {
    return type;
  }
  public void setType(String type) {
    this.type = type;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("data")
  public List<InputMetric> getData() {
    return data;
  }
  public void setData(List<InputMetric> data) {
    this.data = data;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("messages")
  public List<String> getMessages() {
    return messages;
  }
  public void setMessages(List<String> messages) {
    this.messages = messages;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("nodeId")
  public String getNodeId() {
    return nodeId;
  }
  public void setNodeId(String nodeId) {
    this.nodeId = nodeId;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ApiResponseSortedSetInputMetric apiResponseSortedSetInputMetric = (ApiResponseSortedSetInputMetric) o;
    return Objects.equals(version, apiResponseSortedSetInputMetric.version) &&
        Objects.equals(type, apiResponseSortedSetInputMetric.type) &&
        Objects.equals(data, apiResponseSortedSetInputMetric.data) &&
        Objects.equals(messages, apiResponseSortedSetInputMetric.messages) &&
        Objects.equals(nodeId, apiResponseSortedSetInputMetric.nodeId);
  }

  @Override
  public int hashCode() {
    return Objects.hash(version, type, data, messages, nodeId);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ApiResponseSortedSetInputMetric {\n");
    
    sb.append("    version: ").append(toIndentedString(version)).append("\n");
    sb.append("    type: ").append(toIndentedString(type)).append("\n");
    sb.append("    data: ").append(toIndentedString(data)).append("\n");
    sb.append("    messages: ").append(toIndentedString(messages)).append("\n");
    sb.append("    nodeId: ").append(toIndentedString(nodeId)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
