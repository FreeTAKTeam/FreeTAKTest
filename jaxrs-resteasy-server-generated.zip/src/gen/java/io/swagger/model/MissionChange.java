package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import io.swagger.model.ExternalMissionData;
import io.swagger.model.LogEntry;
import io.swagger.model.MapLayer;
import io.swagger.model.MissionFeed;
import io.swagger.model.Resource;
import io.swagger.model.UidDetails;
import java.util.Date;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class MissionChange   {
  /**
   * Gets or Sets type
   */
  public enum TypeEnum {
    CREATE_MISSION("CREATE_MISSION"),
    DELETE_MISSION("DELETE_MISSION"),
    ADD_CONTENT("ADD_CONTENT"),
    REMOVE_CONTENT("REMOVE_CONTENT"),
    CREATE_DATA_FEED("CREATE_DATA_FEED"),
    DELETE_DATA_FEED("DELETE_DATA_FEED");
    private String value;

    TypeEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }
  }
  private TypeEnum type = null;  private String contentUid = null;  private String missionName = null;  private Date timestamp = null;  private String creatorUid = null;  private Date serverTime = null;  private UidDetails details = null;  private ExternalMissionData externalData = null;  private LogEntry logEntry = null;  private MapLayer mapLayer = null;  private MissionFeed missionFeed = null;  private Resource contentResource = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("type")
  public TypeEnum getType() {
    return type;
  }
  public void setType(TypeEnum type) {
    this.type = type;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("contentUid")
  public String getContentUid() {
    return contentUid;
  }
  public void setContentUid(String contentUid) {
    this.contentUid = contentUid;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("missionName")
  public String getMissionName() {
    return missionName;
  }
  public void setMissionName(String missionName) {
    this.missionName = missionName;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("timestamp")
  public Date getTimestamp() {
    return timestamp;
  }
  public void setTimestamp(Date timestamp) {
    this.timestamp = timestamp;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("creatorUid")
  public String getCreatorUid() {
    return creatorUid;
  }
  public void setCreatorUid(String creatorUid) {
    this.creatorUid = creatorUid;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("serverTime")
  public Date getServerTime() {
    return serverTime;
  }
  public void setServerTime(Date serverTime) {
    this.serverTime = serverTime;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("details")
  public UidDetails getDetails() {
    return details;
  }
  public void setDetails(UidDetails details) {
    this.details = details;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("externalData")
  public ExternalMissionData getExternalData() {
    return externalData;
  }
  public void setExternalData(ExternalMissionData externalData) {
    this.externalData = externalData;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("logEntry")
  public LogEntry getLogEntry() {
    return logEntry;
  }
  public void setLogEntry(LogEntry logEntry) {
    this.logEntry = logEntry;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("mapLayer")
  public MapLayer getMapLayer() {
    return mapLayer;
  }
  public void setMapLayer(MapLayer mapLayer) {
    this.mapLayer = mapLayer;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("missionFeed")
  public MissionFeed getMissionFeed() {
    return missionFeed;
  }
  public void setMissionFeed(MissionFeed missionFeed) {
    this.missionFeed = missionFeed;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("contentResource")
  public Resource getContentResource() {
    return contentResource;
  }
  public void setContentResource(Resource contentResource) {
    this.contentResource = contentResource;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    MissionChange missionChange = (MissionChange) o;
    return Objects.equals(type, missionChange.type) &&
        Objects.equals(contentUid, missionChange.contentUid) &&
        Objects.equals(missionName, missionChange.missionName) &&
        Objects.equals(timestamp, missionChange.timestamp) &&
        Objects.equals(creatorUid, missionChange.creatorUid) &&
        Objects.equals(serverTime, missionChange.serverTime) &&
        Objects.equals(details, missionChange.details) &&
        Objects.equals(externalData, missionChange.externalData) &&
        Objects.equals(logEntry, missionChange.logEntry) &&
        Objects.equals(mapLayer, missionChange.mapLayer) &&
        Objects.equals(missionFeed, missionChange.missionFeed) &&
        Objects.equals(contentResource, missionChange.contentResource);
  }

  @Override
  public int hashCode() {
    return Objects.hash(type, contentUid, missionName, timestamp, creatorUid, serverTime, details, externalData, logEntry, mapLayer, missionFeed, contentResource);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class MissionChange {\n");
    
    sb.append("    type: ").append(toIndentedString(type)).append("\n");
    sb.append("    contentUid: ").append(toIndentedString(contentUid)).append("\n");
    sb.append("    missionName: ").append(toIndentedString(missionName)).append("\n");
    sb.append("    timestamp: ").append(toIndentedString(timestamp)).append("\n");
    sb.append("    creatorUid: ").append(toIndentedString(creatorUid)).append("\n");
    sb.append("    serverTime: ").append(toIndentedString(serverTime)).append("\n");
    sb.append("    details: ").append(toIndentedString(details)).append("\n");
    sb.append("    externalData: ").append(toIndentedString(externalData)).append("\n");
    sb.append("    logEntry: ").append(toIndentedString(logEntry)).append("\n");
    sb.append("    mapLayer: ").append(toIndentedString(mapLayer)).append("\n");
    sb.append("    missionFeed: ").append(toIndentedString(missionFeed)).append("\n");
    sb.append("    contentResource: ").append(toIndentedString(contentResource)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
