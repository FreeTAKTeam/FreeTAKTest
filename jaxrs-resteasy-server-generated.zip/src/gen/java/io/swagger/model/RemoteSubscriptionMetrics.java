package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class RemoteSubscriptionMetrics   {
  private String appFramerate = null;  private String battery = null;  private String batteryStatus = null;  private String batteryTemp = null;  private String deviceDataRx = null;  private String deviceDataTx = null;  private String heapCurrentSize = null;  private String heapFreeSize = null;  private String heapMaxSize = null;  private String ipAddress = null;  private String storageAvailable = null;  private String storageTotal = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("appFramerate")
  public String getAppFramerate() {
    return appFramerate;
  }
  public void setAppFramerate(String appFramerate) {
    this.appFramerate = appFramerate;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("battery")
  public String getBattery() {
    return battery;
  }
  public void setBattery(String battery) {
    this.battery = battery;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("batteryStatus")
  public String getBatteryStatus() {
    return batteryStatus;
  }
  public void setBatteryStatus(String batteryStatus) {
    this.batteryStatus = batteryStatus;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("batteryTemp")
  public String getBatteryTemp() {
    return batteryTemp;
  }
  public void setBatteryTemp(String batteryTemp) {
    this.batteryTemp = batteryTemp;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("deviceDataRx")
  public String getDeviceDataRx() {
    return deviceDataRx;
  }
  public void setDeviceDataRx(String deviceDataRx) {
    this.deviceDataRx = deviceDataRx;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("deviceDataTx")
  public String getDeviceDataTx() {
    return deviceDataTx;
  }
  public void setDeviceDataTx(String deviceDataTx) {
    this.deviceDataTx = deviceDataTx;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("heapCurrentSize")
  public String getHeapCurrentSize() {
    return heapCurrentSize;
  }
  public void setHeapCurrentSize(String heapCurrentSize) {
    this.heapCurrentSize = heapCurrentSize;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("heapFreeSize")
  public String getHeapFreeSize() {
    return heapFreeSize;
  }
  public void setHeapFreeSize(String heapFreeSize) {
    this.heapFreeSize = heapFreeSize;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("heapMaxSize")
  public String getHeapMaxSize() {
    return heapMaxSize;
  }
  public void setHeapMaxSize(String heapMaxSize) {
    this.heapMaxSize = heapMaxSize;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("ipAddress")
  public String getIpAddress() {
    return ipAddress;
  }
  public void setIpAddress(String ipAddress) {
    this.ipAddress = ipAddress;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("storageAvailable")
  public String getStorageAvailable() {
    return storageAvailable;
  }
  public void setStorageAvailable(String storageAvailable) {
    this.storageAvailable = storageAvailable;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("storageTotal")
  public String getStorageTotal() {
    return storageTotal;
  }
  public void setStorageTotal(String storageTotal) {
    this.storageTotal = storageTotal;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    RemoteSubscriptionMetrics remoteSubscriptionMetrics = (RemoteSubscriptionMetrics) o;
    return Objects.equals(appFramerate, remoteSubscriptionMetrics.appFramerate) &&
        Objects.equals(battery, remoteSubscriptionMetrics.battery) &&
        Objects.equals(batteryStatus, remoteSubscriptionMetrics.batteryStatus) &&
        Objects.equals(batteryTemp, remoteSubscriptionMetrics.batteryTemp) &&
        Objects.equals(deviceDataRx, remoteSubscriptionMetrics.deviceDataRx) &&
        Objects.equals(deviceDataTx, remoteSubscriptionMetrics.deviceDataTx) &&
        Objects.equals(heapCurrentSize, remoteSubscriptionMetrics.heapCurrentSize) &&
        Objects.equals(heapFreeSize, remoteSubscriptionMetrics.heapFreeSize) &&
        Objects.equals(heapMaxSize, remoteSubscriptionMetrics.heapMaxSize) &&
        Objects.equals(ipAddress, remoteSubscriptionMetrics.ipAddress) &&
        Objects.equals(storageAvailable, remoteSubscriptionMetrics.storageAvailable) &&
        Objects.equals(storageTotal, remoteSubscriptionMetrics.storageTotal);
  }

  @Override
  public int hashCode() {
    return Objects.hash(appFramerate, battery, batteryStatus, batteryTemp, deviceDataRx, deviceDataTx, heapCurrentSize, heapFreeSize, heapMaxSize, ipAddress, storageAvailable, storageTotal);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class RemoteSubscriptionMetrics {\n");
    
    sb.append("    appFramerate: ").append(toIndentedString(appFramerate)).append("\n");
    sb.append("    battery: ").append(toIndentedString(battery)).append("\n");
    sb.append("    batteryStatus: ").append(toIndentedString(batteryStatus)).append("\n");
    sb.append("    batteryTemp: ").append(toIndentedString(batteryTemp)).append("\n");
    sb.append("    deviceDataRx: ").append(toIndentedString(deviceDataRx)).append("\n");
    sb.append("    deviceDataTx: ").append(toIndentedString(deviceDataTx)).append("\n");
    sb.append("    heapCurrentSize: ").append(toIndentedString(heapCurrentSize)).append("\n");
    sb.append("    heapFreeSize: ").append(toIndentedString(heapFreeSize)).append("\n");
    sb.append("    heapMaxSize: ").append(toIndentedString(heapMaxSize)).append("\n");
    sb.append("    ipAddress: ").append(toIndentedString(ipAddress)).append("\n");
    sb.append("    storageAvailable: ").append(toIndentedString(storageAvailable)).append("\n");
    sb.append("    storageTotal: ").append(toIndentedString(storageTotal)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
