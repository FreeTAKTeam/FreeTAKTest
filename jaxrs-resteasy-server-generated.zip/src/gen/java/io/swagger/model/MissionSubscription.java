package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.Mission;
import io.swagger.model.MissionRole;
import java.util.Date;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class MissionSubscription   {
  private String token = null;  private Mission mission = null;  private String clientUid = null;  private String username = null;  private Date createTime = null;  private MissionRole role = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("token")
  public String getToken() {
    return token;
  }
  public void setToken(String token) {
    this.token = token;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("mission")
  public Mission getMission() {
    return mission;
  }
  public void setMission(Mission mission) {
    this.mission = mission;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("clientUid")
  public String getClientUid() {
    return clientUid;
  }
  public void setClientUid(String clientUid) {
    this.clientUid = clientUid;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("username")
  public String getUsername() {
    return username;
  }
  public void setUsername(String username) {
    this.username = username;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("createTime")
  public Date getCreateTime() {
    return createTime;
  }
  public void setCreateTime(Date createTime) {
    this.createTime = createTime;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("role")
  public MissionRole getRole() {
    return role;
  }
  public void setRole(MissionRole role) {
    this.role = role;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    MissionSubscription missionSubscription = (MissionSubscription) o;
    return Objects.equals(token, missionSubscription.token) &&
        Objects.equals(mission, missionSubscription.mission) &&
        Objects.equals(clientUid, missionSubscription.clientUid) &&
        Objects.equals(username, missionSubscription.username) &&
        Objects.equals(createTime, missionSubscription.createTime) &&
        Objects.equals(role, missionSubscription.role);
  }

  @Override
  public int hashCode() {
    return Objects.hash(token, mission, clientUid, username, createTime, role);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class MissionSubscription {\n");
    
    sb.append("    token: ").append(toIndentedString(token)).append("\n");
    sb.append("    mission: ").append(toIndentedString(mission)).append("\n");
    sb.append("    clientUid: ").append(toIndentedString(clientUid)).append("\n");
    sb.append("    username: ").append(toIndentedString(username)).append("\n");
    sb.append("    createTime: ").append(toIndentedString(createTime)).append("\n");
    sb.append("    role: ").append(toIndentedString(role)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
