package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class RemoteContact   {
  private String contactName = null;  private Long lastHeardFromMillis = null;  private String endpoint = null;  private String uid = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("contactName")
  public String getContactName() {
    return contactName;
  }
  public void setContactName(String contactName) {
    this.contactName = contactName;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("lastHeardFromMillis")
  public Long getLastHeardFromMillis() {
    return lastHeardFromMillis;
  }
  public void setLastHeardFromMillis(Long lastHeardFromMillis) {
    this.lastHeardFromMillis = lastHeardFromMillis;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("endpoint")
  public String getEndpoint() {
    return endpoint;
  }
  public void setEndpoint(String endpoint) {
    this.endpoint = endpoint;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("uid")
  public String getUid() {
    return uid;
  }
  public void setUid(String uid) {
    this.uid = uid;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    RemoteContact remoteContact = (RemoteContact) o;
    return Objects.equals(contactName, remoteContact.contactName) &&
        Objects.equals(lastHeardFromMillis, remoteContact.lastHeardFromMillis) &&
        Objects.equals(endpoint, remoteContact.endpoint) &&
        Objects.equals(uid, remoteContact.uid);
  }

  @Override
  public int hashCode() {
    return Objects.hash(contactName, lastHeardFromMillis, endpoint, uid);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class RemoteContact {\n");
    
    sb.append("    contactName: ").append(toIndentedString(contactName)).append("\n");
    sb.append("    lastHeardFromMillis: ").append(toIndentedString(lastHeardFromMillis)).append("\n");
    sb.append("    endpoint: ").append(toIndentedString(endpoint)).append("\n");
    sb.append("    uid: ").append(toIndentedString(uid)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
