package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import java.util.Date;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class TakCert   {
  private Long id = null;  private String creatorDn = null;  private String subjectDn = null;  private String userDn = null;  private String certificate = null;  private String hash = null;  private String clientUid = null;  private Date issuanceDate = null;  private Date expirationDate = null;  private Date effectiveDate = null;  private Date revocationDate = null;  private String token = null;  private String serialNumber = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("id")
  public Long getId() {
    return id;
  }
  public void setId(Long id) {
    this.id = id;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("creatorDn")
  public String getCreatorDn() {
    return creatorDn;
  }
  public void setCreatorDn(String creatorDn) {
    this.creatorDn = creatorDn;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("subjectDn")
  public String getSubjectDn() {
    return subjectDn;
  }
  public void setSubjectDn(String subjectDn) {
    this.subjectDn = subjectDn;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("userDn")
  public String getUserDn() {
    return userDn;
  }
  public void setUserDn(String userDn) {
    this.userDn = userDn;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("certificate")
  public String getCertificate() {
    return certificate;
  }
  public void setCertificate(String certificate) {
    this.certificate = certificate;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("hash")
  public String getHash() {
    return hash;
  }
  public void setHash(String hash) {
    this.hash = hash;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("clientUid")
  public String getClientUid() {
    return clientUid;
  }
  public void setClientUid(String clientUid) {
    this.clientUid = clientUid;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("issuanceDate")
  public Date getIssuanceDate() {
    return issuanceDate;
  }
  public void setIssuanceDate(Date issuanceDate) {
    this.issuanceDate = issuanceDate;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("expirationDate")
  public Date getExpirationDate() {
    return expirationDate;
  }
  public void setExpirationDate(Date expirationDate) {
    this.expirationDate = expirationDate;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("effectiveDate")
  public Date getEffectiveDate() {
    return effectiveDate;
  }
  public void setEffectiveDate(Date effectiveDate) {
    this.effectiveDate = effectiveDate;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("revocationDate")
  public Date getRevocationDate() {
    return revocationDate;
  }
  public void setRevocationDate(Date revocationDate) {
    this.revocationDate = revocationDate;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("token")
  public String getToken() {
    return token;
  }
  public void setToken(String token) {
    this.token = token;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("serialNumber")
  public String getSerialNumber() {
    return serialNumber;
  }
  public void setSerialNumber(String serialNumber) {
    this.serialNumber = serialNumber;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    TakCert takCert = (TakCert) o;
    return Objects.equals(id, takCert.id) &&
        Objects.equals(creatorDn, takCert.creatorDn) &&
        Objects.equals(subjectDn, takCert.subjectDn) &&
        Objects.equals(userDn, takCert.userDn) &&
        Objects.equals(certificate, takCert.certificate) &&
        Objects.equals(hash, takCert.hash) &&
        Objects.equals(clientUid, takCert.clientUid) &&
        Objects.equals(issuanceDate, takCert.issuanceDate) &&
        Objects.equals(expirationDate, takCert.expirationDate) &&
        Objects.equals(effectiveDate, takCert.effectiveDate) &&
        Objects.equals(revocationDate, takCert.revocationDate) &&
        Objects.equals(token, takCert.token) &&
        Objects.equals(serialNumber, takCert.serialNumber);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, creatorDn, subjectDn, userDn, certificate, hash, clientUid, issuanceDate, expirationDate, effectiveDate, revocationDate, token, serialNumber);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class TakCert {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    creatorDn: ").append(toIndentedString(creatorDn)).append("\n");
    sb.append("    subjectDn: ").append(toIndentedString(subjectDn)).append("\n");
    sb.append("    userDn: ").append(toIndentedString(userDn)).append("\n");
    sb.append("    certificate: ").append(toIndentedString(certificate)).append("\n");
    sb.append("    hash: ").append(toIndentedString(hash)).append("\n");
    sb.append("    clientUid: ").append(toIndentedString(clientUid)).append("\n");
    sb.append("    issuanceDate: ").append(toIndentedString(issuanceDate)).append("\n");
    sb.append("    expirationDate: ").append(toIndentedString(expirationDate)).append("\n");
    sb.append("    effectiveDate: ").append(toIndentedString(effectiveDate)).append("\n");
    sb.append("    revocationDate: ").append(toIndentedString(revocationDate)).append("\n");
    sb.append("    token: ").append(toIndentedString(token)).append("\n");
    sb.append("    serialNumber: ").append(toIndentedString(serialNumber)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
