package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class TAKServerCAConfig   {
  private String keystore = null;  private String keystoreFile = null;  private String keystorePass = null;  private Integer validityDays = null;  private Integer validityNotBeforeOffsetMinutes = null;  private String signatureAlg = null;  private String cakey = null;  private String cacertificate = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("keystore")
  public String getKeystore() {
    return keystore;
  }
  public void setKeystore(String keystore) {
    this.keystore = keystore;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("keystoreFile")
  public String getKeystoreFile() {
    return keystoreFile;
  }
  public void setKeystoreFile(String keystoreFile) {
    this.keystoreFile = keystoreFile;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("keystorePass")
  public String getKeystorePass() {
    return keystorePass;
  }
  public void setKeystorePass(String keystorePass) {
    this.keystorePass = keystorePass;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("validityDays")
  public Integer getValidityDays() {
    return validityDays;
  }
  public void setValidityDays(Integer validityDays) {
    this.validityDays = validityDays;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("validityNotBeforeOffsetMinutes")
  public Integer getValidityNotBeforeOffsetMinutes() {
    return validityNotBeforeOffsetMinutes;
  }
  public void setValidityNotBeforeOffsetMinutes(Integer validityNotBeforeOffsetMinutes) {
    this.validityNotBeforeOffsetMinutes = validityNotBeforeOffsetMinutes;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("signatureAlg")
  public String getSignatureAlg() {
    return signatureAlg;
  }
  public void setSignatureAlg(String signatureAlg) {
    this.signatureAlg = signatureAlg;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("cakey")
  public String getCakey() {
    return cakey;
  }
  public void setCakey(String cakey) {
    this.cakey = cakey;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("cacertificate")
  public String getCacertificate() {
    return cacertificate;
  }
  public void setCacertificate(String cacertificate) {
    this.cacertificate = cacertificate;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    TAKServerCAConfig taKServerCAConfig = (TAKServerCAConfig) o;
    return Objects.equals(keystore, taKServerCAConfig.keystore) &&
        Objects.equals(keystoreFile, taKServerCAConfig.keystoreFile) &&
        Objects.equals(keystorePass, taKServerCAConfig.keystorePass) &&
        Objects.equals(validityDays, taKServerCAConfig.validityDays) &&
        Objects.equals(validityNotBeforeOffsetMinutes, taKServerCAConfig.validityNotBeforeOffsetMinutes) &&
        Objects.equals(signatureAlg, taKServerCAConfig.signatureAlg) &&
        Objects.equals(cakey, taKServerCAConfig.cakey) &&
        Objects.equals(cacertificate, taKServerCAConfig.cacertificate);
  }

  @Override
  public int hashCode() {
    return Objects.hash(keystore, keystoreFile, keystorePass, validityDays, validityNotBeforeOffsetMinutes, signatureAlg, cakey, cacertificate);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class TAKServerCAConfig {\n");
    
    sb.append("    keystore: ").append(toIndentedString(keystore)).append("\n");
    sb.append("    keystoreFile: ").append(toIndentedString(keystoreFile)).append("\n");
    sb.append("    keystorePass: ").append(toIndentedString(keystorePass)).append("\n");
    sb.append("    validityDays: ").append(toIndentedString(validityDays)).append("\n");
    sb.append("    validityNotBeforeOffsetMinutes: ").append(toIndentedString(validityNotBeforeOffsetMinutes)).append("\n");
    sb.append("    signatureAlg: ").append(toIndentedString(signatureAlg)).append("\n");
    sb.append("    cakey: ").append(toIndentedString(cakey)).append("\n");
    sb.append("    cacertificate: ").append(toIndentedString(cacertificate)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
