package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class FeedV2   {
  private String uuid = null;  private Boolean active = null;  private String alias = null;  private String url = null;  private Integer order = null;  private String macAddress = null;  private String roverPort = null;  private String ignoreEmbeddedKLV = null;  private String source = null;  private String networkTimeout = null;  private String bufferTime = null;  private String rtspReliable = null;  private String thumbnail = null;  private String classification = null;  private String latitude = null;  private String longitude = null;  private String fov = null;  private String heading = null;  private String range = null;  private Integer width = null;  private Integer height = null;  private Integer bitrate = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("uuid")
  public String getUuid() {
    return uuid;
  }
  public void setUuid(String uuid) {
    this.uuid = uuid;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("active")
  public Boolean isActive() {
    return active;
  }
  public void setActive(Boolean active) {
    this.active = active;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("alias")
  public String getAlias() {
    return alias;
  }
  public void setAlias(String alias) {
    this.alias = alias;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("url")
  public String getUrl() {
    return url;
  }
  public void setUrl(String url) {
    this.url = url;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("order")
  public Integer getOrder() {
    return order;
  }
  public void setOrder(Integer order) {
    this.order = order;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("macAddress")
  public String getMacAddress() {
    return macAddress;
  }
  public void setMacAddress(String macAddress) {
    this.macAddress = macAddress;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("roverPort")
  public String getRoverPort() {
    return roverPort;
  }
  public void setRoverPort(String roverPort) {
    this.roverPort = roverPort;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("ignoreEmbeddedKLV")
  public String getIgnoreEmbeddedKLV() {
    return ignoreEmbeddedKLV;
  }
  public void setIgnoreEmbeddedKLV(String ignoreEmbeddedKLV) {
    this.ignoreEmbeddedKLV = ignoreEmbeddedKLV;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("source")
  public String getSource() {
    return source;
  }
  public void setSource(String source) {
    this.source = source;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("networkTimeout")
  public String getNetworkTimeout() {
    return networkTimeout;
  }
  public void setNetworkTimeout(String networkTimeout) {
    this.networkTimeout = networkTimeout;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("bufferTime")
  public String getBufferTime() {
    return bufferTime;
  }
  public void setBufferTime(String bufferTime) {
    this.bufferTime = bufferTime;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("rtspReliable")
  public String getRtspReliable() {
    return rtspReliable;
  }
  public void setRtspReliable(String rtspReliable) {
    this.rtspReliable = rtspReliable;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("thumbnail")
  public String getThumbnail() {
    return thumbnail;
  }
  public void setThumbnail(String thumbnail) {
    this.thumbnail = thumbnail;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("classification")
  public String getClassification() {
    return classification;
  }
  public void setClassification(String classification) {
    this.classification = classification;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("latitude")
  public String getLatitude() {
    return latitude;
  }
  public void setLatitude(String latitude) {
    this.latitude = latitude;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("longitude")
  public String getLongitude() {
    return longitude;
  }
  public void setLongitude(String longitude) {
    this.longitude = longitude;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("fov")
  public String getFov() {
    return fov;
  }
  public void setFov(String fov) {
    this.fov = fov;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("heading")
  public String getHeading() {
    return heading;
  }
  public void setHeading(String heading) {
    this.heading = heading;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("range")
  public String getRange() {
    return range;
  }
  public void setRange(String range) {
    this.range = range;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("width")
  public Integer getWidth() {
    return width;
  }
  public void setWidth(Integer width) {
    this.width = width;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("height")
  public Integer getHeight() {
    return height;
  }
  public void setHeight(Integer height) {
    this.height = height;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("bitrate")
  public Integer getBitrate() {
    return bitrate;
  }
  public void setBitrate(Integer bitrate) {
    this.bitrate = bitrate;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    FeedV2 feedV2 = (FeedV2) o;
    return Objects.equals(uuid, feedV2.uuid) &&
        Objects.equals(active, feedV2.active) &&
        Objects.equals(alias, feedV2.alias) &&
        Objects.equals(url, feedV2.url) &&
        Objects.equals(order, feedV2.order) &&
        Objects.equals(macAddress, feedV2.macAddress) &&
        Objects.equals(roverPort, feedV2.roverPort) &&
        Objects.equals(ignoreEmbeddedKLV, feedV2.ignoreEmbeddedKLV) &&
        Objects.equals(source, feedV2.source) &&
        Objects.equals(networkTimeout, feedV2.networkTimeout) &&
        Objects.equals(bufferTime, feedV2.bufferTime) &&
        Objects.equals(rtspReliable, feedV2.rtspReliable) &&
        Objects.equals(thumbnail, feedV2.thumbnail) &&
        Objects.equals(classification, feedV2.classification) &&
        Objects.equals(latitude, feedV2.latitude) &&
        Objects.equals(longitude, feedV2.longitude) &&
        Objects.equals(fov, feedV2.fov) &&
        Objects.equals(heading, feedV2.heading) &&
        Objects.equals(range, feedV2.range) &&
        Objects.equals(width, feedV2.width) &&
        Objects.equals(height, feedV2.height) &&
        Objects.equals(bitrate, feedV2.bitrate);
  }

  @Override
  public int hashCode() {
    return Objects.hash(uuid, active, alias, url, order, macAddress, roverPort, ignoreEmbeddedKLV, source, networkTimeout, bufferTime, rtspReliable, thumbnail, classification, latitude, longitude, fov, heading, range, width, height, bitrate);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class FeedV2 {\n");
    
    sb.append("    uuid: ").append(toIndentedString(uuid)).append("\n");
    sb.append("    active: ").append(toIndentedString(active)).append("\n");
    sb.append("    alias: ").append(toIndentedString(alias)).append("\n");
    sb.append("    url: ").append(toIndentedString(url)).append("\n");
    sb.append("    order: ").append(toIndentedString(order)).append("\n");
    sb.append("    macAddress: ").append(toIndentedString(macAddress)).append("\n");
    sb.append("    roverPort: ").append(toIndentedString(roverPort)).append("\n");
    sb.append("    ignoreEmbeddedKLV: ").append(toIndentedString(ignoreEmbeddedKLV)).append("\n");
    sb.append("    source: ").append(toIndentedString(source)).append("\n");
    sb.append("    networkTimeout: ").append(toIndentedString(networkTimeout)).append("\n");
    sb.append("    bufferTime: ").append(toIndentedString(bufferTime)).append("\n");
    sb.append("    rtspReliable: ").append(toIndentedString(rtspReliable)).append("\n");
    sb.append("    thumbnail: ").append(toIndentedString(thumbnail)).append("\n");
    sb.append("    classification: ").append(toIndentedString(classification)).append("\n");
    sb.append("    latitude: ").append(toIndentedString(latitude)).append("\n");
    sb.append("    longitude: ").append(toIndentedString(longitude)).append("\n");
    sb.append("    fov: ").append(toIndentedString(fov)).append("\n");
    sb.append("    heading: ").append(toIndentedString(heading)).append("\n");
    sb.append("    range: ").append(toIndentedString(range)).append("\n");
    sb.append("    width: ").append(toIndentedString(width)).append("\n");
    sb.append("    height: ").append(toIndentedString(height)).append("\n");
    sb.append("    bitrate: ").append(toIndentedString(bitrate)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
