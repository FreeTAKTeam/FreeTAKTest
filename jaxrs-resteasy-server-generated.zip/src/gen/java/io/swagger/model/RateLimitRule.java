package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class RateLimitRule   {
  private Integer clientThresholdCount = null;  private Integer reportingRateLimitSeconds = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("clientThresholdCount")
  public Integer getClientThresholdCount() {
    return clientThresholdCount;
  }
  public void setClientThresholdCount(Integer clientThresholdCount) {
    this.clientThresholdCount = clientThresholdCount;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("reportingRateLimitSeconds")
  public Integer getReportingRateLimitSeconds() {
    return reportingRateLimitSeconds;
  }
  public void setReportingRateLimitSeconds(Integer reportingRateLimitSeconds) {
    this.reportingRateLimitSeconds = reportingRateLimitSeconds;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    RateLimitRule rateLimitRule = (RateLimitRule) o;
    return Objects.equals(clientThresholdCount, rateLimitRule.clientThresholdCount) &&
        Objects.equals(reportingRateLimitSeconds, rateLimitRule.reportingRateLimitSeconds);
  }

  @Override
  public int hashCode() {
    return Objects.hash(clientThresholdCount, reportingRateLimitSeconds);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class RateLimitRule {\n");
    
    sb.append("    clientThresholdCount: ").append(toIndentedString(clientThresholdCount)).append("\n");
    sb.append("    reportingRateLimitSeconds: ").append(toIndentedString(reportingRateLimitSeconds)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
