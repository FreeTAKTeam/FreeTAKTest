package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.Mission;
import java.util.List;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class FederateMissionPerConnectionSettings   {
  private Boolean missionFederateDefault = null;  private List<Mission> missions = new ArrayList<Mission>();

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("missionFederateDefault")
  public Boolean isMissionFederateDefault() {
    return missionFederateDefault;
  }
  public void setMissionFederateDefault(Boolean missionFederateDefault) {
    this.missionFederateDefault = missionFederateDefault;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("missions")
  public List<Mission> getMissions() {
    return missions;
  }
  public void setMissions(List<Mission> missions) {
    this.missions = missions;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    FederateMissionPerConnectionSettings federateMissionPerConnectionSettings = (FederateMissionPerConnectionSettings) o;
    return Objects.equals(missionFederateDefault, federateMissionPerConnectionSettings.missionFederateDefault) &&
        Objects.equals(missions, federateMissionPerConnectionSettings.missions);
  }

  @Override
  public int hashCode() {
    return Objects.hash(missionFederateDefault, missions);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class FederateMissionPerConnectionSettings {\n");
    
    sb.append("    missionFederateDefault: ").append(toIndentedString(missionFederateDefault)).append("\n");
    sb.append("    missions: ").append(toIndentedString(missions)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
