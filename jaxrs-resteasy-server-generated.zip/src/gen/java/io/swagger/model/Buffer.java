package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.LatestSA;
import io.swagger.model.Queue;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class Buffer   {
  private LatestSA latestSA = null;  private Queue queue = null;  private Boolean embeddedIgnite = null;  private Boolean igniteMulticast = null;  private Integer igniteNonMulticastDiscoveryPort = null;  private Integer igniteNonMulticastDiscoveryPortCount = null;  private Integer igniteCommunicationPort = null;  private Integer igniteCommunicationPortCount = null;  private String igniteHost = null;  private Integer igniteWorkerTimeoutMilliseconds = null;

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("latestSA")
  @NotNull
  public LatestSA getLatestSA() {
    return latestSA;
  }
  public void setLatestSA(LatestSA latestSA) {
    this.latestSA = latestSA;
  }

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("queue")
  @NotNull
  public Queue getQueue() {
    return queue;
  }
  public void setQueue(Queue queue) {
    this.queue = queue;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("embeddedIgnite")
  public Boolean isEmbeddedIgnite() {
    return embeddedIgnite;
  }
  public void setEmbeddedIgnite(Boolean embeddedIgnite) {
    this.embeddedIgnite = embeddedIgnite;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("igniteMulticast")
  public Boolean isIgniteMulticast() {
    return igniteMulticast;
  }
  public void setIgniteMulticast(Boolean igniteMulticast) {
    this.igniteMulticast = igniteMulticast;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("igniteNonMulticastDiscoveryPort")
  public Integer getIgniteNonMulticastDiscoveryPort() {
    return igniteNonMulticastDiscoveryPort;
  }
  public void setIgniteNonMulticastDiscoveryPort(Integer igniteNonMulticastDiscoveryPort) {
    this.igniteNonMulticastDiscoveryPort = igniteNonMulticastDiscoveryPort;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("igniteNonMulticastDiscoveryPortCount")
  public Integer getIgniteNonMulticastDiscoveryPortCount() {
    return igniteNonMulticastDiscoveryPortCount;
  }
  public void setIgniteNonMulticastDiscoveryPortCount(Integer igniteNonMulticastDiscoveryPortCount) {
    this.igniteNonMulticastDiscoveryPortCount = igniteNonMulticastDiscoveryPortCount;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("igniteCommunicationPort")
  public Integer getIgniteCommunicationPort() {
    return igniteCommunicationPort;
  }
  public void setIgniteCommunicationPort(Integer igniteCommunicationPort) {
    this.igniteCommunicationPort = igniteCommunicationPort;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("igniteCommunicationPortCount")
  public Integer getIgniteCommunicationPortCount() {
    return igniteCommunicationPortCount;
  }
  public void setIgniteCommunicationPortCount(Integer igniteCommunicationPortCount) {
    this.igniteCommunicationPortCount = igniteCommunicationPortCount;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("igniteHost")
  public String getIgniteHost() {
    return igniteHost;
  }
  public void setIgniteHost(String igniteHost) {
    this.igniteHost = igniteHost;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("igniteWorkerTimeoutMilliseconds")
  public Integer getIgniteWorkerTimeoutMilliseconds() {
    return igniteWorkerTimeoutMilliseconds;
  }
  public void setIgniteWorkerTimeoutMilliseconds(Integer igniteWorkerTimeoutMilliseconds) {
    this.igniteWorkerTimeoutMilliseconds = igniteWorkerTimeoutMilliseconds;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Buffer buffer = (Buffer) o;
    return Objects.equals(latestSA, buffer.latestSA) &&
        Objects.equals(queue, buffer.queue) &&
        Objects.equals(embeddedIgnite, buffer.embeddedIgnite) &&
        Objects.equals(igniteMulticast, buffer.igniteMulticast) &&
        Objects.equals(igniteNonMulticastDiscoveryPort, buffer.igniteNonMulticastDiscoveryPort) &&
        Objects.equals(igniteNonMulticastDiscoveryPortCount, buffer.igniteNonMulticastDiscoveryPortCount) &&
        Objects.equals(igniteCommunicationPort, buffer.igniteCommunicationPort) &&
        Objects.equals(igniteCommunicationPortCount, buffer.igniteCommunicationPortCount) &&
        Objects.equals(igniteHost, buffer.igniteHost) &&
        Objects.equals(igniteWorkerTimeoutMilliseconds, buffer.igniteWorkerTimeoutMilliseconds);
  }

  @Override
  public int hashCode() {
    return Objects.hash(latestSA, queue, embeddedIgnite, igniteMulticast, igniteNonMulticastDiscoveryPort, igniteNonMulticastDiscoveryPortCount, igniteCommunicationPort, igniteCommunicationPortCount, igniteHost, igniteWorkerTimeoutMilliseconds);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Buffer {\n");
    
    sb.append("    latestSA: ").append(toIndentedString(latestSA)).append("\n");
    sb.append("    queue: ").append(toIndentedString(queue)).append("\n");
    sb.append("    embeddedIgnite: ").append(toIndentedString(embeddedIgnite)).append("\n");
    sb.append("    igniteMulticast: ").append(toIndentedString(igniteMulticast)).append("\n");
    sb.append("    igniteNonMulticastDiscoveryPort: ").append(toIndentedString(igniteNonMulticastDiscoveryPort)).append("\n");
    sb.append("    igniteNonMulticastDiscoveryPortCount: ").append(toIndentedString(igniteNonMulticastDiscoveryPortCount)).append("\n");
    sb.append("    igniteCommunicationPort: ").append(toIndentedString(igniteCommunicationPort)).append("\n");
    sb.append("    igniteCommunicationPortCount: ").append(toIndentedString(igniteCommunicationPortCount)).append("\n");
    sb.append("    igniteHost: ").append(toIndentedString(igniteHost)).append("\n");
    sb.append("    igniteWorkerTimeoutMilliseconds: ").append(toIndentedString(igniteWorkerTimeoutMilliseconds)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
