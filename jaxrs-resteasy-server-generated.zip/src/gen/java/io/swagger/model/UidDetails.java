package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.Location;
import java.util.List;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class UidDetails   {
  private String type = null;  private String callsign = null;  private String title = null;  private String iconsetPath = null;  private String color = null;  private List<String> attachments = new ArrayList<String>();  private String name = null;  private String category = null;  private Location location = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("type")
  public String getType() {
    return type;
  }
  public void setType(String type) {
    this.type = type;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("callsign")
  public String getCallsign() {
    return callsign;
  }
  public void setCallsign(String callsign) {
    this.callsign = callsign;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("title")
  public String getTitle() {
    return title;
  }
  public void setTitle(String title) {
    this.title = title;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("iconsetPath")
  public String getIconsetPath() {
    return iconsetPath;
  }
  public void setIconsetPath(String iconsetPath) {
    this.iconsetPath = iconsetPath;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("color")
  public String getColor() {
    return color;
  }
  public void setColor(String color) {
    this.color = color;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("attachments")
  public List<String> getAttachments() {
    return attachments;
  }
  public void setAttachments(List<String> attachments) {
    this.attachments = attachments;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("name")
  public String getName() {
    return name;
  }
  public void setName(String name) {
    this.name = name;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("category")
  public String getCategory() {
    return category;
  }
  public void setCategory(String category) {
    this.category = category;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("location")
  public Location getLocation() {
    return location;
  }
  public void setLocation(Location location) {
    this.location = location;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    UidDetails uidDetails = (UidDetails) o;
    return Objects.equals(type, uidDetails.type) &&
        Objects.equals(callsign, uidDetails.callsign) &&
        Objects.equals(title, uidDetails.title) &&
        Objects.equals(iconsetPath, uidDetails.iconsetPath) &&
        Objects.equals(color, uidDetails.color) &&
        Objects.equals(attachments, uidDetails.attachments) &&
        Objects.equals(name, uidDetails.name) &&
        Objects.equals(category, uidDetails.category) &&
        Objects.equals(location, uidDetails.location);
  }

  @Override
  public int hashCode() {
    return Objects.hash(type, callsign, title, iconsetPath, color, attachments, name, category, location);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class UidDetails {\n");
    
    sb.append("    type: ").append(toIndentedString(type)).append("\n");
    sb.append("    callsign: ").append(toIndentedString(callsign)).append("\n");
    sb.append("    title: ").append(toIndentedString(title)).append("\n");
    sb.append("    iconsetPath: ").append(toIndentedString(iconsetPath)).append("\n");
    sb.append("    color: ").append(toIndentedString(color)).append("\n");
    sb.append("    attachments: ").append(toIndentedString(attachments)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    category: ").append(toIndentedString(category)).append("\n");
    sb.append("    location: ").append(toIndentedString(location)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
