package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class FederationPort   {
  private Integer port = null;  private String tlsVersion = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("port")
  public Integer getPort() {
    return port;
  }
  public void setPort(Integer port) {
    this.port = port;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("tlsVersion")
  public String getTlsVersion() {
    return tlsVersion;
  }
  public void setTlsVersion(String tlsVersion) {
    this.tlsVersion = tlsVersion;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    FederationPort federationPort = (FederationPort) o;
    return Objects.equals(port, federationPort.port) &&
        Objects.equals(tlsVersion, federationPort.tlsVersion);
  }

  @Override
  public int hashCode() {
    return Objects.hash(port, tlsVersion);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class FederationPort {\n");
    
    sb.append("    port: ").append(toIndentedString(port)).append("\n");
    sb.append("    tlsVersion: ").append(toIndentedString(tlsVersion)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
