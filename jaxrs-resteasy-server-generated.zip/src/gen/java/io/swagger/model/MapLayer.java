package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import java.util.Date;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class MapLayer   {
  private Integer minZoom = null;  private Integer maxZoom = null;  private Double north = null;  private Double south = null;  private Double east = null;  private Double west = null;  private String uid = null;  private String creatorUid = null;  private String name = null;  private String description = null;  private String type = null;  private String url = null;  private String tileType = null;  private String serverParts = null;  private String backgroundColor = null;  private String tileUpdate = null;  private String additionalParameters = null;  private String coordinateSystem = null;  private String version = null;  private String layers = null;  private Integer opacity = null;  private Date createTime = null;  private Date modifiedTime = null;  private Boolean defaultLayer = null;  private Boolean enabled = null;  private Boolean ignoreErrors = null;  private Boolean invertYCoordinate = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("minZoom")
  public Integer getMinZoom() {
    return minZoom;
  }
  public void setMinZoom(Integer minZoom) {
    this.minZoom = minZoom;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("maxZoom")
  public Integer getMaxZoom() {
    return maxZoom;
  }
  public void setMaxZoom(Integer maxZoom) {
    this.maxZoom = maxZoom;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("north")
  public Double getNorth() {
    return north;
  }
  public void setNorth(Double north) {
    this.north = north;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("south")
  public Double getSouth() {
    return south;
  }
  public void setSouth(Double south) {
    this.south = south;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("east")
  public Double getEast() {
    return east;
  }
  public void setEast(Double east) {
    this.east = east;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("west")
  public Double getWest() {
    return west;
  }
  public void setWest(Double west) {
    this.west = west;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("uid")
  public String getUid() {
    return uid;
  }
  public void setUid(String uid) {
    this.uid = uid;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("creatorUid")
  public String getCreatorUid() {
    return creatorUid;
  }
  public void setCreatorUid(String creatorUid) {
    this.creatorUid = creatorUid;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("name")
  public String getName() {
    return name;
  }
  public void setName(String name) {
    this.name = name;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("description")
  public String getDescription() {
    return description;
  }
  public void setDescription(String description) {
    this.description = description;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("type")
  public String getType() {
    return type;
  }
  public void setType(String type) {
    this.type = type;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("url")
  public String getUrl() {
    return url;
  }
  public void setUrl(String url) {
    this.url = url;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("tileType")
  public String getTileType() {
    return tileType;
  }
  public void setTileType(String tileType) {
    this.tileType = tileType;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("serverParts")
  public String getServerParts() {
    return serverParts;
  }
  public void setServerParts(String serverParts) {
    this.serverParts = serverParts;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("backgroundColor")
  public String getBackgroundColor() {
    return backgroundColor;
  }
  public void setBackgroundColor(String backgroundColor) {
    this.backgroundColor = backgroundColor;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("tileUpdate")
  public String getTileUpdate() {
    return tileUpdate;
  }
  public void setTileUpdate(String tileUpdate) {
    this.tileUpdate = tileUpdate;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("additionalParameters")
  public String getAdditionalParameters() {
    return additionalParameters;
  }
  public void setAdditionalParameters(String additionalParameters) {
    this.additionalParameters = additionalParameters;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("coordinateSystem")
  public String getCoordinateSystem() {
    return coordinateSystem;
  }
  public void setCoordinateSystem(String coordinateSystem) {
    this.coordinateSystem = coordinateSystem;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("version")
  public String getVersion() {
    return version;
  }
  public void setVersion(String version) {
    this.version = version;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("layers")
  public String getLayers() {
    return layers;
  }
  public void setLayers(String layers) {
    this.layers = layers;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("opacity")
  public Integer getOpacity() {
    return opacity;
  }
  public void setOpacity(Integer opacity) {
    this.opacity = opacity;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("createTime")
  public Date getCreateTime() {
    return createTime;
  }
  public void setCreateTime(Date createTime) {
    this.createTime = createTime;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("modifiedTime")
  public Date getModifiedTime() {
    return modifiedTime;
  }
  public void setModifiedTime(Date modifiedTime) {
    this.modifiedTime = modifiedTime;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("defaultLayer")
  public Boolean isDefaultLayer() {
    return defaultLayer;
  }
  public void setDefaultLayer(Boolean defaultLayer) {
    this.defaultLayer = defaultLayer;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("enabled")
  public Boolean isEnabled() {
    return enabled;
  }
  public void setEnabled(Boolean enabled) {
    this.enabled = enabled;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("ignoreErrors")
  public Boolean isIgnoreErrors() {
    return ignoreErrors;
  }
  public void setIgnoreErrors(Boolean ignoreErrors) {
    this.ignoreErrors = ignoreErrors;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("invertYCoordinate")
  public Boolean isInvertYCoordinate() {
    return invertYCoordinate;
  }
  public void setInvertYCoordinate(Boolean invertYCoordinate) {
    this.invertYCoordinate = invertYCoordinate;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    MapLayer mapLayer = (MapLayer) o;
    return Objects.equals(minZoom, mapLayer.minZoom) &&
        Objects.equals(maxZoom, mapLayer.maxZoom) &&
        Objects.equals(north, mapLayer.north) &&
        Objects.equals(south, mapLayer.south) &&
        Objects.equals(east, mapLayer.east) &&
        Objects.equals(west, mapLayer.west) &&
        Objects.equals(uid, mapLayer.uid) &&
        Objects.equals(creatorUid, mapLayer.creatorUid) &&
        Objects.equals(name, mapLayer.name) &&
        Objects.equals(description, mapLayer.description) &&
        Objects.equals(type, mapLayer.type) &&
        Objects.equals(url, mapLayer.url) &&
        Objects.equals(tileType, mapLayer.tileType) &&
        Objects.equals(serverParts, mapLayer.serverParts) &&
        Objects.equals(backgroundColor, mapLayer.backgroundColor) &&
        Objects.equals(tileUpdate, mapLayer.tileUpdate) &&
        Objects.equals(additionalParameters, mapLayer.additionalParameters) &&
        Objects.equals(coordinateSystem, mapLayer.coordinateSystem) &&
        Objects.equals(version, mapLayer.version) &&
        Objects.equals(layers, mapLayer.layers) &&
        Objects.equals(opacity, mapLayer.opacity) &&
        Objects.equals(createTime, mapLayer.createTime) &&
        Objects.equals(modifiedTime, mapLayer.modifiedTime) &&
        Objects.equals(defaultLayer, mapLayer.defaultLayer) &&
        Objects.equals(enabled, mapLayer.enabled) &&
        Objects.equals(ignoreErrors, mapLayer.ignoreErrors) &&
        Objects.equals(invertYCoordinate, mapLayer.invertYCoordinate);
  }

  @Override
  public int hashCode() {
    return Objects.hash(minZoom, maxZoom, north, south, east, west, uid, creatorUid, name, description, type, url, tileType, serverParts, backgroundColor, tileUpdate, additionalParameters, coordinateSystem, version, layers, opacity, createTime, modifiedTime, defaultLayer, enabled, ignoreErrors, invertYCoordinate);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class MapLayer {\n");
    
    sb.append("    minZoom: ").append(toIndentedString(minZoom)).append("\n");
    sb.append("    maxZoom: ").append(toIndentedString(maxZoom)).append("\n");
    sb.append("    north: ").append(toIndentedString(north)).append("\n");
    sb.append("    south: ").append(toIndentedString(south)).append("\n");
    sb.append("    east: ").append(toIndentedString(east)).append("\n");
    sb.append("    west: ").append(toIndentedString(west)).append("\n");
    sb.append("    uid: ").append(toIndentedString(uid)).append("\n");
    sb.append("    creatorUid: ").append(toIndentedString(creatorUid)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    description: ").append(toIndentedString(description)).append("\n");
    sb.append("    type: ").append(toIndentedString(type)).append("\n");
    sb.append("    url: ").append(toIndentedString(url)).append("\n");
    sb.append("    tileType: ").append(toIndentedString(tileType)).append("\n");
    sb.append("    serverParts: ").append(toIndentedString(serverParts)).append("\n");
    sb.append("    backgroundColor: ").append(toIndentedString(backgroundColor)).append("\n");
    sb.append("    tileUpdate: ").append(toIndentedString(tileUpdate)).append("\n");
    sb.append("    additionalParameters: ").append(toIndentedString(additionalParameters)).append("\n");
    sb.append("    coordinateSystem: ").append(toIndentedString(coordinateSystem)).append("\n");
    sb.append("    version: ").append(toIndentedString(version)).append("\n");
    sb.append("    layers: ").append(toIndentedString(layers)).append("\n");
    sb.append("    opacity: ").append(toIndentedString(opacity)).append("\n");
    sb.append("    createTime: ").append(toIndentedString(createTime)).append("\n");
    sb.append("    modifiedTime: ").append(toIndentedString(modifiedTime)).append("\n");
    sb.append("    defaultLayer: ").append(toIndentedString(defaultLayer)).append("\n");
    sb.append("    enabled: ").append(toIndentedString(enabled)).append("\n");
    sb.append("    ignoreErrors: ").append(toIndentedString(ignoreErrors)).append("\n");
    sb.append("    invertYCoordinate: ").append(toIndentedString(invertYCoordinate)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
