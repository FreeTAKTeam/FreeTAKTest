package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import io.swagger.model.ConnectionInfo;
import io.swagger.model.Federate;
import io.swagger.model.Group;
import io.swagger.model.User;
import java.util.List;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class ConnectionStatus   {
  private String nodeId = null;  private ConnectionInfo connection = null;  private Federate federate = null;  private String lastError = null;  /**
   * Gets or Sets connectionStatusValue
   */
  public enum ConnectionStatusValueEnum {
    DISABLED("DISABLED"),
    CONNECTED("CONNECTED"),
    CONNECTING("CONNECTING"),
    WAITING_TO_RETRY("WAITING_TO_RETRY"),
    RETRY_SCHEDULED("RETRY_SCHEDULED");
    private String value;

    ConnectionStatusValueEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }
  }
  private ConnectionStatusValueEnum connectionStatusValue = null;  private User user = null;  private List<Group> groups = new ArrayList<Group>();  private String federateName = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("nodeId")
  public String getNodeId() {
    return nodeId;
  }
  public void setNodeId(String nodeId) {
    this.nodeId = nodeId;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("connection")
  public ConnectionInfo getConnection() {
    return connection;
  }
  public void setConnection(ConnectionInfo connection) {
    this.connection = connection;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("federate")
  public Federate getFederate() {
    return federate;
  }
  public void setFederate(Federate federate) {
    this.federate = federate;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("lastError")
  public String getLastError() {
    return lastError;
  }
  public void setLastError(String lastError) {
    this.lastError = lastError;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("connectionStatusValue")
  public ConnectionStatusValueEnum getConnectionStatusValue() {
    return connectionStatusValue;
  }
  public void setConnectionStatusValue(ConnectionStatusValueEnum connectionStatusValue) {
    this.connectionStatusValue = connectionStatusValue;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("user")
  public User getUser() {
    return user;
  }
  public void setUser(User user) {
    this.user = user;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("groups")
  public List<Group> getGroups() {
    return groups;
  }
  public void setGroups(List<Group> groups) {
    this.groups = groups;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("federateName")
  public String getFederateName() {
    return federateName;
  }
  public void setFederateName(String federateName) {
    this.federateName = federateName;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ConnectionStatus connectionStatus = (ConnectionStatus) o;
    return Objects.equals(nodeId, connectionStatus.nodeId) &&
        Objects.equals(connection, connectionStatus.connection) &&
        Objects.equals(federate, connectionStatus.federate) &&
        Objects.equals(lastError, connectionStatus.lastError) &&
        Objects.equals(connectionStatusValue, connectionStatus.connectionStatusValue) &&
        Objects.equals(user, connectionStatus.user) &&
        Objects.equals(groups, connectionStatus.groups) &&
        Objects.equals(federateName, connectionStatus.federateName);
  }

  @Override
  public int hashCode() {
    return Objects.hash(nodeId, connection, federate, lastError, connectionStatusValue, user, groups, federateName);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ConnectionStatus {\n");
    
    sb.append("    nodeId: ").append(toIndentedString(nodeId)).append("\n");
    sb.append("    connection: ").append(toIndentedString(connection)).append("\n");
    sb.append("    federate: ").append(toIndentedString(federate)).append("\n");
    sb.append("    lastError: ").append(toIndentedString(lastError)).append("\n");
    sb.append("    connectionStatusValue: ").append(toIndentedString(connectionStatusValue)).append("\n");
    sb.append("    user: ").append(toIndentedString(user)).append("\n");
    sb.append("    groups: ").append(toIndentedString(groups)).append("\n");
    sb.append("    federateName: ").append(toIndentedString(federateName)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
