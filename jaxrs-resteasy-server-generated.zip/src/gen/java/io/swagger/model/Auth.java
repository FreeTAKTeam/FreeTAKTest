package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.Ldap;
import io.swagger.model.Oauth;
import java.io.File;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class Auth   {
  private Ldap ldap = null;  private File file = null;  private Oauth oauth = null;  private Boolean x509Groups = null;  private Boolean x509GroupsDefaultRDN = null;  private Boolean x509AddAnonymous = null;  private Boolean x509UseGroupCache = null;  private Boolean x509CheckRevocation = null;  private Boolean x509TokenAuth = null;  private String _default = null;  private String dnusernameExtractorRegex = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("ldap")
  public Ldap getLdap() {
    return ldap;
  }
  public void setLdap(Ldap ldap) {
    this.ldap = ldap;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("file")
  public File getFile() {
    return file;
  }
  public void setFile(File file) {
    this.file = file;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("oauth")
  public Oauth getOauth() {
    return oauth;
  }
  public void setOauth(Oauth oauth) {
    this.oauth = oauth;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("x509Groups")
  public Boolean isX509Groups() {
    return x509Groups;
  }
  public void setX509Groups(Boolean x509Groups) {
    this.x509Groups = x509Groups;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("x509GroupsDefaultRDN")
  public Boolean isX509GroupsDefaultRDN() {
    return x509GroupsDefaultRDN;
  }
  public void setX509GroupsDefaultRDN(Boolean x509GroupsDefaultRDN) {
    this.x509GroupsDefaultRDN = x509GroupsDefaultRDN;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("x509AddAnonymous")
  public Boolean isX509AddAnonymous() {
    return x509AddAnonymous;
  }
  public void setX509AddAnonymous(Boolean x509AddAnonymous) {
    this.x509AddAnonymous = x509AddAnonymous;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("x509UseGroupCache")
  public Boolean isX509UseGroupCache() {
    return x509UseGroupCache;
  }
  public void setX509UseGroupCache(Boolean x509UseGroupCache) {
    this.x509UseGroupCache = x509UseGroupCache;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("x509CheckRevocation")
  public Boolean isX509CheckRevocation() {
    return x509CheckRevocation;
  }
  public void setX509CheckRevocation(Boolean x509CheckRevocation) {
    this.x509CheckRevocation = x509CheckRevocation;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("x509TokenAuth")
  public Boolean isX509TokenAuth() {
    return x509TokenAuth;
  }
  public void setX509TokenAuth(Boolean x509TokenAuth) {
    this.x509TokenAuth = x509TokenAuth;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("default")
  public String getDefault() {
    return _default;
  }
  public void setDefault(String _default) {
    this._default = _default;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("dnusernameExtractorRegex")
  public String getDnusernameExtractorRegex() {
    return dnusernameExtractorRegex;
  }
  public void setDnusernameExtractorRegex(String dnusernameExtractorRegex) {
    this.dnusernameExtractorRegex = dnusernameExtractorRegex;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Auth auth = (Auth) o;
    return Objects.equals(ldap, auth.ldap) &&
        Objects.equals(file, auth.file) &&
        Objects.equals(oauth, auth.oauth) &&
        Objects.equals(x509Groups, auth.x509Groups) &&
        Objects.equals(x509GroupsDefaultRDN, auth.x509GroupsDefaultRDN) &&
        Objects.equals(x509AddAnonymous, auth.x509AddAnonymous) &&
        Objects.equals(x509UseGroupCache, auth.x509UseGroupCache) &&
        Objects.equals(x509CheckRevocation, auth.x509CheckRevocation) &&
        Objects.equals(x509TokenAuth, auth.x509TokenAuth) &&
        Objects.equals(_default, auth._default) &&
        Objects.equals(dnusernameExtractorRegex, auth.dnusernameExtractorRegex);
  }

  @Override
  public int hashCode() {
    return Objects.hash(ldap, file, oauth, x509Groups, x509GroupsDefaultRDN, x509AddAnonymous, x509UseGroupCache, x509CheckRevocation, x509TokenAuth, _default, dnusernameExtractorRegex);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Auth {\n");
    
    sb.append("    ldap: ").append(toIndentedString(ldap)).append("\n");
    sb.append("    file: ").append(toIndentedString(file)).append("\n");
    sb.append("    oauth: ").append(toIndentedString(oauth)).append("\n");
    sb.append("    x509Groups: ").append(toIndentedString(x509Groups)).append("\n");
    sb.append("    x509GroupsDefaultRDN: ").append(toIndentedString(x509GroupsDefaultRDN)).append("\n");
    sb.append("    x509AddAnonymous: ").append(toIndentedString(x509AddAnonymous)).append("\n");
    sb.append("    x509UseGroupCache: ").append(toIndentedString(x509UseGroupCache)).append("\n");
    sb.append("    x509CheckRevocation: ").append(toIndentedString(x509CheckRevocation)).append("\n");
    sb.append("    x509TokenAuth: ").append(toIndentedString(x509TokenAuth)).append("\n");
    sb.append("    _default: ").append(toIndentedString(_default)).append("\n");
    sb.append("    dnusernameExtractorRegex: ").append(toIndentedString(dnusernameExtractorRegex)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
