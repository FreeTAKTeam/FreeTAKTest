package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.Announce;
import io.swagger.model.Connector;
import io.swagger.model.DataFeed;
import io.swagger.model.Filter;
import io.swagger.model.Input;
import java.util.List;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class Network   {
  private Filter filter = null;  private List<Input> input = new ArrayList<Input>();  private List<DataFeed> datafeed = new ArrayList<DataFeed>();  private List<Connector> connector = new ArrayList<Connector>();  private Announce announce = null;  private Integer multicastTTL = null;  private String serverId = null;  private Integer enterpriseSyncSizeLimitMB = null;  private Integer missionPackageAutoExtractSizeLimitMB = null;  private Integer httpSessionTimeoutMinutes = null;  private String extWebContentDir = null;  private String takServerHost = null;  private Boolean useLinuxEpoll = null;  private Boolean allowAllOrigins = null;  private Integer esyncEnableCache = null;  private Boolean esyncEnableCotFilter = null;  private String esyncCotFilter = null;  private String version = null;  private String webCiphers = null;  private Integer tomcatMaxPool = null;  private String cloudwatchNamespace = null;  private Integer cloudwatchMetricsBatchSize = null;  private Boolean cloudwatchEnable = null;  private String cloudwatchName = null;  private String missionCopTool = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("filter")
  public Filter getFilter() {
    return filter;
  }
  public void setFilter(Filter filter) {
    this.filter = filter;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("input")
  public List<Input> getInput() {
    return input;
  }
  public void setInput(List<Input> input) {
    this.input = input;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("datafeed")
  public List<DataFeed> getDatafeed() {
    return datafeed;
  }
  public void setDatafeed(List<DataFeed> datafeed) {
    this.datafeed = datafeed;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("connector")
  public List<Connector> getConnector() {
    return connector;
  }
  public void setConnector(List<Connector> connector) {
    this.connector = connector;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("announce")
  public Announce getAnnounce() {
    return announce;
  }
  public void setAnnounce(Announce announce) {
    this.announce = announce;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("multicastTTL")
  public Integer getMulticastTTL() {
    return multicastTTL;
  }
  public void setMulticastTTL(Integer multicastTTL) {
    this.multicastTTL = multicastTTL;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("serverId")
  public String getServerId() {
    return serverId;
  }
  public void setServerId(String serverId) {
    this.serverId = serverId;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("enterpriseSyncSizeLimitMB")
  public Integer getEnterpriseSyncSizeLimitMB() {
    return enterpriseSyncSizeLimitMB;
  }
  public void setEnterpriseSyncSizeLimitMB(Integer enterpriseSyncSizeLimitMB) {
    this.enterpriseSyncSizeLimitMB = enterpriseSyncSizeLimitMB;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("missionPackageAutoExtractSizeLimitMB")
  public Integer getMissionPackageAutoExtractSizeLimitMB() {
    return missionPackageAutoExtractSizeLimitMB;
  }
  public void setMissionPackageAutoExtractSizeLimitMB(Integer missionPackageAutoExtractSizeLimitMB) {
    this.missionPackageAutoExtractSizeLimitMB = missionPackageAutoExtractSizeLimitMB;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("httpSessionTimeoutMinutes")
  public Integer getHttpSessionTimeoutMinutes() {
    return httpSessionTimeoutMinutes;
  }
  public void setHttpSessionTimeoutMinutes(Integer httpSessionTimeoutMinutes) {
    this.httpSessionTimeoutMinutes = httpSessionTimeoutMinutes;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("extWebContentDir")
  public String getExtWebContentDir() {
    return extWebContentDir;
  }
  public void setExtWebContentDir(String extWebContentDir) {
    this.extWebContentDir = extWebContentDir;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("takServerHost")
  public String getTakServerHost() {
    return takServerHost;
  }
  public void setTakServerHost(String takServerHost) {
    this.takServerHost = takServerHost;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("useLinuxEpoll")
  public Boolean isUseLinuxEpoll() {
    return useLinuxEpoll;
  }
  public void setUseLinuxEpoll(Boolean useLinuxEpoll) {
    this.useLinuxEpoll = useLinuxEpoll;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("allowAllOrigins")
  public Boolean isAllowAllOrigins() {
    return allowAllOrigins;
  }
  public void setAllowAllOrigins(Boolean allowAllOrigins) {
    this.allowAllOrigins = allowAllOrigins;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("esyncEnableCache")
  public Integer getEsyncEnableCache() {
    return esyncEnableCache;
  }
  public void setEsyncEnableCache(Integer esyncEnableCache) {
    this.esyncEnableCache = esyncEnableCache;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("esyncEnableCotFilter")
  public Boolean isEsyncEnableCotFilter() {
    return esyncEnableCotFilter;
  }
  public void setEsyncEnableCotFilter(Boolean esyncEnableCotFilter) {
    this.esyncEnableCotFilter = esyncEnableCotFilter;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("esyncCotFilter")
  public String getEsyncCotFilter() {
    return esyncCotFilter;
  }
  public void setEsyncCotFilter(String esyncCotFilter) {
    this.esyncCotFilter = esyncCotFilter;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("version")
  public String getVersion() {
    return version;
  }
  public void setVersion(String version) {
    this.version = version;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("webCiphers")
  public String getWebCiphers() {
    return webCiphers;
  }
  public void setWebCiphers(String webCiphers) {
    this.webCiphers = webCiphers;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("tomcatMaxPool")
  public Integer getTomcatMaxPool() {
    return tomcatMaxPool;
  }
  public void setTomcatMaxPool(Integer tomcatMaxPool) {
    this.tomcatMaxPool = tomcatMaxPool;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("cloudwatchNamespace")
  public String getCloudwatchNamespace() {
    return cloudwatchNamespace;
  }
  public void setCloudwatchNamespace(String cloudwatchNamespace) {
    this.cloudwatchNamespace = cloudwatchNamespace;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("cloudwatchMetricsBatchSize")
  public Integer getCloudwatchMetricsBatchSize() {
    return cloudwatchMetricsBatchSize;
  }
  public void setCloudwatchMetricsBatchSize(Integer cloudwatchMetricsBatchSize) {
    this.cloudwatchMetricsBatchSize = cloudwatchMetricsBatchSize;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("cloudwatchEnable")
  public Boolean isCloudwatchEnable() {
    return cloudwatchEnable;
  }
  public void setCloudwatchEnable(Boolean cloudwatchEnable) {
    this.cloudwatchEnable = cloudwatchEnable;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("cloudwatchName")
  public String getCloudwatchName() {
    return cloudwatchName;
  }
  public void setCloudwatchName(String cloudwatchName) {
    this.cloudwatchName = cloudwatchName;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("missionCopTool")
  public String getMissionCopTool() {
    return missionCopTool;
  }
  public void setMissionCopTool(String missionCopTool) {
    this.missionCopTool = missionCopTool;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Network network = (Network) o;
    return Objects.equals(filter, network.filter) &&
        Objects.equals(input, network.input) &&
        Objects.equals(datafeed, network.datafeed) &&
        Objects.equals(connector, network.connector) &&
        Objects.equals(announce, network.announce) &&
        Objects.equals(multicastTTL, network.multicastTTL) &&
        Objects.equals(serverId, network.serverId) &&
        Objects.equals(enterpriseSyncSizeLimitMB, network.enterpriseSyncSizeLimitMB) &&
        Objects.equals(missionPackageAutoExtractSizeLimitMB, network.missionPackageAutoExtractSizeLimitMB) &&
        Objects.equals(httpSessionTimeoutMinutes, network.httpSessionTimeoutMinutes) &&
        Objects.equals(extWebContentDir, network.extWebContentDir) &&
        Objects.equals(takServerHost, network.takServerHost) &&
        Objects.equals(useLinuxEpoll, network.useLinuxEpoll) &&
        Objects.equals(allowAllOrigins, network.allowAllOrigins) &&
        Objects.equals(esyncEnableCache, network.esyncEnableCache) &&
        Objects.equals(esyncEnableCotFilter, network.esyncEnableCotFilter) &&
        Objects.equals(esyncCotFilter, network.esyncCotFilter) &&
        Objects.equals(version, network.version) &&
        Objects.equals(webCiphers, network.webCiphers) &&
        Objects.equals(tomcatMaxPool, network.tomcatMaxPool) &&
        Objects.equals(cloudwatchNamespace, network.cloudwatchNamespace) &&
        Objects.equals(cloudwatchMetricsBatchSize, network.cloudwatchMetricsBatchSize) &&
        Objects.equals(cloudwatchEnable, network.cloudwatchEnable) &&
        Objects.equals(cloudwatchName, network.cloudwatchName) &&
        Objects.equals(missionCopTool, network.missionCopTool);
  }

  @Override
  public int hashCode() {
    return Objects.hash(filter, input, datafeed, connector, announce, multicastTTL, serverId, enterpriseSyncSizeLimitMB, missionPackageAutoExtractSizeLimitMB, httpSessionTimeoutMinutes, extWebContentDir, takServerHost, useLinuxEpoll, allowAllOrigins, esyncEnableCache, esyncEnableCotFilter, esyncCotFilter, version, webCiphers, tomcatMaxPool, cloudwatchNamespace, cloudwatchMetricsBatchSize, cloudwatchEnable, cloudwatchName, missionCopTool);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Network {\n");
    
    sb.append("    filter: ").append(toIndentedString(filter)).append("\n");
    sb.append("    input: ").append(toIndentedString(input)).append("\n");
    sb.append("    datafeed: ").append(toIndentedString(datafeed)).append("\n");
    sb.append("    connector: ").append(toIndentedString(connector)).append("\n");
    sb.append("    announce: ").append(toIndentedString(announce)).append("\n");
    sb.append("    multicastTTL: ").append(toIndentedString(multicastTTL)).append("\n");
    sb.append("    serverId: ").append(toIndentedString(serverId)).append("\n");
    sb.append("    enterpriseSyncSizeLimitMB: ").append(toIndentedString(enterpriseSyncSizeLimitMB)).append("\n");
    sb.append("    missionPackageAutoExtractSizeLimitMB: ").append(toIndentedString(missionPackageAutoExtractSizeLimitMB)).append("\n");
    sb.append("    httpSessionTimeoutMinutes: ").append(toIndentedString(httpSessionTimeoutMinutes)).append("\n");
    sb.append("    extWebContentDir: ").append(toIndentedString(extWebContentDir)).append("\n");
    sb.append("    takServerHost: ").append(toIndentedString(takServerHost)).append("\n");
    sb.append("    useLinuxEpoll: ").append(toIndentedString(useLinuxEpoll)).append("\n");
    sb.append("    allowAllOrigins: ").append(toIndentedString(allowAllOrigins)).append("\n");
    sb.append("    esyncEnableCache: ").append(toIndentedString(esyncEnableCache)).append("\n");
    sb.append("    esyncEnableCotFilter: ").append(toIndentedString(esyncEnableCotFilter)).append("\n");
    sb.append("    esyncCotFilter: ").append(toIndentedString(esyncCotFilter)).append("\n");
    sb.append("    version: ").append(toIndentedString(version)).append("\n");
    sb.append("    webCiphers: ").append(toIndentedString(webCiphers)).append("\n");
    sb.append("    tomcatMaxPool: ").append(toIndentedString(tomcatMaxPool)).append("\n");
    sb.append("    cloudwatchNamespace: ").append(toIndentedString(cloudwatchNamespace)).append("\n");
    sb.append("    cloudwatchMetricsBatchSize: ").append(toIndentedString(cloudwatchMetricsBatchSize)).append("\n");
    sb.append("    cloudwatchEnable: ").append(toIndentedString(cloudwatchEnable)).append("\n");
    sb.append("    cloudwatchName: ").append(toIndentedString(cloudwatchName)).append("\n");
    sb.append("    missionCopTool: ").append(toIndentedString(missionCopTool)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
