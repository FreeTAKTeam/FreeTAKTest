package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class Connector   {
  private Integer port = null;  private Boolean tls = null;  private Boolean useFederationTruststore = null;  private String clientAuth = null;  private Boolean allowBasicAuth = null;  private String crlFile = null;  private String name = null;  private String keystore = null;  private String keystoreFile = null;  private String keystorePass = null;  private String truststore = null;  private String truststoreFile = null;  private String truststorePass = null;  private Boolean enableAdminUI = null;  private Boolean enableWebtak = null;  private Boolean enableNonAdminUI = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("port")
  public Integer getPort() {
    return port;
  }
  public void setPort(Integer port) {
    this.port = port;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("tls")
  public Boolean isTls() {
    return tls;
  }
  public void setTls(Boolean tls) {
    this.tls = tls;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("useFederationTruststore")
  public Boolean isUseFederationTruststore() {
    return useFederationTruststore;
  }
  public void setUseFederationTruststore(Boolean useFederationTruststore) {
    this.useFederationTruststore = useFederationTruststore;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("clientAuth")
  public String getClientAuth() {
    return clientAuth;
  }
  public void setClientAuth(String clientAuth) {
    this.clientAuth = clientAuth;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("allowBasicAuth")
  public Boolean isAllowBasicAuth() {
    return allowBasicAuth;
  }
  public void setAllowBasicAuth(Boolean allowBasicAuth) {
    this.allowBasicAuth = allowBasicAuth;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("crlFile")
  public String getCrlFile() {
    return crlFile;
  }
  public void setCrlFile(String crlFile) {
    this.crlFile = crlFile;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("name")
  public String getName() {
    return name;
  }
  public void setName(String name) {
    this.name = name;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("keystore")
  public String getKeystore() {
    return keystore;
  }
  public void setKeystore(String keystore) {
    this.keystore = keystore;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("keystoreFile")
  public String getKeystoreFile() {
    return keystoreFile;
  }
  public void setKeystoreFile(String keystoreFile) {
    this.keystoreFile = keystoreFile;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("keystorePass")
  public String getKeystorePass() {
    return keystorePass;
  }
  public void setKeystorePass(String keystorePass) {
    this.keystorePass = keystorePass;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("truststore")
  public String getTruststore() {
    return truststore;
  }
  public void setTruststore(String truststore) {
    this.truststore = truststore;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("truststoreFile")
  public String getTruststoreFile() {
    return truststoreFile;
  }
  public void setTruststoreFile(String truststoreFile) {
    this.truststoreFile = truststoreFile;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("truststorePass")
  public String getTruststorePass() {
    return truststorePass;
  }
  public void setTruststorePass(String truststorePass) {
    this.truststorePass = truststorePass;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("enableAdminUI")
  public Boolean isEnableAdminUI() {
    return enableAdminUI;
  }
  public void setEnableAdminUI(Boolean enableAdminUI) {
    this.enableAdminUI = enableAdminUI;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("enableWebtak")
  public Boolean isEnableWebtak() {
    return enableWebtak;
  }
  public void setEnableWebtak(Boolean enableWebtak) {
    this.enableWebtak = enableWebtak;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("enableNonAdminUI")
  public Boolean isEnableNonAdminUI() {
    return enableNonAdminUI;
  }
  public void setEnableNonAdminUI(Boolean enableNonAdminUI) {
    this.enableNonAdminUI = enableNonAdminUI;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Connector connector = (Connector) o;
    return Objects.equals(port, connector.port) &&
        Objects.equals(tls, connector.tls) &&
        Objects.equals(useFederationTruststore, connector.useFederationTruststore) &&
        Objects.equals(clientAuth, connector.clientAuth) &&
        Objects.equals(allowBasicAuth, connector.allowBasicAuth) &&
        Objects.equals(crlFile, connector.crlFile) &&
        Objects.equals(name, connector.name) &&
        Objects.equals(keystore, connector.keystore) &&
        Objects.equals(keystoreFile, connector.keystoreFile) &&
        Objects.equals(keystorePass, connector.keystorePass) &&
        Objects.equals(truststore, connector.truststore) &&
        Objects.equals(truststoreFile, connector.truststoreFile) &&
        Objects.equals(truststorePass, connector.truststorePass) &&
        Objects.equals(enableAdminUI, connector.enableAdminUI) &&
        Objects.equals(enableWebtak, connector.enableWebtak) &&
        Objects.equals(enableNonAdminUI, connector.enableNonAdminUI);
  }

  @Override
  public int hashCode() {
    return Objects.hash(port, tls, useFederationTruststore, clientAuth, allowBasicAuth, crlFile, name, keystore, keystoreFile, keystorePass, truststore, truststoreFile, truststorePass, enableAdminUI, enableWebtak, enableNonAdminUI);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Connector {\n");
    
    sb.append("    port: ").append(toIndentedString(port)).append("\n");
    sb.append("    tls: ").append(toIndentedString(tls)).append("\n");
    sb.append("    useFederationTruststore: ").append(toIndentedString(useFederationTruststore)).append("\n");
    sb.append("    clientAuth: ").append(toIndentedString(clientAuth)).append("\n");
    sb.append("    allowBasicAuth: ").append(toIndentedString(allowBasicAuth)).append("\n");
    sb.append("    crlFile: ").append(toIndentedString(crlFile)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    keystore: ").append(toIndentedString(keystore)).append("\n");
    sb.append("    keystoreFile: ").append(toIndentedString(keystoreFile)).append("\n");
    sb.append("    keystorePass: ").append(toIndentedString(keystorePass)).append("\n");
    sb.append("    truststore: ").append(toIndentedString(truststore)).append("\n");
    sb.append("    truststoreFile: ").append(toIndentedString(truststoreFile)).append("\n");
    sb.append("    truststorePass: ").append(toIndentedString(truststorePass)).append("\n");
    sb.append("    enableAdminUI: ").append(toIndentedString(enableAdminUI)).append("\n");
    sb.append("    enableWebtak: ").append(toIndentedString(enableWebtak)).append("\n");
    sb.append("    enableNonAdminUI: ").append(toIndentedString(enableNonAdminUI)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
