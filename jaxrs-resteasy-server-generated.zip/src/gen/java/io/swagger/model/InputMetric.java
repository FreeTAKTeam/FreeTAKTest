package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.Input;
import io.swagger.model.InputMetricBytesRecieveds;
import io.swagger.model.InputMetricReadsReceived;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class InputMetric   {
  private String id = null;  private Input input = null;  private InputMetricReadsReceived readsReceived = null;  private InputMetricReadsReceived messagesReceived = null;  private InputMetricReadsReceived numClients = null;  private InputMetricReadsReceived bytesRecieved = null;  private InputMetricBytesRecieveds bytesRecieveds = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("id")
  public String getId() {
    return id;
  }
  public void setId(String id) {
    this.id = id;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("input")
  public Input getInput() {
    return input;
  }
  public void setInput(Input input) {
    this.input = input;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("readsReceived")
  public InputMetricReadsReceived getReadsReceived() {
    return readsReceived;
  }
  public void setReadsReceived(InputMetricReadsReceived readsReceived) {
    this.readsReceived = readsReceived;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("messagesReceived")
  public InputMetricReadsReceived getMessagesReceived() {
    return messagesReceived;
  }
  public void setMessagesReceived(InputMetricReadsReceived messagesReceived) {
    this.messagesReceived = messagesReceived;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("numClients")
  public InputMetricReadsReceived getNumClients() {
    return numClients;
  }
  public void setNumClients(InputMetricReadsReceived numClients) {
    this.numClients = numClients;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("bytesRecieved")
  public InputMetricReadsReceived getBytesRecieved() {
    return bytesRecieved;
  }
  public void setBytesRecieved(InputMetricReadsReceived bytesRecieved) {
    this.bytesRecieved = bytesRecieved;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("bytesRecieveds")
  public InputMetricBytesRecieveds getBytesRecieveds() {
    return bytesRecieveds;
  }
  public void setBytesRecieveds(InputMetricBytesRecieveds bytesRecieveds) {
    this.bytesRecieveds = bytesRecieveds;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    InputMetric inputMetric = (InputMetric) o;
    return Objects.equals(id, inputMetric.id) &&
        Objects.equals(input, inputMetric.input) &&
        Objects.equals(readsReceived, inputMetric.readsReceived) &&
        Objects.equals(messagesReceived, inputMetric.messagesReceived) &&
        Objects.equals(numClients, inputMetric.numClients) &&
        Objects.equals(bytesRecieved, inputMetric.bytesRecieved) &&
        Objects.equals(bytesRecieveds, inputMetric.bytesRecieveds);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, input, readsReceived, messagesReceived, numClients, bytesRecieved, bytesRecieveds);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class InputMetric {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    input: ").append(toIndentedString(input)).append("\n");
    sb.append("    readsReceived: ").append(toIndentedString(readsReceived)).append("\n");
    sb.append("    messagesReceived: ").append(toIndentedString(messagesReceived)).append("\n");
    sb.append("    numClients: ").append(toIndentedString(numClients)).append("\n");
    sb.append("    bytesRecieved: ").append(toIndentedString(bytesRecieved)).append("\n");
    sb.append("    bytesRecieveds: ").append(toIndentedString(bytesRecieveds)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
