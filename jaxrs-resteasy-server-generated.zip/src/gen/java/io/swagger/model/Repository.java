package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.Connection;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class Repository   {
  private Connection connection = null;  private Boolean enable = null;  private Integer numDbConnections = null;  private Boolean connectionPoolAutoSize = null;  private Integer primaryKeyBatchSize = null;  private Integer insertionBatchSize = null;  private Boolean archive = null;  private String iconsetDir = null;  private Boolean enableCallsignAudit = null;  private Integer contactCacheMaxClearRateSeconds = null;  private Long dbTimeoutMs = null;  private Integer dbConnectionMaxLifetimeMs = null;  private Integer dbConnectionMaxIdleMs = null;  private Integer poolScaleFactor = null;

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("connection")
  @NotNull
  public Connection getConnection() {
    return connection;
  }
  public void setConnection(Connection connection) {
    this.connection = connection;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("enable")
  public Boolean isEnable() {
    return enable;
  }
  public void setEnable(Boolean enable) {
    this.enable = enable;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("numDbConnections")
  public Integer getNumDbConnections() {
    return numDbConnections;
  }
  public void setNumDbConnections(Integer numDbConnections) {
    this.numDbConnections = numDbConnections;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("connectionPoolAutoSize")
  public Boolean isConnectionPoolAutoSize() {
    return connectionPoolAutoSize;
  }
  public void setConnectionPoolAutoSize(Boolean connectionPoolAutoSize) {
    this.connectionPoolAutoSize = connectionPoolAutoSize;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("primaryKeyBatchSize")
  public Integer getPrimaryKeyBatchSize() {
    return primaryKeyBatchSize;
  }
  public void setPrimaryKeyBatchSize(Integer primaryKeyBatchSize) {
    this.primaryKeyBatchSize = primaryKeyBatchSize;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("insertionBatchSize")
  public Integer getInsertionBatchSize() {
    return insertionBatchSize;
  }
  public void setInsertionBatchSize(Integer insertionBatchSize) {
    this.insertionBatchSize = insertionBatchSize;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("archive")
  public Boolean isArchive() {
    return archive;
  }
  public void setArchive(Boolean archive) {
    this.archive = archive;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("iconsetDir")
  public String getIconsetDir() {
    return iconsetDir;
  }
  public void setIconsetDir(String iconsetDir) {
    this.iconsetDir = iconsetDir;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("enableCallsignAudit")
  public Boolean isEnableCallsignAudit() {
    return enableCallsignAudit;
  }
  public void setEnableCallsignAudit(Boolean enableCallsignAudit) {
    this.enableCallsignAudit = enableCallsignAudit;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("contactCacheMaxClearRateSeconds")
  public Integer getContactCacheMaxClearRateSeconds() {
    return contactCacheMaxClearRateSeconds;
  }
  public void setContactCacheMaxClearRateSeconds(Integer contactCacheMaxClearRateSeconds) {
    this.contactCacheMaxClearRateSeconds = contactCacheMaxClearRateSeconds;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("dbTimeoutMs")
  public Long getDbTimeoutMs() {
    return dbTimeoutMs;
  }
  public void setDbTimeoutMs(Long dbTimeoutMs) {
    this.dbTimeoutMs = dbTimeoutMs;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("dbConnectionMaxLifetimeMs")
  public Integer getDbConnectionMaxLifetimeMs() {
    return dbConnectionMaxLifetimeMs;
  }
  public void setDbConnectionMaxLifetimeMs(Integer dbConnectionMaxLifetimeMs) {
    this.dbConnectionMaxLifetimeMs = dbConnectionMaxLifetimeMs;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("dbConnectionMaxIdleMs")
  public Integer getDbConnectionMaxIdleMs() {
    return dbConnectionMaxIdleMs;
  }
  public void setDbConnectionMaxIdleMs(Integer dbConnectionMaxIdleMs) {
    this.dbConnectionMaxIdleMs = dbConnectionMaxIdleMs;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("poolScaleFactor")
  public Integer getPoolScaleFactor() {
    return poolScaleFactor;
  }
  public void setPoolScaleFactor(Integer poolScaleFactor) {
    this.poolScaleFactor = poolScaleFactor;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Repository repository = (Repository) o;
    return Objects.equals(connection, repository.connection) &&
        Objects.equals(enable, repository.enable) &&
        Objects.equals(numDbConnections, repository.numDbConnections) &&
        Objects.equals(connectionPoolAutoSize, repository.connectionPoolAutoSize) &&
        Objects.equals(primaryKeyBatchSize, repository.primaryKeyBatchSize) &&
        Objects.equals(insertionBatchSize, repository.insertionBatchSize) &&
        Objects.equals(archive, repository.archive) &&
        Objects.equals(iconsetDir, repository.iconsetDir) &&
        Objects.equals(enableCallsignAudit, repository.enableCallsignAudit) &&
        Objects.equals(contactCacheMaxClearRateSeconds, repository.contactCacheMaxClearRateSeconds) &&
        Objects.equals(dbTimeoutMs, repository.dbTimeoutMs) &&
        Objects.equals(dbConnectionMaxLifetimeMs, repository.dbConnectionMaxLifetimeMs) &&
        Objects.equals(dbConnectionMaxIdleMs, repository.dbConnectionMaxIdleMs) &&
        Objects.equals(poolScaleFactor, repository.poolScaleFactor);
  }

  @Override
  public int hashCode() {
    return Objects.hash(connection, enable, numDbConnections, connectionPoolAutoSize, primaryKeyBatchSize, insertionBatchSize, archive, iconsetDir, enableCallsignAudit, contactCacheMaxClearRateSeconds, dbTimeoutMs, dbConnectionMaxLifetimeMs, dbConnectionMaxIdleMs, poolScaleFactor);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Repository {\n");
    
    sb.append("    connection: ").append(toIndentedString(connection)).append("\n");
    sb.append("    enable: ").append(toIndentedString(enable)).append("\n");
    sb.append("    numDbConnections: ").append(toIndentedString(numDbConnections)).append("\n");
    sb.append("    connectionPoolAutoSize: ").append(toIndentedString(connectionPoolAutoSize)).append("\n");
    sb.append("    primaryKeyBatchSize: ").append(toIndentedString(primaryKeyBatchSize)).append("\n");
    sb.append("    insertionBatchSize: ").append(toIndentedString(insertionBatchSize)).append("\n");
    sb.append("    archive: ").append(toIndentedString(archive)).append("\n");
    sb.append("    iconsetDir: ").append(toIndentedString(iconsetDir)).append("\n");
    sb.append("    enableCallsignAudit: ").append(toIndentedString(enableCallsignAudit)).append("\n");
    sb.append("    contactCacheMaxClearRateSeconds: ").append(toIndentedString(contactCacheMaxClearRateSeconds)).append("\n");
    sb.append("    dbTimeoutMs: ").append(toIndentedString(dbTimeoutMs)).append("\n");
    sb.append("    dbConnectionMaxLifetimeMs: ").append(toIndentedString(dbConnectionMaxLifetimeMs)).append("\n");
    sb.append("    dbConnectionMaxIdleMs: ").append(toIndentedString(dbConnectionMaxIdleMs)).append("\n");
    sb.append("    poolScaleFactor: ").append(toIndentedString(poolScaleFactor)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
