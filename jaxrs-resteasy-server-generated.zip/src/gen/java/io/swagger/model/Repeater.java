package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.RepeatableType;
import java.util.List;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class Repeater   {
  private List<RepeatableType> repeatableType = new ArrayList<RepeatableType>();  private Boolean enable = null;  private Integer periodMillis = null;  private Integer staleDelayMillis = null;  private Integer maxAllowedRepeatables = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("repeatableType")
  public List<RepeatableType> getRepeatableType() {
    return repeatableType;
  }
  public void setRepeatableType(List<RepeatableType> repeatableType) {
    this.repeatableType = repeatableType;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("enable")
  public Boolean isEnable() {
    return enable;
  }
  public void setEnable(Boolean enable) {
    this.enable = enable;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("periodMillis")
  public Integer getPeriodMillis() {
    return periodMillis;
  }
  public void setPeriodMillis(Integer periodMillis) {
    this.periodMillis = periodMillis;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("staleDelayMillis")
  public Integer getStaleDelayMillis() {
    return staleDelayMillis;
  }
  public void setStaleDelayMillis(Integer staleDelayMillis) {
    this.staleDelayMillis = staleDelayMillis;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("maxAllowedRepeatables")
  public Integer getMaxAllowedRepeatables() {
    return maxAllowedRepeatables;
  }
  public void setMaxAllowedRepeatables(Integer maxAllowedRepeatables) {
    this.maxAllowedRepeatables = maxAllowedRepeatables;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Repeater repeater = (Repeater) o;
    return Objects.equals(repeatableType, repeater.repeatableType) &&
        Objects.equals(enable, repeater.enable) &&
        Objects.equals(periodMillis, repeater.periodMillis) &&
        Objects.equals(staleDelayMillis, repeater.staleDelayMillis) &&
        Objects.equals(maxAllowedRepeatables, repeater.maxAllowedRepeatables);
  }

  @Override
  public int hashCode() {
    return Objects.hash(repeatableType, enable, periodMillis, staleDelayMillis, maxAllowedRepeatables);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Repeater {\n");
    
    sb.append("    repeatableType: ").append(toIndentedString(repeatableType)).append("\n");
    sb.append("    enable: ").append(toIndentedString(enable)).append("\n");
    sb.append("    periodMillis: ").append(toIndentedString(periodMillis)).append("\n");
    sb.append("    staleDelayMillis: ").append(toIndentedString(staleDelayMillis)).append("\n");
    sb.append("    maxAllowedRepeatables: ").append(toIndentedString(maxAllowedRepeatables)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
