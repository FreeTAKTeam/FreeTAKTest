package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class Client   {
  private String clientId = null;  private String secret = null;  private String redirectUri = null;  private String resourceIds = null;  private String scope = null;  private String authorizedGrantTypes = null;  private String authorities = null;  private String autoapprove = null;  private Integer refreshTokenValidity = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("clientId")
  public String getClientId() {
    return clientId;
  }
  public void setClientId(String clientId) {
    this.clientId = clientId;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("secret")
  public String getSecret() {
    return secret;
  }
  public void setSecret(String secret) {
    this.secret = secret;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("redirectUri")
  public String getRedirectUri() {
    return redirectUri;
  }
  public void setRedirectUri(String redirectUri) {
    this.redirectUri = redirectUri;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("resourceIds")
  public String getResourceIds() {
    return resourceIds;
  }
  public void setResourceIds(String resourceIds) {
    this.resourceIds = resourceIds;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("scope")
  public String getScope() {
    return scope;
  }
  public void setScope(String scope) {
    this.scope = scope;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("authorizedGrantTypes")
  public String getAuthorizedGrantTypes() {
    return authorizedGrantTypes;
  }
  public void setAuthorizedGrantTypes(String authorizedGrantTypes) {
    this.authorizedGrantTypes = authorizedGrantTypes;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("authorities")
  public String getAuthorities() {
    return authorities;
  }
  public void setAuthorities(String authorities) {
    this.authorities = authorities;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("autoapprove")
  public String getAutoapprove() {
    return autoapprove;
  }
  public void setAutoapprove(String autoapprove) {
    this.autoapprove = autoapprove;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("refreshTokenValidity")
  public Integer getRefreshTokenValidity() {
    return refreshTokenValidity;
  }
  public void setRefreshTokenValidity(Integer refreshTokenValidity) {
    this.refreshTokenValidity = refreshTokenValidity;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Client client = (Client) o;
    return Objects.equals(clientId, client.clientId) &&
        Objects.equals(secret, client.secret) &&
        Objects.equals(redirectUri, client.redirectUri) &&
        Objects.equals(resourceIds, client.resourceIds) &&
        Objects.equals(scope, client.scope) &&
        Objects.equals(authorizedGrantTypes, client.authorizedGrantTypes) &&
        Objects.equals(authorities, client.authorities) &&
        Objects.equals(autoapprove, client.autoapprove) &&
        Objects.equals(refreshTokenValidity, client.refreshTokenValidity);
  }

  @Override
  public int hashCode() {
    return Objects.hash(clientId, secret, redirectUri, resourceIds, scope, authorizedGrantTypes, authorities, autoapprove, refreshTokenValidity);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Client {\n");
    
    sb.append("    clientId: ").append(toIndentedString(clientId)).append("\n");
    sb.append("    secret: ").append(toIndentedString(secret)).append("\n");
    sb.append("    redirectUri: ").append(toIndentedString(redirectUri)).append("\n");
    sb.append("    resourceIds: ").append(toIndentedString(resourceIds)).append("\n");
    sb.append("    scope: ").append(toIndentedString(scope)).append("\n");
    sb.append("    authorizedGrantTypes: ").append(toIndentedString(authorizedGrantTypes)).append("\n");
    sb.append("    authorities: ").append(toIndentedString(authorities)).append("\n");
    sb.append("    autoapprove: ").append(toIndentedString(autoapprove)).append("\n");
    sb.append("    refreshTokenValidity: ").append(toIndentedString(refreshTokenValidity)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
