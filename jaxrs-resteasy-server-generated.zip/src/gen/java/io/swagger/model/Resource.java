package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.Point;
import java.util.Date;
import java.util.List;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class Resource   {
  private String filename = null;  private List<String> keywords = new ArrayList<String>();  private String mimeType = null;  private String contentType = null;  private String name = null;  private Date submissionTime = null;  private String submitter = null;  private String uid = null;  private String creatorUid = null;  private String hash = null;  private Long size = null;  private String tool = null;  private Point location = null;  private Double latitude = null;  private Double longitude = null;  private Double altitude = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("filename")
  public String getFilename() {
    return filename;
  }
  public void setFilename(String filename) {
    this.filename = filename;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("keywords")
  public List<String> getKeywords() {
    return keywords;
  }
  public void setKeywords(List<String> keywords) {
    this.keywords = keywords;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("mimeType")
  public String getMimeType() {
    return mimeType;
  }
  public void setMimeType(String mimeType) {
    this.mimeType = mimeType;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("contentType")
  public String getContentType() {
    return contentType;
  }
  public void setContentType(String contentType) {
    this.contentType = contentType;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("name")
  public String getName() {
    return name;
  }
  public void setName(String name) {
    this.name = name;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("submissionTime")
  public Date getSubmissionTime() {
    return submissionTime;
  }
  public void setSubmissionTime(Date submissionTime) {
    this.submissionTime = submissionTime;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("submitter")
  public String getSubmitter() {
    return submitter;
  }
  public void setSubmitter(String submitter) {
    this.submitter = submitter;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("uid")
  public String getUid() {
    return uid;
  }
  public void setUid(String uid) {
    this.uid = uid;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("creatorUid")
  public String getCreatorUid() {
    return creatorUid;
  }
  public void setCreatorUid(String creatorUid) {
    this.creatorUid = creatorUid;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("hash")
  public String getHash() {
    return hash;
  }
  public void setHash(String hash) {
    this.hash = hash;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("size")
  public Long getSize() {
    return size;
  }
  public void setSize(Long size) {
    this.size = size;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("tool")
  public String getTool() {
    return tool;
  }
  public void setTool(String tool) {
    this.tool = tool;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("location")
  public Point getLocation() {
    return location;
  }
  public void setLocation(Point location) {
    this.location = location;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("latitude")
  public Double getLatitude() {
    return latitude;
  }
  public void setLatitude(Double latitude) {
    this.latitude = latitude;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("longitude")
  public Double getLongitude() {
    return longitude;
  }
  public void setLongitude(Double longitude) {
    this.longitude = longitude;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("altitude")
  public Double getAltitude() {
    return altitude;
  }
  public void setAltitude(Double altitude) {
    this.altitude = altitude;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Resource resource = (Resource) o;
    return Objects.equals(filename, resource.filename) &&
        Objects.equals(keywords, resource.keywords) &&
        Objects.equals(mimeType, resource.mimeType) &&
        Objects.equals(contentType, resource.contentType) &&
        Objects.equals(name, resource.name) &&
        Objects.equals(submissionTime, resource.submissionTime) &&
        Objects.equals(submitter, resource.submitter) &&
        Objects.equals(uid, resource.uid) &&
        Objects.equals(creatorUid, resource.creatorUid) &&
        Objects.equals(hash, resource.hash) &&
        Objects.equals(size, resource.size) &&
        Objects.equals(tool, resource.tool) &&
        Objects.equals(location, resource.location) &&
        Objects.equals(latitude, resource.latitude) &&
        Objects.equals(longitude, resource.longitude) &&
        Objects.equals(altitude, resource.altitude);
  }

  @Override
  public int hashCode() {
    return Objects.hash(filename, keywords, mimeType, contentType, name, submissionTime, submitter, uid, creatorUid, hash, size, tool, location, latitude, longitude, altitude);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Resource {\n");
    
    sb.append("    filename: ").append(toIndentedString(filename)).append("\n");
    sb.append("    keywords: ").append(toIndentedString(keywords)).append("\n");
    sb.append("    mimeType: ").append(toIndentedString(mimeType)).append("\n");
    sb.append("    contentType: ").append(toIndentedString(contentType)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    submissionTime: ").append(toIndentedString(submissionTime)).append("\n");
    sb.append("    submitter: ").append(toIndentedString(submitter)).append("\n");
    sb.append("    uid: ").append(toIndentedString(uid)).append("\n");
    sb.append("    creatorUid: ").append(toIndentedString(creatorUid)).append("\n");
    sb.append("    hash: ").append(toIndentedString(hash)).append("\n");
    sb.append("    size: ").append(toIndentedString(size)).append("\n");
    sb.append("    tool: ").append(toIndentedString(tool)).append("\n");
    sb.append("    location: ").append(toIndentedString(location)).append("\n");
    sb.append("    latitude: ").append(toIndentedString(latitude)).append("\n");
    sb.append("    longitude: ").append(toIndentedString(longitude)).append("\n");
    sb.append("    altitude: ").append(toIndentedString(altitude)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
