package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import java.util.List;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class ConnectionInfoCertPublicKey   {
  private List<byte[]> encoded = new ArrayList<byte[]>();  private String format = null;  private String algorithm = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("encoded")
  public List<byte[]> getEncoded() {
    return encoded;
  }
  public void setEncoded(List<byte[]> encoded) {
    this.encoded = encoded;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("format")
  public String getFormat() {
    return format;
  }
  public void setFormat(String format) {
    this.format = format;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("algorithm")
  public String getAlgorithm() {
    return algorithm;
  }
  public void setAlgorithm(String algorithm) {
    this.algorithm = algorithm;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ConnectionInfoCertPublicKey connectionInfoCertPublicKey = (ConnectionInfoCertPublicKey) o;
    return Objects.equals(encoded, connectionInfoCertPublicKey.encoded) &&
        Objects.equals(format, connectionInfoCertPublicKey.format) &&
        Objects.equals(algorithm, connectionInfoCertPublicKey.algorithm);
  }

  @Override
  public int hashCode() {
    return Objects.hash(encoded, format, algorithm);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ConnectionInfoCertPublicKey {\n");
    
    sb.append("    encoded: ").append(toIndentedString(encoded)).append("\n");
    sb.append("    format: ").append(toIndentedString(format)).append("\n");
    sb.append("    algorithm: ").append(toIndentedString(algorithm)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
