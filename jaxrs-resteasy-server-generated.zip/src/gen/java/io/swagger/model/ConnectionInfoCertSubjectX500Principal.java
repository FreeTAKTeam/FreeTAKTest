package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import java.util.List;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class ConnectionInfoCertSubjectX500Principal   {
  private String name = null;  private List<byte[]> encoded = new ArrayList<byte[]>();

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("name")
  public String getName() {
    return name;
  }
  public void setName(String name) {
    this.name = name;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("encoded")
  public List<byte[]> getEncoded() {
    return encoded;
  }
  public void setEncoded(List<byte[]> encoded) {
    this.encoded = encoded;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ConnectionInfoCertSubjectX500Principal connectionInfoCertSubjectX500Principal = (ConnectionInfoCertSubjectX500Principal) o;
    return Objects.equals(name, connectionInfoCertSubjectX500Principal.name) &&
        Objects.equals(encoded, connectionInfoCertSubjectX500Principal.encoded);
  }

  @Override
  public int hashCode() {
    return Objects.hash(name, encoded);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ConnectionInfoCertSubjectX500Principal {\n");
    
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    encoded: ").append(toIndentedString(encoded)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
