package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class InputMetricBytesRecieveds   {
  private Long opaque = null;  private Long acquire = null;  private Long release = null;  private Long andIncrement = null;  private Long andDecrement = null;  private Long plain = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("opaque")
  public Long getOpaque() {
    return opaque;
  }
  public void setOpaque(Long opaque) {
    this.opaque = opaque;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("acquire")
  public Long getAcquire() {
    return acquire;
  }
  public void setAcquire(Long acquire) {
    this.acquire = acquire;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("release")
  public Long getRelease() {
    return release;
  }
  public void setRelease(Long release) {
    this.release = release;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("andIncrement")
  public Long getAndIncrement() {
    return andIncrement;
  }
  public void setAndIncrement(Long andIncrement) {
    this.andIncrement = andIncrement;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("andDecrement")
  public Long getAndDecrement() {
    return andDecrement;
  }
  public void setAndDecrement(Long andDecrement) {
    this.andDecrement = andDecrement;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("plain")
  public Long getPlain() {
    return plain;
  }
  public void setPlain(Long plain) {
    this.plain = plain;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    InputMetricBytesRecieveds inputMetricBytesRecieveds = (InputMetricBytesRecieveds) o;
    return Objects.equals(opaque, inputMetricBytesRecieveds.opaque) &&
        Objects.equals(acquire, inputMetricBytesRecieveds.acquire) &&
        Objects.equals(release, inputMetricBytesRecieveds.release) &&
        Objects.equals(andIncrement, inputMetricBytesRecieveds.andIncrement) &&
        Objects.equals(andDecrement, inputMetricBytesRecieveds.andDecrement) &&
        Objects.equals(plain, inputMetricBytesRecieveds.plain);
  }

  @Override
  public int hashCode() {
    return Objects.hash(opaque, acquire, release, andIncrement, andDecrement, plain);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class InputMetricBytesRecieveds {\n");
    
    sb.append("    opaque: ").append(toIndentedString(opaque)).append("\n");
    sb.append("    acquire: ").append(toIndentedString(acquire)).append("\n");
    sb.append("    release: ").append(toIndentedString(release)).append("\n");
    sb.append("    andIncrement: ").append(toIndentedString(andIncrement)).append("\n");
    sb.append("    andDecrement: ").append(toIndentedString(andDecrement)).append("\n");
    sb.append("    plain: ").append(toIndentedString(plain)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
