package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class AuthServer   {
  private String name = null;  private String issuer = null;  private String clientId = null;  private String secret = null;  private String redirectUri = null;  private String scope = null;  private String authEndpoint = null;  private String tokenEndpoint = null;  private String tokenName = null;  private Boolean trustAllCerts = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("name")
  public String getName() {
    return name;
  }
  public void setName(String name) {
    this.name = name;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("issuer")
  public String getIssuer() {
    return issuer;
  }
  public void setIssuer(String issuer) {
    this.issuer = issuer;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("clientId")
  public String getClientId() {
    return clientId;
  }
  public void setClientId(String clientId) {
    this.clientId = clientId;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("secret")
  public String getSecret() {
    return secret;
  }
  public void setSecret(String secret) {
    this.secret = secret;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("redirectUri")
  public String getRedirectUri() {
    return redirectUri;
  }
  public void setRedirectUri(String redirectUri) {
    this.redirectUri = redirectUri;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("scope")
  public String getScope() {
    return scope;
  }
  public void setScope(String scope) {
    this.scope = scope;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("authEndpoint")
  public String getAuthEndpoint() {
    return authEndpoint;
  }
  public void setAuthEndpoint(String authEndpoint) {
    this.authEndpoint = authEndpoint;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("tokenEndpoint")
  public String getTokenEndpoint() {
    return tokenEndpoint;
  }
  public void setTokenEndpoint(String tokenEndpoint) {
    this.tokenEndpoint = tokenEndpoint;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("tokenName")
  public String getTokenName() {
    return tokenName;
  }
  public void setTokenName(String tokenName) {
    this.tokenName = tokenName;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("trustAllCerts")
  public Boolean isTrustAllCerts() {
    return trustAllCerts;
  }
  public void setTrustAllCerts(Boolean trustAllCerts) {
    this.trustAllCerts = trustAllCerts;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    AuthServer authServer = (AuthServer) o;
    return Objects.equals(name, authServer.name) &&
        Objects.equals(issuer, authServer.issuer) &&
        Objects.equals(clientId, authServer.clientId) &&
        Objects.equals(secret, authServer.secret) &&
        Objects.equals(redirectUri, authServer.redirectUri) &&
        Objects.equals(scope, authServer.scope) &&
        Objects.equals(authEndpoint, authServer.authEndpoint) &&
        Objects.equals(tokenEndpoint, authServer.tokenEndpoint) &&
        Objects.equals(tokenName, authServer.tokenName) &&
        Objects.equals(trustAllCerts, authServer.trustAllCerts);
  }

  @Override
  public int hashCode() {
    return Objects.hash(name, issuer, clientId, secret, redirectUri, scope, authEndpoint, tokenEndpoint, tokenName, trustAllCerts);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class AuthServer {\n");
    
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    issuer: ").append(toIndentedString(issuer)).append("\n");
    sb.append("    clientId: ").append(toIndentedString(clientId)).append("\n");
    sb.append("    secret: ").append(toIndentedString(secret)).append("\n");
    sb.append("    redirectUri: ").append(toIndentedString(redirectUri)).append("\n");
    sb.append("    scope: ").append(toIndentedString(scope)).append("\n");
    sb.append("    authEndpoint: ").append(toIndentedString(authEndpoint)).append("\n");
    sb.append("    tokenEndpoint: ").append(toIndentedString(tokenEndpoint)).append("\n");
    sb.append("    tokenName: ").append(toIndentedString(tokenName)).append("\n");
    sb.append("    trustAllCerts: ").append(toIndentedString(trustAllCerts)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
