package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import java.util.List;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class Ldap   {
  private List<String> filtergroup = new ArrayList<String>();  private String url = null;  private String userstring = null;  private Integer updateinterval = null;  private String groupprefix = null;  private String groupNameExtractorRegex = null;  /**
   * Gets or Sets style
   */
  public enum StyleEnum {
    AD("AD"),
    DS("DS");
    private String value;

    StyleEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }
  }
  private StyleEnum style = null;  /**
   * Gets or Sets ldapSecurityType
   */
  public enum LdapSecurityTypeEnum {
    NONE("NONE"),
    SIMPLE("SIMPLE");
    private String value;

    LdapSecurityTypeEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }
  }
  private LdapSecurityTypeEnum ldapSecurityType = null;  private String serviceAccountDN = null;  private String serviceAccountCredential = null;  private String groupObjectClass = null;  private String userObjectClass = null;  private String groupBaseRDN = null;  private String userBaseRDN = null;  private Boolean x509Groups = null;  private Boolean x509AddAnonymous = null;  private Boolean matchGroupInChain = null;  private Boolean postMissionEventsAsPublic = null;  private String ldapsTruststore = null;  private String ldapsTruststoreFile = null;  private String ldapsTruststorePass = null;  private String readOnlyGroup = null;  private String readGroupSuffix = null;  private String writeGroupSuffix = null;  private Boolean loginWithEmail = null;  private String callsignAttribute = null;  private String colorAttribute = null;  private String roleAttribute = null;  private Boolean enableConnectionPool = null;  private String connectionPoolTimeout = null;  private String dnAttributeName = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("filtergroup")
  public List<String> getFiltergroup() {
    return filtergroup;
  }
  public void setFiltergroup(List<String> filtergroup) {
    this.filtergroup = filtergroup;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("url")
  public String getUrl() {
    return url;
  }
  public void setUrl(String url) {
    this.url = url;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("userstring")
  public String getUserstring() {
    return userstring;
  }
  public void setUserstring(String userstring) {
    this.userstring = userstring;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("updateinterval")
  public Integer getUpdateinterval() {
    return updateinterval;
  }
  public void setUpdateinterval(Integer updateinterval) {
    this.updateinterval = updateinterval;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("groupprefix")
  public String getGroupprefix() {
    return groupprefix;
  }
  public void setGroupprefix(String groupprefix) {
    this.groupprefix = groupprefix;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("groupNameExtractorRegex")
  public String getGroupNameExtractorRegex() {
    return groupNameExtractorRegex;
  }
  public void setGroupNameExtractorRegex(String groupNameExtractorRegex) {
    this.groupNameExtractorRegex = groupNameExtractorRegex;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("style")
  public StyleEnum getStyle() {
    return style;
  }
  public void setStyle(StyleEnum style) {
    this.style = style;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("ldapSecurityType")
  public LdapSecurityTypeEnum getLdapSecurityType() {
    return ldapSecurityType;
  }
  public void setLdapSecurityType(LdapSecurityTypeEnum ldapSecurityType) {
    this.ldapSecurityType = ldapSecurityType;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("serviceAccountDN")
  public String getServiceAccountDN() {
    return serviceAccountDN;
  }
  public void setServiceAccountDN(String serviceAccountDN) {
    this.serviceAccountDN = serviceAccountDN;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("serviceAccountCredential")
  public String getServiceAccountCredential() {
    return serviceAccountCredential;
  }
  public void setServiceAccountCredential(String serviceAccountCredential) {
    this.serviceAccountCredential = serviceAccountCredential;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("groupObjectClass")
  public String getGroupObjectClass() {
    return groupObjectClass;
  }
  public void setGroupObjectClass(String groupObjectClass) {
    this.groupObjectClass = groupObjectClass;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("userObjectClass")
  public String getUserObjectClass() {
    return userObjectClass;
  }
  public void setUserObjectClass(String userObjectClass) {
    this.userObjectClass = userObjectClass;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("groupBaseRDN")
  public String getGroupBaseRDN() {
    return groupBaseRDN;
  }
  public void setGroupBaseRDN(String groupBaseRDN) {
    this.groupBaseRDN = groupBaseRDN;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("userBaseRDN")
  public String getUserBaseRDN() {
    return userBaseRDN;
  }
  public void setUserBaseRDN(String userBaseRDN) {
    this.userBaseRDN = userBaseRDN;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("x509Groups")
  public Boolean isX509Groups() {
    return x509Groups;
  }
  public void setX509Groups(Boolean x509Groups) {
    this.x509Groups = x509Groups;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("x509AddAnonymous")
  public Boolean isX509AddAnonymous() {
    return x509AddAnonymous;
  }
  public void setX509AddAnonymous(Boolean x509AddAnonymous) {
    this.x509AddAnonymous = x509AddAnonymous;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("matchGroupInChain")
  public Boolean isMatchGroupInChain() {
    return matchGroupInChain;
  }
  public void setMatchGroupInChain(Boolean matchGroupInChain) {
    this.matchGroupInChain = matchGroupInChain;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("postMissionEventsAsPublic")
  public Boolean isPostMissionEventsAsPublic() {
    return postMissionEventsAsPublic;
  }
  public void setPostMissionEventsAsPublic(Boolean postMissionEventsAsPublic) {
    this.postMissionEventsAsPublic = postMissionEventsAsPublic;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("ldapsTruststore")
  public String getLdapsTruststore() {
    return ldapsTruststore;
  }
  public void setLdapsTruststore(String ldapsTruststore) {
    this.ldapsTruststore = ldapsTruststore;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("ldapsTruststoreFile")
  public String getLdapsTruststoreFile() {
    return ldapsTruststoreFile;
  }
  public void setLdapsTruststoreFile(String ldapsTruststoreFile) {
    this.ldapsTruststoreFile = ldapsTruststoreFile;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("ldapsTruststorePass")
  public String getLdapsTruststorePass() {
    return ldapsTruststorePass;
  }
  public void setLdapsTruststorePass(String ldapsTruststorePass) {
    this.ldapsTruststorePass = ldapsTruststorePass;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("readOnlyGroup")
  public String getReadOnlyGroup() {
    return readOnlyGroup;
  }
  public void setReadOnlyGroup(String readOnlyGroup) {
    this.readOnlyGroup = readOnlyGroup;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("readGroupSuffix")
  public String getReadGroupSuffix() {
    return readGroupSuffix;
  }
  public void setReadGroupSuffix(String readGroupSuffix) {
    this.readGroupSuffix = readGroupSuffix;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("writeGroupSuffix")
  public String getWriteGroupSuffix() {
    return writeGroupSuffix;
  }
  public void setWriteGroupSuffix(String writeGroupSuffix) {
    this.writeGroupSuffix = writeGroupSuffix;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("loginWithEmail")
  public Boolean isLoginWithEmail() {
    return loginWithEmail;
  }
  public void setLoginWithEmail(Boolean loginWithEmail) {
    this.loginWithEmail = loginWithEmail;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("callsignAttribute")
  public String getCallsignAttribute() {
    return callsignAttribute;
  }
  public void setCallsignAttribute(String callsignAttribute) {
    this.callsignAttribute = callsignAttribute;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("colorAttribute")
  public String getColorAttribute() {
    return colorAttribute;
  }
  public void setColorAttribute(String colorAttribute) {
    this.colorAttribute = colorAttribute;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("roleAttribute")
  public String getRoleAttribute() {
    return roleAttribute;
  }
  public void setRoleAttribute(String roleAttribute) {
    this.roleAttribute = roleAttribute;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("enableConnectionPool")
  public Boolean isEnableConnectionPool() {
    return enableConnectionPool;
  }
  public void setEnableConnectionPool(Boolean enableConnectionPool) {
    this.enableConnectionPool = enableConnectionPool;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("connectionPoolTimeout")
  public String getConnectionPoolTimeout() {
    return connectionPoolTimeout;
  }
  public void setConnectionPoolTimeout(String connectionPoolTimeout) {
    this.connectionPoolTimeout = connectionPoolTimeout;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("dnAttributeName")
  public String getDnAttributeName() {
    return dnAttributeName;
  }
  public void setDnAttributeName(String dnAttributeName) {
    this.dnAttributeName = dnAttributeName;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Ldap ldap = (Ldap) o;
    return Objects.equals(filtergroup, ldap.filtergroup) &&
        Objects.equals(url, ldap.url) &&
        Objects.equals(userstring, ldap.userstring) &&
        Objects.equals(updateinterval, ldap.updateinterval) &&
        Objects.equals(groupprefix, ldap.groupprefix) &&
        Objects.equals(groupNameExtractorRegex, ldap.groupNameExtractorRegex) &&
        Objects.equals(style, ldap.style) &&
        Objects.equals(ldapSecurityType, ldap.ldapSecurityType) &&
        Objects.equals(serviceAccountDN, ldap.serviceAccountDN) &&
        Objects.equals(serviceAccountCredential, ldap.serviceAccountCredential) &&
        Objects.equals(groupObjectClass, ldap.groupObjectClass) &&
        Objects.equals(userObjectClass, ldap.userObjectClass) &&
        Objects.equals(groupBaseRDN, ldap.groupBaseRDN) &&
        Objects.equals(userBaseRDN, ldap.userBaseRDN) &&
        Objects.equals(x509Groups, ldap.x509Groups) &&
        Objects.equals(x509AddAnonymous, ldap.x509AddAnonymous) &&
        Objects.equals(matchGroupInChain, ldap.matchGroupInChain) &&
        Objects.equals(postMissionEventsAsPublic, ldap.postMissionEventsAsPublic) &&
        Objects.equals(ldapsTruststore, ldap.ldapsTruststore) &&
        Objects.equals(ldapsTruststoreFile, ldap.ldapsTruststoreFile) &&
        Objects.equals(ldapsTruststorePass, ldap.ldapsTruststorePass) &&
        Objects.equals(readOnlyGroup, ldap.readOnlyGroup) &&
        Objects.equals(readGroupSuffix, ldap.readGroupSuffix) &&
        Objects.equals(writeGroupSuffix, ldap.writeGroupSuffix) &&
        Objects.equals(loginWithEmail, ldap.loginWithEmail) &&
        Objects.equals(callsignAttribute, ldap.callsignAttribute) &&
        Objects.equals(colorAttribute, ldap.colorAttribute) &&
        Objects.equals(roleAttribute, ldap.roleAttribute) &&
        Objects.equals(enableConnectionPool, ldap.enableConnectionPool) &&
        Objects.equals(connectionPoolTimeout, ldap.connectionPoolTimeout) &&
        Objects.equals(dnAttributeName, ldap.dnAttributeName);
  }

  @Override
  public int hashCode() {
    return Objects.hash(filtergroup, url, userstring, updateinterval, groupprefix, groupNameExtractorRegex, style, ldapSecurityType, serviceAccountDN, serviceAccountCredential, groupObjectClass, userObjectClass, groupBaseRDN, userBaseRDN, x509Groups, x509AddAnonymous, matchGroupInChain, postMissionEventsAsPublic, ldapsTruststore, ldapsTruststoreFile, ldapsTruststorePass, readOnlyGroup, readGroupSuffix, writeGroupSuffix, loginWithEmail, callsignAttribute, colorAttribute, roleAttribute, enableConnectionPool, connectionPoolTimeout, dnAttributeName);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Ldap {\n");
    
    sb.append("    filtergroup: ").append(toIndentedString(filtergroup)).append("\n");
    sb.append("    url: ").append(toIndentedString(url)).append("\n");
    sb.append("    userstring: ").append(toIndentedString(userstring)).append("\n");
    sb.append("    updateinterval: ").append(toIndentedString(updateinterval)).append("\n");
    sb.append("    groupprefix: ").append(toIndentedString(groupprefix)).append("\n");
    sb.append("    groupNameExtractorRegex: ").append(toIndentedString(groupNameExtractorRegex)).append("\n");
    sb.append("    style: ").append(toIndentedString(style)).append("\n");
    sb.append("    ldapSecurityType: ").append(toIndentedString(ldapSecurityType)).append("\n");
    sb.append("    serviceAccountDN: ").append(toIndentedString(serviceAccountDN)).append("\n");
    sb.append("    serviceAccountCredential: ").append(toIndentedString(serviceAccountCredential)).append("\n");
    sb.append("    groupObjectClass: ").append(toIndentedString(groupObjectClass)).append("\n");
    sb.append("    userObjectClass: ").append(toIndentedString(userObjectClass)).append("\n");
    sb.append("    groupBaseRDN: ").append(toIndentedString(groupBaseRDN)).append("\n");
    sb.append("    userBaseRDN: ").append(toIndentedString(userBaseRDN)).append("\n");
    sb.append("    x509Groups: ").append(toIndentedString(x509Groups)).append("\n");
    sb.append("    x509AddAnonymous: ").append(toIndentedString(x509AddAnonymous)).append("\n");
    sb.append("    matchGroupInChain: ").append(toIndentedString(matchGroupInChain)).append("\n");
    sb.append("    postMissionEventsAsPublic: ").append(toIndentedString(postMissionEventsAsPublic)).append("\n");
    sb.append("    ldapsTruststore: ").append(toIndentedString(ldapsTruststore)).append("\n");
    sb.append("    ldapsTruststoreFile: ").append(toIndentedString(ldapsTruststoreFile)).append("\n");
    sb.append("    ldapsTruststorePass: ").append(toIndentedString(ldapsTruststorePass)).append("\n");
    sb.append("    readOnlyGroup: ").append(toIndentedString(readOnlyGroup)).append("\n");
    sb.append("    readGroupSuffix: ").append(toIndentedString(readGroupSuffix)).append("\n");
    sb.append("    writeGroupSuffix: ").append(toIndentedString(writeGroupSuffix)).append("\n");
    sb.append("    loginWithEmail: ").append(toIndentedString(loginWithEmail)).append("\n");
    sb.append("    callsignAttribute: ").append(toIndentedString(callsignAttribute)).append("\n");
    sb.append("    colorAttribute: ").append(toIndentedString(colorAttribute)).append("\n");
    sb.append("    roleAttribute: ").append(toIndentedString(roleAttribute)).append("\n");
    sb.append("    enableConnectionPool: ").append(toIndentedString(enableConnectionPool)).append("\n");
    sb.append("    connectionPoolTimeout: ").append(toIndentedString(connectionPoolTimeout)).append("\n");
    sb.append("    dnAttributeName: ").append(toIndentedString(dnAttributeName)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
