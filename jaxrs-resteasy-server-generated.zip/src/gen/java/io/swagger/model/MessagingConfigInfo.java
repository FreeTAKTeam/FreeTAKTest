package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class MessagingConfigInfo   {
  private Boolean latestSA = null;  private Integer numDbConnections = null;  private Integer numAutoDbConnections = null;  private Boolean connectionPoolAutoSize = null;  private Boolean archive = null;  private String dbUsername = null;  private String dbPassword = null;  private String dbUrl = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("latestSA")
  public Boolean isLatestSA() {
    return latestSA;
  }
  public void setLatestSA(Boolean latestSA) {
    this.latestSA = latestSA;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("numDbConnections")
  public Integer getNumDbConnections() {
    return numDbConnections;
  }
  public void setNumDbConnections(Integer numDbConnections) {
    this.numDbConnections = numDbConnections;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("numAutoDbConnections")
  public Integer getNumAutoDbConnections() {
    return numAutoDbConnections;
  }
  public void setNumAutoDbConnections(Integer numAutoDbConnections) {
    this.numAutoDbConnections = numAutoDbConnections;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("connectionPoolAutoSize")
  public Boolean isConnectionPoolAutoSize() {
    return connectionPoolAutoSize;
  }
  public void setConnectionPoolAutoSize(Boolean connectionPoolAutoSize) {
    this.connectionPoolAutoSize = connectionPoolAutoSize;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("archive")
  public Boolean isArchive() {
    return archive;
  }
  public void setArchive(Boolean archive) {
    this.archive = archive;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("dbUsername")
  public String getDbUsername() {
    return dbUsername;
  }
  public void setDbUsername(String dbUsername) {
    this.dbUsername = dbUsername;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("dbPassword")
  public String getDbPassword() {
    return dbPassword;
  }
  public void setDbPassword(String dbPassword) {
    this.dbPassword = dbPassword;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("dbUrl")
  public String getDbUrl() {
    return dbUrl;
  }
  public void setDbUrl(String dbUrl) {
    this.dbUrl = dbUrl;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    MessagingConfigInfo messagingConfigInfo = (MessagingConfigInfo) o;
    return Objects.equals(latestSA, messagingConfigInfo.latestSA) &&
        Objects.equals(numDbConnections, messagingConfigInfo.numDbConnections) &&
        Objects.equals(numAutoDbConnections, messagingConfigInfo.numAutoDbConnections) &&
        Objects.equals(connectionPoolAutoSize, messagingConfigInfo.connectionPoolAutoSize) &&
        Objects.equals(archive, messagingConfigInfo.archive) &&
        Objects.equals(dbUsername, messagingConfigInfo.dbUsername) &&
        Objects.equals(dbPassword, messagingConfigInfo.dbPassword) &&
        Objects.equals(dbUrl, messagingConfigInfo.dbUrl);
  }

  @Override
  public int hashCode() {
    return Objects.hash(latestSA, numDbConnections, numAutoDbConnections, connectionPoolAutoSize, archive, dbUsername, dbPassword, dbUrl);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class MessagingConfigInfo {\n");
    
    sb.append("    latestSA: ").append(toIndentedString(latestSA)).append("\n");
    sb.append("    numDbConnections: ").append(toIndentedString(numDbConnections)).append("\n");
    sb.append("    numAutoDbConnections: ").append(toIndentedString(numAutoDbConnections)).append("\n");
    sb.append("    connectionPoolAutoSize: ").append(toIndentedString(connectionPoolAutoSize)).append("\n");
    sb.append("    archive: ").append(toIndentedString(archive)).append("\n");
    sb.append("    dbUsername: ").append(toIndentedString(dbUsername)).append("\n");
    sb.append("    dbPassword: ").append(toIndentedString(dbPassword)).append("\n");
    sb.append("    dbUrl: ").append(toIndentedString(dbUrl)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
