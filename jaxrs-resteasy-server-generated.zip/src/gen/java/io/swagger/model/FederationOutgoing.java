package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class FederationOutgoing   {
  private String displayName = null;  private String address = null;  private Integer port = null;  private Boolean enabled = null;  private Integer protocolVersion = null;  private Integer reconnectInterval = null;  private String filter = null;  private Integer maxFrameSize = null;  private String fallback = null;  private Integer maxRetries = null;  private Boolean unlimitedRetries = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("displayName")
  public String getDisplayName() {
    return displayName;
  }
  public void setDisplayName(String displayName) {
    this.displayName = displayName;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("address")
  public String getAddress() {
    return address;
  }
  public void setAddress(String address) {
    this.address = address;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("port")
  public Integer getPort() {
    return port;
  }
  public void setPort(Integer port) {
    this.port = port;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("enabled")
  public Boolean isEnabled() {
    return enabled;
  }
  public void setEnabled(Boolean enabled) {
    this.enabled = enabled;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("protocolVersion")
  public Integer getProtocolVersion() {
    return protocolVersion;
  }
  public void setProtocolVersion(Integer protocolVersion) {
    this.protocolVersion = protocolVersion;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("reconnectInterval")
  public Integer getReconnectInterval() {
    return reconnectInterval;
  }
  public void setReconnectInterval(Integer reconnectInterval) {
    this.reconnectInterval = reconnectInterval;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("filter")
  public String getFilter() {
    return filter;
  }
  public void setFilter(String filter) {
    this.filter = filter;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("maxFrameSize")
  public Integer getMaxFrameSize() {
    return maxFrameSize;
  }
  public void setMaxFrameSize(Integer maxFrameSize) {
    this.maxFrameSize = maxFrameSize;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("fallback")
  public String getFallback() {
    return fallback;
  }
  public void setFallback(String fallback) {
    this.fallback = fallback;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("maxRetries")
  public Integer getMaxRetries() {
    return maxRetries;
  }
  public void setMaxRetries(Integer maxRetries) {
    this.maxRetries = maxRetries;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("unlimitedRetries")
  public Boolean isUnlimitedRetries() {
    return unlimitedRetries;
  }
  public void setUnlimitedRetries(Boolean unlimitedRetries) {
    this.unlimitedRetries = unlimitedRetries;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    FederationOutgoing federationOutgoing = (FederationOutgoing) o;
    return Objects.equals(displayName, federationOutgoing.displayName) &&
        Objects.equals(address, federationOutgoing.address) &&
        Objects.equals(port, federationOutgoing.port) &&
        Objects.equals(enabled, federationOutgoing.enabled) &&
        Objects.equals(protocolVersion, federationOutgoing.protocolVersion) &&
        Objects.equals(reconnectInterval, federationOutgoing.reconnectInterval) &&
        Objects.equals(filter, federationOutgoing.filter) &&
        Objects.equals(maxFrameSize, federationOutgoing.maxFrameSize) &&
        Objects.equals(fallback, federationOutgoing.fallback) &&
        Objects.equals(maxRetries, federationOutgoing.maxRetries) &&
        Objects.equals(unlimitedRetries, federationOutgoing.unlimitedRetries);
  }

  @Override
  public int hashCode() {
    return Objects.hash(displayName, address, port, enabled, protocolVersion, reconnectInterval, filter, maxFrameSize, fallback, maxRetries, unlimitedRetries);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class FederationOutgoing {\n");
    
    sb.append("    displayName: ").append(toIndentedString(displayName)).append("\n");
    sb.append("    address: ").append(toIndentedString(address)).append("\n");
    sb.append("    port: ").append(toIndentedString(port)).append("\n");
    sb.append("    enabled: ").append(toIndentedString(enabled)).append("\n");
    sb.append("    protocolVersion: ").append(toIndentedString(protocolVersion)).append("\n");
    sb.append("    reconnectInterval: ").append(toIndentedString(reconnectInterval)).append("\n");
    sb.append("    filter: ").append(toIndentedString(filter)).append("\n");
    sb.append("    maxFrameSize: ").append(toIndentedString(maxFrameSize)).append("\n");
    sb.append("    fallback: ").append(toIndentedString(fallback)).append("\n");
    sb.append("    maxRetries: ").append(toIndentedString(maxRetries)).append("\n");
    sb.append("    unlimitedRetries: ").append(toIndentedString(unlimitedRetries)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
