package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import java.util.UUID;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class PluginInfo   {
  private String name = null;  private String description = null;  private String className = null;  private String version = null;  private String tag = null;  private UUID id = null;  private String exceptionMessage = null;  private Boolean archiveEnabled = null;  private Boolean enabled = null;  private Boolean sender = null;  private Boolean interceptor = null;  private Boolean started = null;  private Boolean receiver = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("name")
  public String getName() {
    return name;
  }
  public void setName(String name) {
    this.name = name;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("description")
  public String getDescription() {
    return description;
  }
  public void setDescription(String description) {
    this.description = description;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("className")
  public String getClassName() {
    return className;
  }
  public void setClassName(String className) {
    this.className = className;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("version")
  public String getVersion() {
    return version;
  }
  public void setVersion(String version) {
    this.version = version;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("tag")
  public String getTag() {
    return tag;
  }
  public void setTag(String tag) {
    this.tag = tag;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("id")
  public UUID getId() {
    return id;
  }
  public void setId(UUID id) {
    this.id = id;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("exceptionMessage")
  public String getExceptionMessage() {
    return exceptionMessage;
  }
  public void setExceptionMessage(String exceptionMessage) {
    this.exceptionMessage = exceptionMessage;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("archiveEnabled")
  public Boolean isArchiveEnabled() {
    return archiveEnabled;
  }
  public void setArchiveEnabled(Boolean archiveEnabled) {
    this.archiveEnabled = archiveEnabled;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("enabled")
  public Boolean isEnabled() {
    return enabled;
  }
  public void setEnabled(Boolean enabled) {
    this.enabled = enabled;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("sender")
  public Boolean isSender() {
    return sender;
  }
  public void setSender(Boolean sender) {
    this.sender = sender;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("interceptor")
  public Boolean isInterceptor() {
    return interceptor;
  }
  public void setInterceptor(Boolean interceptor) {
    this.interceptor = interceptor;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("started")
  public Boolean isStarted() {
    return started;
  }
  public void setStarted(Boolean started) {
    this.started = started;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("receiver")
  public Boolean isReceiver() {
    return receiver;
  }
  public void setReceiver(Boolean receiver) {
    this.receiver = receiver;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    PluginInfo pluginInfo = (PluginInfo) o;
    return Objects.equals(name, pluginInfo.name) &&
        Objects.equals(description, pluginInfo.description) &&
        Objects.equals(className, pluginInfo.className) &&
        Objects.equals(version, pluginInfo.version) &&
        Objects.equals(tag, pluginInfo.tag) &&
        Objects.equals(id, pluginInfo.id) &&
        Objects.equals(exceptionMessage, pluginInfo.exceptionMessage) &&
        Objects.equals(archiveEnabled, pluginInfo.archiveEnabled) &&
        Objects.equals(enabled, pluginInfo.enabled) &&
        Objects.equals(sender, pluginInfo.sender) &&
        Objects.equals(interceptor, pluginInfo.interceptor) &&
        Objects.equals(started, pluginInfo.started) &&
        Objects.equals(receiver, pluginInfo.receiver);
  }

  @Override
  public int hashCode() {
    return Objects.hash(name, description, className, version, tag, id, exceptionMessage, archiveEnabled, enabled, sender, interceptor, started, receiver);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PluginInfo {\n");
    
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    description: ").append(toIndentedString(description)).append("\n");
    sb.append("    className: ").append(toIndentedString(className)).append("\n");
    sb.append("    version: ").append(toIndentedString(version)).append("\n");
    sb.append("    tag: ").append(toIndentedString(tag)).append("\n");
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    exceptionMessage: ").append(toIndentedString(exceptionMessage)).append("\n");
    sb.append("    archiveEnabled: ").append(toIndentedString(archiveEnabled)).append("\n");
    sb.append("    enabled: ").append(toIndentedString(enabled)).append("\n");
    sb.append("    sender: ").append(toIndentedString(sender)).append("\n");
    sb.append("    interceptor: ").append(toIndentedString(interceptor)).append("\n");
    sb.append("    started: ").append(toIndentedString(started)).append("\n");
    sb.append("    receiver: ").append(toIndentedString(receiver)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
