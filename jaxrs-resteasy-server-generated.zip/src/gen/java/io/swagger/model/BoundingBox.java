package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class BoundingBox   {
  private Double minLongitude = null;  private Double minLatitude = null;  private Double maxLongitude = null;  private Double maxLatitude = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("minLongitude")
  public Double getMinLongitude() {
    return minLongitude;
  }
  public void setMinLongitude(Double minLongitude) {
    this.minLongitude = minLongitude;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("minLatitude")
  public Double getMinLatitude() {
    return minLatitude;
  }
  public void setMinLatitude(Double minLatitude) {
    this.minLatitude = minLatitude;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("maxLongitude")
  public Double getMaxLongitude() {
    return maxLongitude;
  }
  public void setMaxLongitude(Double maxLongitude) {
    this.maxLongitude = maxLongitude;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("maxLatitude")
  public Double getMaxLatitude() {
    return maxLatitude;
  }
  public void setMaxLatitude(Double maxLatitude) {
    this.maxLatitude = maxLatitude;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    BoundingBox boundingBox = (BoundingBox) o;
    return Objects.equals(minLongitude, boundingBox.minLongitude) &&
        Objects.equals(minLatitude, boundingBox.minLatitude) &&
        Objects.equals(maxLongitude, boundingBox.maxLongitude) &&
        Objects.equals(maxLatitude, boundingBox.maxLatitude);
  }

  @Override
  public int hashCode() {
    return Objects.hash(minLongitude, minLatitude, maxLongitude, maxLatitude);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class BoundingBox {\n");
    
    sb.append("    minLongitude: ").append(toIndentedString(minLongitude)).append("\n");
    sb.append("    minLatitude: ").append(toIndentedString(minLatitude)).append("\n");
    sb.append("    maxLongitude: ").append(toIndentedString(maxLongitude)).append("\n");
    sb.append("    maxLatitude: ").append(toIndentedString(maxLatitude)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
