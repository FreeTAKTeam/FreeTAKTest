package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class MissionFeed   {
  private String dataFeedUid = null;  private String filterBbox = null;  private String filterType = null;  private String filterCallsign = null;  private String uid = null;  private String name = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("dataFeedUid")
  public String getDataFeedUid() {
    return dataFeedUid;
  }
  public void setDataFeedUid(String dataFeedUid) {
    this.dataFeedUid = dataFeedUid;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("filterBbox")
  public String getFilterBbox() {
    return filterBbox;
  }
  public void setFilterBbox(String filterBbox) {
    this.filterBbox = filterBbox;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("filterType")
  public String getFilterType() {
    return filterType;
  }
  public void setFilterType(String filterType) {
    this.filterType = filterType;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("filterCallsign")
  public String getFilterCallsign() {
    return filterCallsign;
  }
  public void setFilterCallsign(String filterCallsign) {
    this.filterCallsign = filterCallsign;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("uid")
  public String getUid() {
    return uid;
  }
  public void setUid(String uid) {
    this.uid = uid;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("name")
  public String getName() {
    return name;
  }
  public void setName(String name) {
    this.name = name;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    MissionFeed missionFeed = (MissionFeed) o;
    return Objects.equals(dataFeedUid, missionFeed.dataFeedUid) &&
        Objects.equals(filterBbox, missionFeed.filterBbox) &&
        Objects.equals(filterType, missionFeed.filterType) &&
        Objects.equals(filterCallsign, missionFeed.filterCallsign) &&
        Objects.equals(uid, missionFeed.uid) &&
        Objects.equals(name, missionFeed.name);
  }

  @Override
  public int hashCode() {
    return Objects.hash(dataFeedUid, filterBbox, filterType, filterCallsign, uid, name);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class MissionFeed {\n");
    
    sb.append("    dataFeedUid: ").append(toIndentedString(dataFeedUid)).append("\n");
    sb.append("    filterBbox: ").append(toIndentedString(filterBbox)).append("\n");
    sb.append("    filterType: ").append(toIndentedString(filterType)).append("\n");
    sb.append("    filterCallsign: ").append(toIndentedString(filterCallsign)).append("\n");
    sb.append("    uid: ").append(toIndentedString(uid)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
