package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class TmpStaticSub   {
  private String uid = null;  private String protocol = null;  private String subaddr = null;  private String subport = null;  private String to = null;  private String xpath = null;  private String filterGroups = null;  private String iface = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("uid")
  public String getUid() {
    return uid;
  }
  public void setUid(String uid) {
    this.uid = uid;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("protocol")
  public String getProtocol() {
    return protocol;
  }
  public void setProtocol(String protocol) {
    this.protocol = protocol;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("subaddr")
  public String getSubaddr() {
    return subaddr;
  }
  public void setSubaddr(String subaddr) {
    this.subaddr = subaddr;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("subport")
  public String getSubport() {
    return subport;
  }
  public void setSubport(String subport) {
    this.subport = subport;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("to")
  public String getTo() {
    return to;
  }
  public void setTo(String to) {
    this.to = to;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("xpath")
  public String getXpath() {
    return xpath;
  }
  public void setXpath(String xpath) {
    this.xpath = xpath;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("filterGroups")
  public String getFilterGroups() {
    return filterGroups;
  }
  public void setFilterGroups(String filterGroups) {
    this.filterGroups = filterGroups;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("iface")
  public String getIface() {
    return iface;
  }
  public void setIface(String iface) {
    this.iface = iface;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    TmpStaticSub tmpStaticSub = (TmpStaticSub) o;
    return Objects.equals(uid, tmpStaticSub.uid) &&
        Objects.equals(protocol, tmpStaticSub.protocol) &&
        Objects.equals(subaddr, tmpStaticSub.subaddr) &&
        Objects.equals(subport, tmpStaticSub.subport) &&
        Objects.equals(to, tmpStaticSub.to) &&
        Objects.equals(xpath, tmpStaticSub.xpath) &&
        Objects.equals(filterGroups, tmpStaticSub.filterGroups) &&
        Objects.equals(iface, tmpStaticSub.iface);
  }

  @Override
  public int hashCode() {
    return Objects.hash(uid, protocol, subaddr, subport, to, xpath, filterGroups, iface);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class TmpStaticSub {\n");
    
    sb.append("    uid: ").append(toIndentedString(uid)).append("\n");
    sb.append("    protocol: ").append(toIndentedString(protocol)).append("\n");
    sb.append("    subaddr: ").append(toIndentedString(subaddr)).append("\n");
    sb.append("    subport: ").append(toIndentedString(subport)).append("\n");
    sb.append("    to: ").append(toIndentedString(to)).append("\n");
    sb.append("    xpath: ").append(toIndentedString(xpath)).append("\n");
    sb.append("    filterGroups: ").append(toIndentedString(filterGroups)).append("\n");
    sb.append("    iface: ").append(toIndentedString(iface)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
