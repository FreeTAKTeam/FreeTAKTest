package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.MissionRole;
import java.util.Date;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class MissionInvitation   {
  private String missionName = null;  private String invitee = null;  private String type = null;  private String creatorUid = null;  private Date createTime = null;  private String token = null;  private MissionRole role = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("missionName")
  public String getMissionName() {
    return missionName;
  }
  public void setMissionName(String missionName) {
    this.missionName = missionName;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("invitee")
  public String getInvitee() {
    return invitee;
  }
  public void setInvitee(String invitee) {
    this.invitee = invitee;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("type")
  public String getType() {
    return type;
  }
  public void setType(String type) {
    this.type = type;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("creatorUid")
  public String getCreatorUid() {
    return creatorUid;
  }
  public void setCreatorUid(String creatorUid) {
    this.creatorUid = creatorUid;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("createTime")
  public Date getCreateTime() {
    return createTime;
  }
  public void setCreateTime(Date createTime) {
    this.createTime = createTime;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("token")
  public String getToken() {
    return token;
  }
  public void setToken(String token) {
    this.token = token;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("role")
  public MissionRole getRole() {
    return role;
  }
  public void setRole(MissionRole role) {
    this.role = role;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    MissionInvitation missionInvitation = (MissionInvitation) o;
    return Objects.equals(missionName, missionInvitation.missionName) &&
        Objects.equals(invitee, missionInvitation.invitee) &&
        Objects.equals(type, missionInvitation.type) &&
        Objects.equals(creatorUid, missionInvitation.creatorUid) &&
        Objects.equals(createTime, missionInvitation.createTime) &&
        Objects.equals(token, missionInvitation.token) &&
        Objects.equals(role, missionInvitation.role);
  }

  @Override
  public int hashCode() {
    return Objects.hash(missionName, invitee, type, creatorUid, createTime, token, role);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class MissionInvitation {\n");
    
    sb.append("    missionName: ").append(toIndentedString(missionName)).append("\n");
    sb.append("    invitee: ").append(toIndentedString(invitee)).append("\n");
    sb.append("    type: ").append(toIndentedString(type)).append("\n");
    sb.append("    creatorUid: ").append(toIndentedString(creatorUid)).append("\n");
    sb.append("    createTime: ").append(toIndentedString(createTime)).append("\n");
    sb.append("    token: ").append(toIndentedString(token)).append("\n");
    sb.append("    role: ").append(toIndentedString(role)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
