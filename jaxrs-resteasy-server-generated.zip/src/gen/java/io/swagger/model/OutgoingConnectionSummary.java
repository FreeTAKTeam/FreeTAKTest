package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.ConnectionInfoSummary;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class OutgoingConnectionSummary   {
  private ConnectionInfoSummary connectionInfoSummary = null;  private String address = null;  private Integer port = null;  private String displayName = null;  private Boolean enabled = null;  private Integer protocolVersion = null;  private Integer reconnectInterval = null;  private String fallback = null;  private Integer maxRetries = null;  private Boolean unlimitedRetries = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("connectionInfoSummary")
  public ConnectionInfoSummary getConnectionInfoSummary() {
    return connectionInfoSummary;
  }
  public void setConnectionInfoSummary(ConnectionInfoSummary connectionInfoSummary) {
    this.connectionInfoSummary = connectionInfoSummary;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("address")
  public String getAddress() {
    return address;
  }
  public void setAddress(String address) {
    this.address = address;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("port")
  public Integer getPort() {
    return port;
  }
  public void setPort(Integer port) {
    this.port = port;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("displayName")
  public String getDisplayName() {
    return displayName;
  }
  public void setDisplayName(String displayName) {
    this.displayName = displayName;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("enabled")
  public Boolean isEnabled() {
    return enabled;
  }
  public void setEnabled(Boolean enabled) {
    this.enabled = enabled;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("protocolVersion")
  public Integer getProtocolVersion() {
    return protocolVersion;
  }
  public void setProtocolVersion(Integer protocolVersion) {
    this.protocolVersion = protocolVersion;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("reconnectInterval")
  public Integer getReconnectInterval() {
    return reconnectInterval;
  }
  public void setReconnectInterval(Integer reconnectInterval) {
    this.reconnectInterval = reconnectInterval;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("fallback")
  public String getFallback() {
    return fallback;
  }
  public void setFallback(String fallback) {
    this.fallback = fallback;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("maxRetries")
  public Integer getMaxRetries() {
    return maxRetries;
  }
  public void setMaxRetries(Integer maxRetries) {
    this.maxRetries = maxRetries;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("unlimitedRetries")
  public Boolean isUnlimitedRetries() {
    return unlimitedRetries;
  }
  public void setUnlimitedRetries(Boolean unlimitedRetries) {
    this.unlimitedRetries = unlimitedRetries;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    OutgoingConnectionSummary outgoingConnectionSummary = (OutgoingConnectionSummary) o;
    return Objects.equals(connectionInfoSummary, outgoingConnectionSummary.connectionInfoSummary) &&
        Objects.equals(address, outgoingConnectionSummary.address) &&
        Objects.equals(port, outgoingConnectionSummary.port) &&
        Objects.equals(displayName, outgoingConnectionSummary.displayName) &&
        Objects.equals(enabled, outgoingConnectionSummary.enabled) &&
        Objects.equals(protocolVersion, outgoingConnectionSummary.protocolVersion) &&
        Objects.equals(reconnectInterval, outgoingConnectionSummary.reconnectInterval) &&
        Objects.equals(fallback, outgoingConnectionSummary.fallback) &&
        Objects.equals(maxRetries, outgoingConnectionSummary.maxRetries) &&
        Objects.equals(unlimitedRetries, outgoingConnectionSummary.unlimitedRetries);
  }

  @Override
  public int hashCode() {
    return Objects.hash(connectionInfoSummary, address, port, displayName, enabled, protocolVersion, reconnectInterval, fallback, maxRetries, unlimitedRetries);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class OutgoingConnectionSummary {\n");
    
    sb.append("    connectionInfoSummary: ").append(toIndentedString(connectionInfoSummary)).append("\n");
    sb.append("    address: ").append(toIndentedString(address)).append("\n");
    sb.append("    port: ").append(toIndentedString(port)).append("\n");
    sb.append("    displayName: ").append(toIndentedString(displayName)).append("\n");
    sb.append("    enabled: ").append(toIndentedString(enabled)).append("\n");
    sb.append("    protocolVersion: ").append(toIndentedString(protocolVersion)).append("\n");
    sb.append("    reconnectInterval: ").append(toIndentedString(reconnectInterval)).append("\n");
    sb.append("    fallback: ").append(toIndentedString(fallback)).append("\n");
    sb.append("    maxRetries: ").append(toIndentedString(maxRetries)).append("\n");
    sb.append("    unlimitedRetries: ").append(toIndentedString(unlimitedRetries)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
