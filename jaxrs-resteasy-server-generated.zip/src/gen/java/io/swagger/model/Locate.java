package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class Locate   {
  private Boolean enabled = null;  private Boolean requireLogin = null;  private String cotType = null;  private String group = null;  private Boolean broadcast = null;  private Boolean addToMission = null;  private String mission = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("enabled")
  public Boolean isEnabled() {
    return enabled;
  }
  public void setEnabled(Boolean enabled) {
    this.enabled = enabled;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("requireLogin")
  public Boolean isRequireLogin() {
    return requireLogin;
  }
  public void setRequireLogin(Boolean requireLogin) {
    this.requireLogin = requireLogin;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("cotType")
  public String getCotType() {
    return cotType;
  }
  public void setCotType(String cotType) {
    this.cotType = cotType;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("group")
  public String getGroup() {
    return group;
  }
  public void setGroup(String group) {
    this.group = group;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("broadcast")
  public Boolean isBroadcast() {
    return broadcast;
  }
  public void setBroadcast(Boolean broadcast) {
    this.broadcast = broadcast;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("addToMission")
  public Boolean isAddToMission() {
    return addToMission;
  }
  public void setAddToMission(Boolean addToMission) {
    this.addToMission = addToMission;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("mission")
  public String getMission() {
    return mission;
  }
  public void setMission(String mission) {
    this.mission = mission;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Locate locate = (Locate) o;
    return Objects.equals(enabled, locate.enabled) &&
        Objects.equals(requireLogin, locate.requireLogin) &&
        Objects.equals(cotType, locate.cotType) &&
        Objects.equals(group, locate.group) &&
        Objects.equals(broadcast, locate.broadcast) &&
        Objects.equals(addToMission, locate.addToMission) &&
        Objects.equals(mission, locate.mission);
  }

  @Override
  public int hashCode() {
    return Objects.hash(enabled, requireLogin, cotType, group, broadcast, addToMission, mission);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Locate {\n");
    
    sb.append("    enabled: ").append(toIndentedString(enabled)).append("\n");
    sb.append("    requireLogin: ").append(toIndentedString(requireLogin)).append("\n");
    sb.append("    cotType: ").append(toIndentedString(cotType)).append("\n");
    sb.append("    group: ").append(toIndentedString(group)).append("\n");
    sb.append("    broadcast: ").append(toIndentedString(broadcast)).append("\n");
    sb.append("    addToMission: ").append(toIndentedString(addToMission)).append("\n");
    sb.append("    mission: ").append(toIndentedString(mission)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
