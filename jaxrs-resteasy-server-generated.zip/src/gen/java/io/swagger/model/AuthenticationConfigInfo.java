package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class AuthenticationConfigInfo   {
  private String url = null;  private String userString = null;  private Integer updateInterval = null;  private String groupPrefix = null;  private String serviceAccountDN = null;  private String serviceAccountCredential = null;  private String groupBaseRDN = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("url")
  public String getUrl() {
    return url;
  }
  public void setUrl(String url) {
    this.url = url;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("userString")
  public String getUserString() {
    return userString;
  }
  public void setUserString(String userString) {
    this.userString = userString;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("updateInterval")
  public Integer getUpdateInterval() {
    return updateInterval;
  }
  public void setUpdateInterval(Integer updateInterval) {
    this.updateInterval = updateInterval;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("groupPrefix")
  public String getGroupPrefix() {
    return groupPrefix;
  }
  public void setGroupPrefix(String groupPrefix) {
    this.groupPrefix = groupPrefix;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("serviceAccountDN")
  public String getServiceAccountDN() {
    return serviceAccountDN;
  }
  public void setServiceAccountDN(String serviceAccountDN) {
    this.serviceAccountDN = serviceAccountDN;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("serviceAccountCredential")
  public String getServiceAccountCredential() {
    return serviceAccountCredential;
  }
  public void setServiceAccountCredential(String serviceAccountCredential) {
    this.serviceAccountCredential = serviceAccountCredential;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("groupBaseRDN")
  public String getGroupBaseRDN() {
    return groupBaseRDN;
  }
  public void setGroupBaseRDN(String groupBaseRDN) {
    this.groupBaseRDN = groupBaseRDN;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    AuthenticationConfigInfo authenticationConfigInfo = (AuthenticationConfigInfo) o;
    return Objects.equals(url, authenticationConfigInfo.url) &&
        Objects.equals(userString, authenticationConfigInfo.userString) &&
        Objects.equals(updateInterval, authenticationConfigInfo.updateInterval) &&
        Objects.equals(groupPrefix, authenticationConfigInfo.groupPrefix) &&
        Objects.equals(serviceAccountDN, authenticationConfigInfo.serviceAccountDN) &&
        Objects.equals(serviceAccountCredential, authenticationConfigInfo.serviceAccountCredential) &&
        Objects.equals(groupBaseRDN, authenticationConfigInfo.groupBaseRDN);
  }

  @Override
  public int hashCode() {
    return Objects.hash(url, userString, updateInterval, groupPrefix, serviceAccountDN, serviceAccountCredential, groupBaseRDN);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class AuthenticationConfigInfo {\n");
    
    sb.append("    url: ").append(toIndentedString(url)).append("\n");
    sb.append("    userString: ").append(toIndentedString(userString)).append("\n");
    sb.append("    updateInterval: ").append(toIndentedString(updateInterval)).append("\n");
    sb.append("    groupPrefix: ").append(toIndentedString(groupPrefix)).append("\n");
    sb.append("    serviceAccountDN: ").append(toIndentedString(serviceAccountDN)).append("\n");
    sb.append("    serviceAccountCredential: ").append(toIndentedString(serviceAccountCredential)).append("\n");
    sb.append("    groupBaseRDN: ").append(toIndentedString(groupBaseRDN)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
