package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.FederationPort;
import io.swagger.model.Tls;
import io.swagger.model.V1Tls;
import java.util.List;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class FederationServer   {
  private Tls tls = null;  private List<FederationPort> federationPort = new ArrayList<FederationPort>();  private List<V1Tls> v1Tls = new ArrayList<V1Tls>();  private Integer port = null;  private Integer coreVersion = null;  private Boolean v1Enabled = null;  private Integer v2Port = null;  private Boolean v2Enabled = null;  private String webBaseUrl = null;  private Integer httpsPort = null;  private Integer healthCheckIntervalSeconds = null;  private Integer initializationDelaySeconds = null;  private Integer maxMessageSizeBytes = null;

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("tls")
  @NotNull
  public Tls getTls() {
    return tls;
  }
  public void setTls(Tls tls) {
    this.tls = tls;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("federationPort")
  public List<FederationPort> getFederationPort() {
    return federationPort;
  }
  public void setFederationPort(List<FederationPort> federationPort) {
    this.federationPort = federationPort;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("v1Tls")
  public List<V1Tls> getV1Tls() {
    return v1Tls;
  }
  public void setV1Tls(List<V1Tls> v1Tls) {
    this.v1Tls = v1Tls;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("port")
  public Integer getPort() {
    return port;
  }
  public void setPort(Integer port) {
    this.port = port;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("coreVersion")
  public Integer getCoreVersion() {
    return coreVersion;
  }
  public void setCoreVersion(Integer coreVersion) {
    this.coreVersion = coreVersion;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("v1Enabled")
  public Boolean isV1Enabled() {
    return v1Enabled;
  }
  public void setV1Enabled(Boolean v1Enabled) {
    this.v1Enabled = v1Enabled;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("v2Port")
  public Integer getV2Port() {
    return v2Port;
  }
  public void setV2Port(Integer v2Port) {
    this.v2Port = v2Port;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("v2Enabled")
  public Boolean isV2Enabled() {
    return v2Enabled;
  }
  public void setV2Enabled(Boolean v2Enabled) {
    this.v2Enabled = v2Enabled;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("webBaseUrl")
  public String getWebBaseUrl() {
    return webBaseUrl;
  }
  public void setWebBaseUrl(String webBaseUrl) {
    this.webBaseUrl = webBaseUrl;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("httpsPort")
  public Integer getHttpsPort() {
    return httpsPort;
  }
  public void setHttpsPort(Integer httpsPort) {
    this.httpsPort = httpsPort;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("healthCheckIntervalSeconds")
  public Integer getHealthCheckIntervalSeconds() {
    return healthCheckIntervalSeconds;
  }
  public void setHealthCheckIntervalSeconds(Integer healthCheckIntervalSeconds) {
    this.healthCheckIntervalSeconds = healthCheckIntervalSeconds;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("initializationDelaySeconds")
  public Integer getInitializationDelaySeconds() {
    return initializationDelaySeconds;
  }
  public void setInitializationDelaySeconds(Integer initializationDelaySeconds) {
    this.initializationDelaySeconds = initializationDelaySeconds;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("maxMessageSizeBytes")
  public Integer getMaxMessageSizeBytes() {
    return maxMessageSizeBytes;
  }
  public void setMaxMessageSizeBytes(Integer maxMessageSizeBytes) {
    this.maxMessageSizeBytes = maxMessageSizeBytes;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    FederationServer federationServer = (FederationServer) o;
    return Objects.equals(tls, federationServer.tls) &&
        Objects.equals(federationPort, federationServer.federationPort) &&
        Objects.equals(v1Tls, federationServer.v1Tls) &&
        Objects.equals(port, federationServer.port) &&
        Objects.equals(coreVersion, federationServer.coreVersion) &&
        Objects.equals(v1Enabled, federationServer.v1Enabled) &&
        Objects.equals(v2Port, federationServer.v2Port) &&
        Objects.equals(v2Enabled, federationServer.v2Enabled) &&
        Objects.equals(webBaseUrl, federationServer.webBaseUrl) &&
        Objects.equals(httpsPort, federationServer.httpsPort) &&
        Objects.equals(healthCheckIntervalSeconds, federationServer.healthCheckIntervalSeconds) &&
        Objects.equals(initializationDelaySeconds, federationServer.initializationDelaySeconds) &&
        Objects.equals(maxMessageSizeBytes, federationServer.maxMessageSizeBytes);
  }

  @Override
  public int hashCode() {
    return Objects.hash(tls, federationPort, v1Tls, port, coreVersion, v1Enabled, v2Port, v2Enabled, webBaseUrl, httpsPort, healthCheckIntervalSeconds, initializationDelaySeconds, maxMessageSizeBytes);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class FederationServer {\n");
    
    sb.append("    tls: ").append(toIndentedString(tls)).append("\n");
    sb.append("    federationPort: ").append(toIndentedString(federationPort)).append("\n");
    sb.append("    v1Tls: ").append(toIndentedString(v1Tls)).append("\n");
    sb.append("    port: ").append(toIndentedString(port)).append("\n");
    sb.append("    coreVersion: ").append(toIndentedString(coreVersion)).append("\n");
    sb.append("    v1Enabled: ").append(toIndentedString(v1Enabled)).append("\n");
    sb.append("    v2Port: ").append(toIndentedString(v2Port)).append("\n");
    sb.append("    v2Enabled: ").append(toIndentedString(v2Enabled)).append("\n");
    sb.append("    webBaseUrl: ").append(toIndentedString(webBaseUrl)).append("\n");
    sb.append("    httpsPort: ").append(toIndentedString(httpsPort)).append("\n");
    sb.append("    healthCheckIntervalSeconds: ").append(toIndentedString(healthCheckIntervalSeconds)).append("\n");
    sb.append("    initializationDelaySeconds: ").append(toIndentedString(initializationDelaySeconds)).append("\n");
    sb.append("    maxMessageSizeBytes: ").append(toIndentedString(maxMessageSizeBytes)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
