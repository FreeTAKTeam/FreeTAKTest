package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import java.util.Date;
import java.util.List;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class LogEntry   {
  private String id = null;  private String content = null;  private String creatorUid = null;  private String entryUid = null;  private List<String> missionNames = new ArrayList<String>();  private Date servertime = null;  private Date dtg = null;  private Date created = null;  private List<String> contentHashes = new ArrayList<String>();  private List<String> keywords = new ArrayList<String>();

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("id")
  public String getId() {
    return id;
  }
  public void setId(String id) {
    this.id = id;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("content")
  public String getContent() {
    return content;
  }
  public void setContent(String content) {
    this.content = content;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("creatorUid")
  public String getCreatorUid() {
    return creatorUid;
  }
  public void setCreatorUid(String creatorUid) {
    this.creatorUid = creatorUid;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("entryUid")
  public String getEntryUid() {
    return entryUid;
  }
  public void setEntryUid(String entryUid) {
    this.entryUid = entryUid;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("missionNames")
  public List<String> getMissionNames() {
    return missionNames;
  }
  public void setMissionNames(List<String> missionNames) {
    this.missionNames = missionNames;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("servertime")
  public Date getServertime() {
    return servertime;
  }
  public void setServertime(Date servertime) {
    this.servertime = servertime;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("dtg")
  public Date getDtg() {
    return dtg;
  }
  public void setDtg(Date dtg) {
    this.dtg = dtg;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("created")
  public Date getCreated() {
    return created;
  }
  public void setCreated(Date created) {
    this.created = created;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("contentHashes")
  public List<String> getContentHashes() {
    return contentHashes;
  }
  public void setContentHashes(List<String> contentHashes) {
    this.contentHashes = contentHashes;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("keywords")
  public List<String> getKeywords() {
    return keywords;
  }
  public void setKeywords(List<String> keywords) {
    this.keywords = keywords;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    LogEntry logEntry = (LogEntry) o;
    return Objects.equals(id, logEntry.id) &&
        Objects.equals(content, logEntry.content) &&
        Objects.equals(creatorUid, logEntry.creatorUid) &&
        Objects.equals(entryUid, logEntry.entryUid) &&
        Objects.equals(missionNames, logEntry.missionNames) &&
        Objects.equals(servertime, logEntry.servertime) &&
        Objects.equals(dtg, logEntry.dtg) &&
        Objects.equals(created, logEntry.created) &&
        Objects.equals(contentHashes, logEntry.contentHashes) &&
        Objects.equals(keywords, logEntry.keywords);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, content, creatorUid, entryUid, missionNames, servertime, dtg, created, contentHashes, keywords);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class LogEntry {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    content: ").append(toIndentedString(content)).append("\n");
    sb.append("    creatorUid: ").append(toIndentedString(creatorUid)).append("\n");
    sb.append("    entryUid: ").append(toIndentedString(entryUid)).append("\n");
    sb.append("    missionNames: ").append(toIndentedString(missionNames)).append("\n");
    sb.append("    servertime: ").append(toIndentedString(servertime)).append("\n");
    sb.append("    dtg: ").append(toIndentedString(dtg)).append("\n");
    sb.append("    created: ").append(toIndentedString(created)).append("\n");
    sb.append("    contentHashes: ").append(toIndentedString(contentHashes)).append("\n");
    sb.append("    keywords: ").append(toIndentedString(keywords)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
