package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import java.util.Date;
import java.util.List;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class Profile   {
  private Long id = null;  private String name = null;  private Boolean active = null;  private Boolean applyOnEnrollment = null;  private Boolean applyOnConnect = null;  private String type = null;  private Date updated = null;  private String tool = null;  private List<String> groups = new ArrayList<String>();

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("id")
  public Long getId() {
    return id;
  }
  public void setId(Long id) {
    this.id = id;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("name")
  public String getName() {
    return name;
  }
  public void setName(String name) {
    this.name = name;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("active")
  public Boolean isActive() {
    return active;
  }
  public void setActive(Boolean active) {
    this.active = active;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("applyOnEnrollment")
  public Boolean isApplyOnEnrollment() {
    return applyOnEnrollment;
  }
  public void setApplyOnEnrollment(Boolean applyOnEnrollment) {
    this.applyOnEnrollment = applyOnEnrollment;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("applyOnConnect")
  public Boolean isApplyOnConnect() {
    return applyOnConnect;
  }
  public void setApplyOnConnect(Boolean applyOnConnect) {
    this.applyOnConnect = applyOnConnect;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("type")
  public String getType() {
    return type;
  }
  public void setType(String type) {
    this.type = type;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("updated")
  public Date getUpdated() {
    return updated;
  }
  public void setUpdated(Date updated) {
    this.updated = updated;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("tool")
  public String getTool() {
    return tool;
  }
  public void setTool(String tool) {
    this.tool = tool;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("groups")
  public List<String> getGroups() {
    return groups;
  }
  public void setGroups(List<String> groups) {
    this.groups = groups;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Profile profile = (Profile) o;
    return Objects.equals(id, profile.id) &&
        Objects.equals(name, profile.name) &&
        Objects.equals(active, profile.active) &&
        Objects.equals(applyOnEnrollment, profile.applyOnEnrollment) &&
        Objects.equals(applyOnConnect, profile.applyOnConnect) &&
        Objects.equals(type, profile.type) &&
        Objects.equals(updated, profile.updated) &&
        Objects.equals(tool, profile.tool) &&
        Objects.equals(groups, profile.groups);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, name, active, applyOnEnrollment, applyOnConnect, type, updated, tool, groups);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Profile {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    active: ").append(toIndentedString(active)).append("\n");
    sb.append("    applyOnEnrollment: ").append(toIndentedString(applyOnEnrollment)).append("\n");
    sb.append("    applyOnConnect: ").append(toIndentedString(applyOnConnect)).append("\n");
    sb.append("    type: ").append(toIndentedString(type)).append("\n");
    sb.append("    updated: ").append(toIndentedString(updated)).append("\n");
    sb.append("    tool: ").append(toIndentedString(tool)).append("\n");
    sb.append("    groups: ").append(toIndentedString(groups)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
