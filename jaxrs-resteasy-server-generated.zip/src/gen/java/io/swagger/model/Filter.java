package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.ContactApi;
import io.swagger.model.Dropfilter;
import io.swagger.model.Flowtag;
import io.swagger.model.GeospatialFilter;
import io.swagger.model.Injectionfilter;
import io.swagger.model.Qos;
import io.swagger.model.Scrubber;
import io.swagger.model.Streamingbroker;
import io.swagger.model.Thumbnail;
import io.swagger.model.Urladd;
import java.util.List;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class Filter   {
  private Thumbnail thumbnail = null;  private Urladd urladd = null;  private Flowtag flowtag = null;  private Streamingbroker streamingbroker = null;  private Dropfilter dropfilter = null;  private Injectionfilter injectionfilter = null;  private Scrubber scrubber = null;  private GeospatialFilter geospatialFilter = null;  private Qos qos = null;  private List<ContactApi> contactApi = new ArrayList<ContactApi>();

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("thumbnail")
  public Thumbnail getThumbnail() {
    return thumbnail;
  }
  public void setThumbnail(Thumbnail thumbnail) {
    this.thumbnail = thumbnail;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("urladd")
  public Urladd getUrladd() {
    return urladd;
  }
  public void setUrladd(Urladd urladd) {
    this.urladd = urladd;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("flowtag")
  public Flowtag getFlowtag() {
    return flowtag;
  }
  public void setFlowtag(Flowtag flowtag) {
    this.flowtag = flowtag;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("streamingbroker")
  public Streamingbroker getStreamingbroker() {
    return streamingbroker;
  }
  public void setStreamingbroker(Streamingbroker streamingbroker) {
    this.streamingbroker = streamingbroker;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("dropfilter")
  public Dropfilter getDropfilter() {
    return dropfilter;
  }
  public void setDropfilter(Dropfilter dropfilter) {
    this.dropfilter = dropfilter;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("injectionfilter")
  public Injectionfilter getInjectionfilter() {
    return injectionfilter;
  }
  public void setInjectionfilter(Injectionfilter injectionfilter) {
    this.injectionfilter = injectionfilter;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("scrubber")
  public Scrubber getScrubber() {
    return scrubber;
  }
  public void setScrubber(Scrubber scrubber) {
    this.scrubber = scrubber;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("geospatialFilter")
  public GeospatialFilter getGeospatialFilter() {
    return geospatialFilter;
  }
  public void setGeospatialFilter(GeospatialFilter geospatialFilter) {
    this.geospatialFilter = geospatialFilter;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("qos")
  public Qos getQos() {
    return qos;
  }
  public void setQos(Qos qos) {
    this.qos = qos;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("contactApi")
  public List<ContactApi> getContactApi() {
    return contactApi;
  }
  public void setContactApi(List<ContactApi> contactApi) {
    this.contactApi = contactApi;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Filter filter = (Filter) o;
    return Objects.equals(thumbnail, filter.thumbnail) &&
        Objects.equals(urladd, filter.urladd) &&
        Objects.equals(flowtag, filter.flowtag) &&
        Objects.equals(streamingbroker, filter.streamingbroker) &&
        Objects.equals(dropfilter, filter.dropfilter) &&
        Objects.equals(injectionfilter, filter.injectionfilter) &&
        Objects.equals(scrubber, filter.scrubber) &&
        Objects.equals(geospatialFilter, filter.geospatialFilter) &&
        Objects.equals(qos, filter.qos) &&
        Objects.equals(contactApi, filter.contactApi);
  }

  @Override
  public int hashCode() {
    return Objects.hash(thumbnail, urladd, flowtag, streamingbroker, dropfilter, injectionfilter, scrubber, geospatialFilter, qos, contactApi);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Filter {\n");
    
    sb.append("    thumbnail: ").append(toIndentedString(thumbnail)).append("\n");
    sb.append("    urladd: ").append(toIndentedString(urladd)).append("\n");
    sb.append("    flowtag: ").append(toIndentedString(flowtag)).append("\n");
    sb.append("    streamingbroker: ").append(toIndentedString(streamingbroker)).append("\n");
    sb.append("    dropfilter: ").append(toIndentedString(dropfilter)).append("\n");
    sb.append("    injectionfilter: ").append(toIndentedString(injectionfilter)).append("\n");
    sb.append("    scrubber: ").append(toIndentedString(scrubber)).append("\n");
    sb.append("    geospatialFilter: ").append(toIndentedString(geospatialFilter)).append("\n");
    sb.append("    qos: ").append(toIndentedString(qos)).append("\n");
    sb.append("    contactApi: ").append(toIndentedString(contactApi)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
