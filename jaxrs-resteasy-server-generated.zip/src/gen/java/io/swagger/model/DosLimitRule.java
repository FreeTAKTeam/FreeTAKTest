package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class DosLimitRule   {
  private Integer clientThresholdCount = null;  private Integer messageLimitPerInterval = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("clientThresholdCount")
  public Integer getClientThresholdCount() {
    return clientThresholdCount;
  }
  public void setClientThresholdCount(Integer clientThresholdCount) {
    this.clientThresholdCount = clientThresholdCount;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("messageLimitPerInterval")
  public Integer getMessageLimitPerInterval() {
    return messageLimitPerInterval;
  }
  public void setMessageLimitPerInterval(Integer messageLimitPerInterval) {
    this.messageLimitPerInterval = messageLimitPerInterval;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    DosLimitRule dosLimitRule = (DosLimitRule) o;
    return Objects.equals(clientThresholdCount, dosLimitRule.clientThresholdCount) &&
        Objects.equals(messageLimitPerInterval, dosLimitRule.messageLimitPerInterval);
  }

  @Override
  public int hashCode() {
    return Objects.hash(clientThresholdCount, messageLimitPerInterval);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class DosLimitRule {\n");
    
    sb.append("    clientThresholdCount: ").append(toIndentedString(clientThresholdCount)).append("\n");
    sb.append("    messageLimitPerInterval: ").append(toIndentedString(messageLimitPerInterval)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
