package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.Whitelist;
import java.util.List;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class Email   {
  private List<Whitelist> whitelist = new ArrayList<Whitelist>();  private List<String> logAlertsExtension = new ArrayList<String>();  private String host = null;  private Integer port = null;  private String username = null;  private String password = null;  private String from = null;  private String supportName = null;  private String supportEmail = null;  private Integer registrationPort = null;  private Boolean logAlertsEnabled = null;  private String logAlertsTo = null;  private String logAlertsSubject = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("whitelist")
  public List<Whitelist> getWhitelist() {
    return whitelist;
  }
  public void setWhitelist(List<Whitelist> whitelist) {
    this.whitelist = whitelist;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("logAlertsExtension")
  public List<String> getLogAlertsExtension() {
    return logAlertsExtension;
  }
  public void setLogAlertsExtension(List<String> logAlertsExtension) {
    this.logAlertsExtension = logAlertsExtension;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("host")
  public String getHost() {
    return host;
  }
  public void setHost(String host) {
    this.host = host;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("port")
  public Integer getPort() {
    return port;
  }
  public void setPort(Integer port) {
    this.port = port;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("username")
  public String getUsername() {
    return username;
  }
  public void setUsername(String username) {
    this.username = username;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("password")
  public String getPassword() {
    return password;
  }
  public void setPassword(String password) {
    this.password = password;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("from")
  public String getFrom() {
    return from;
  }
  public void setFrom(String from) {
    this.from = from;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("supportName")
  public String getSupportName() {
    return supportName;
  }
  public void setSupportName(String supportName) {
    this.supportName = supportName;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("supportEmail")
  public String getSupportEmail() {
    return supportEmail;
  }
  public void setSupportEmail(String supportEmail) {
    this.supportEmail = supportEmail;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("registrationPort")
  public Integer getRegistrationPort() {
    return registrationPort;
  }
  public void setRegistrationPort(Integer registrationPort) {
    this.registrationPort = registrationPort;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("logAlertsEnabled")
  public Boolean isLogAlertsEnabled() {
    return logAlertsEnabled;
  }
  public void setLogAlertsEnabled(Boolean logAlertsEnabled) {
    this.logAlertsEnabled = logAlertsEnabled;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("logAlertsTo")
  public String getLogAlertsTo() {
    return logAlertsTo;
  }
  public void setLogAlertsTo(String logAlertsTo) {
    this.logAlertsTo = logAlertsTo;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("logAlertsSubject")
  public String getLogAlertsSubject() {
    return logAlertsSubject;
  }
  public void setLogAlertsSubject(String logAlertsSubject) {
    this.logAlertsSubject = logAlertsSubject;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Email email = (Email) o;
    return Objects.equals(whitelist, email.whitelist) &&
        Objects.equals(logAlertsExtension, email.logAlertsExtension) &&
        Objects.equals(host, email.host) &&
        Objects.equals(port, email.port) &&
        Objects.equals(username, email.username) &&
        Objects.equals(password, email.password) &&
        Objects.equals(from, email.from) &&
        Objects.equals(supportName, email.supportName) &&
        Objects.equals(supportEmail, email.supportEmail) &&
        Objects.equals(registrationPort, email.registrationPort) &&
        Objects.equals(logAlertsEnabled, email.logAlertsEnabled) &&
        Objects.equals(logAlertsTo, email.logAlertsTo) &&
        Objects.equals(logAlertsSubject, email.logAlertsSubject);
  }

  @Override
  public int hashCode() {
    return Objects.hash(whitelist, logAlertsExtension, host, port, username, password, from, supportName, supportEmail, registrationPort, logAlertsEnabled, logAlertsTo, logAlertsSubject);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Email {\n");
    
    sb.append("    whitelist: ").append(toIndentedString(whitelist)).append("\n");
    sb.append("    logAlertsExtension: ").append(toIndentedString(logAlertsExtension)).append("\n");
    sb.append("    host: ").append(toIndentedString(host)).append("\n");
    sb.append("    port: ").append(toIndentedString(port)).append("\n");
    sb.append("    username: ").append(toIndentedString(username)).append("\n");
    sb.append("    password: ").append(toIndentedString(password)).append("\n");
    sb.append("    from: ").append(toIndentedString(from)).append("\n");
    sb.append("    supportName: ").append(toIndentedString(supportName)).append("\n");
    sb.append("    supportEmail: ").append(toIndentedString(supportEmail)).append("\n");
    sb.append("    registrationPort: ").append(toIndentedString(registrationPort)).append("\n");
    sb.append("    logAlertsEnabled: ").append(toIndentedString(logAlertsEnabled)).append("\n");
    sb.append("    logAlertsTo: ").append(toIndentedString(logAlertsTo)).append("\n");
    sb.append("    logAlertsSubject: ").append(toIndentedString(logAlertsSubject)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
