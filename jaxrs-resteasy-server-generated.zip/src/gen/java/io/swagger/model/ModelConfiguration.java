package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.Async;
import io.swagger.model.Auth;
import io.swagger.model.Buffer;
import io.swagger.model.CertificateSigning;
import io.swagger.model.Citrap;
import io.swagger.model.Cluster;
import io.swagger.model.Dissemination;
import io.swagger.model.Docs;
import io.swagger.model.Email;
import io.swagger.model.Federation;
import io.swagger.model.Ferry;
import io.swagger.model.Filter;
import io.swagger.model.Geocache;
import io.swagger.model.Locate;
import io.swagger.model.Network;
import io.swagger.model.Plugins;
import io.swagger.model.Profile;
import io.swagger.model.Repeater;
import io.swagger.model.Repository;
import io.swagger.model.Security;
import io.swagger.model.Submission;
import io.swagger.model.Subscription;
import io.swagger.model.Vbm;
import io.swagger.model.Xmpp;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class ModelConfiguration   {
  private Network network = null;  private Auth auth = null;  private Submission submission = null;  private Subscription subscription = null;  private Repository repository = null;  private Repeater repeater = null;  private Filter filter = null;  private Buffer buffer = null;  private Dissemination dissemination = null;  private CertificateSigning certificateSigning = null;  private Security security = null;  private Ferry ferry = null;  private Async async = null;  private Federation federation = null;  private Geocache geocache = null;  private Citrap citrap = null;  private Xmpp xmpp = null;  private Plugins plugins = null;  private Cluster cluster = null;  private Docs docs = null;  private Email email = null;  private Locate locate = null;  private Vbm vbm = null;  private Profile profile = null;  private Boolean forceLowConcurrency = null;

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("network")
  @NotNull
  public Network getNetwork() {
    return network;
  }
  public void setNetwork(Network network) {
    this.network = network;
  }

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("auth")
  @NotNull
  public Auth getAuth() {
    return auth;
  }
  public void setAuth(Auth auth) {
    this.auth = auth;
  }

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("submission")
  @NotNull
  public Submission getSubmission() {
    return submission;
  }
  public void setSubmission(Submission submission) {
    this.submission = submission;
  }

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("subscription")
  @NotNull
  public Subscription getSubscription() {
    return subscription;
  }
  public void setSubscription(Subscription subscription) {
    this.subscription = subscription;
  }

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("repository")
  @NotNull
  public Repository getRepository() {
    return repository;
  }
  public void setRepository(Repository repository) {
    this.repository = repository;
  }

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("repeater")
  @NotNull
  public Repeater getRepeater() {
    return repeater;
  }
  public void setRepeater(Repeater repeater) {
    this.repeater = repeater;
  }

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("filter")
  @NotNull
  public Filter getFilter() {
    return filter;
  }
  public void setFilter(Filter filter) {
    this.filter = filter;
  }

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("buffer")
  @NotNull
  public Buffer getBuffer() {
    return buffer;
  }
  public void setBuffer(Buffer buffer) {
    this.buffer = buffer;
  }

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("dissemination")
  @NotNull
  public Dissemination getDissemination() {
    return dissemination;
  }
  public void setDissemination(Dissemination dissemination) {
    this.dissemination = dissemination;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("certificateSigning")
  public CertificateSigning getCertificateSigning() {
    return certificateSigning;
  }
  public void setCertificateSigning(CertificateSigning certificateSigning) {
    this.certificateSigning = certificateSigning;
  }

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("security")
  @NotNull
  public Security getSecurity() {
    return security;
  }
  public void setSecurity(Security security) {
    this.security = security;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("ferry")
  public Ferry getFerry() {
    return ferry;
  }
  public void setFerry(Ferry ferry) {
    this.ferry = ferry;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("async")
  public Async getAsync() {
    return async;
  }
  public void setAsync(Async async) {
    this.async = async;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("federation")
  public Federation getFederation() {
    return federation;
  }
  public void setFederation(Federation federation) {
    this.federation = federation;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("geocache")
  public Geocache getGeocache() {
    return geocache;
  }
  public void setGeocache(Geocache geocache) {
    this.geocache = geocache;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("citrap")
  public Citrap getCitrap() {
    return citrap;
  }
  public void setCitrap(Citrap citrap) {
    this.citrap = citrap;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("xmpp")
  public Xmpp getXmpp() {
    return xmpp;
  }
  public void setXmpp(Xmpp xmpp) {
    this.xmpp = xmpp;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("plugins")
  public Plugins getPlugins() {
    return plugins;
  }
  public void setPlugins(Plugins plugins) {
    this.plugins = plugins;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("cluster")
  public Cluster getCluster() {
    return cluster;
  }
  public void setCluster(Cluster cluster) {
    this.cluster = cluster;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("docs")
  public Docs getDocs() {
    return docs;
  }
  public void setDocs(Docs docs) {
    this.docs = docs;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("email")
  public Email getEmail() {
    return email;
  }
  public void setEmail(Email email) {
    this.email = email;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("locate")
  public Locate getLocate() {
    return locate;
  }
  public void setLocate(Locate locate) {
    this.locate = locate;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("vbm")
  public Vbm getVbm() {
    return vbm;
  }
  public void setVbm(Vbm vbm) {
    this.vbm = vbm;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("profile")
  public Profile getProfile() {
    return profile;
  }
  public void setProfile(Profile profile) {
    this.profile = profile;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("forceLowConcurrency")
  public Boolean isForceLowConcurrency() {
    return forceLowConcurrency;
  }
  public void setForceLowConcurrency(Boolean forceLowConcurrency) {
    this.forceLowConcurrency = forceLowConcurrency;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ModelConfiguration _configuration = (ModelConfiguration) o;
    return Objects.equals(network, _configuration.network) &&
        Objects.equals(auth, _configuration.auth) &&
        Objects.equals(submission, _configuration.submission) &&
        Objects.equals(subscription, _configuration.subscription) &&
        Objects.equals(repository, _configuration.repository) &&
        Objects.equals(repeater, _configuration.repeater) &&
        Objects.equals(filter, _configuration.filter) &&
        Objects.equals(buffer, _configuration.buffer) &&
        Objects.equals(dissemination, _configuration.dissemination) &&
        Objects.equals(certificateSigning, _configuration.certificateSigning) &&
        Objects.equals(security, _configuration.security) &&
        Objects.equals(ferry, _configuration.ferry) &&
        Objects.equals(async, _configuration.async) &&
        Objects.equals(federation, _configuration.federation) &&
        Objects.equals(geocache, _configuration.geocache) &&
        Objects.equals(citrap, _configuration.citrap) &&
        Objects.equals(xmpp, _configuration.xmpp) &&
        Objects.equals(plugins, _configuration.plugins) &&
        Objects.equals(cluster, _configuration.cluster) &&
        Objects.equals(docs, _configuration.docs) &&
        Objects.equals(email, _configuration.email) &&
        Objects.equals(locate, _configuration.locate) &&
        Objects.equals(vbm, _configuration.vbm) &&
        Objects.equals(profile, _configuration.profile) &&
        Objects.equals(forceLowConcurrency, _configuration.forceLowConcurrency);
  }

  @Override
  public int hashCode() {
    return Objects.hash(network, auth, submission, subscription, repository, repeater, filter, buffer, dissemination, certificateSigning, security, ferry, async, federation, geocache, citrap, xmpp, plugins, cluster, docs, email, locate, vbm, profile, forceLowConcurrency);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ModelConfiguration {\n");
    
    sb.append("    network: ").append(toIndentedString(network)).append("\n");
    sb.append("    auth: ").append(toIndentedString(auth)).append("\n");
    sb.append("    submission: ").append(toIndentedString(submission)).append("\n");
    sb.append("    subscription: ").append(toIndentedString(subscription)).append("\n");
    sb.append("    repository: ").append(toIndentedString(repository)).append("\n");
    sb.append("    repeater: ").append(toIndentedString(repeater)).append("\n");
    sb.append("    filter: ").append(toIndentedString(filter)).append("\n");
    sb.append("    buffer: ").append(toIndentedString(buffer)).append("\n");
    sb.append("    dissemination: ").append(toIndentedString(dissemination)).append("\n");
    sb.append("    certificateSigning: ").append(toIndentedString(certificateSigning)).append("\n");
    sb.append("    security: ").append(toIndentedString(security)).append("\n");
    sb.append("    ferry: ").append(toIndentedString(ferry)).append("\n");
    sb.append("    async: ").append(toIndentedString(async)).append("\n");
    sb.append("    federation: ").append(toIndentedString(federation)).append("\n");
    sb.append("    geocache: ").append(toIndentedString(geocache)).append("\n");
    sb.append("    citrap: ").append(toIndentedString(citrap)).append("\n");
    sb.append("    xmpp: ").append(toIndentedString(xmpp)).append("\n");
    sb.append("    plugins: ").append(toIndentedString(plugins)).append("\n");
    sb.append("    cluster: ").append(toIndentedString(cluster)).append("\n");
    sb.append("    docs: ").append(toIndentedString(docs)).append("\n");
    sb.append("    email: ").append(toIndentedString(email)).append("\n");
    sb.append("    locate: ").append(toIndentedString(locate)).append("\n");
    sb.append("    vbm: ").append(toIndentedString(vbm)).append("\n");
    sb.append("    profile: ").append(toIndentedString(profile)).append("\n");
    sb.append("    forceLowConcurrency: ").append(toIndentedString(forceLowConcurrency)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
