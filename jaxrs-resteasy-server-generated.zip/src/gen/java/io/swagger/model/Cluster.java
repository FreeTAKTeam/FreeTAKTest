package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class Cluster   {
  private Boolean enabled = null;  private String natsURL = null;  private String natsClusterID = null;  private Boolean kubernetes = null;  private Boolean cacheConfig = null;  private Integer metricsIntervalSeconds = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("enabled")
  public Boolean isEnabled() {
    return enabled;
  }
  public void setEnabled(Boolean enabled) {
    this.enabled = enabled;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("natsURL")
  public String getNatsURL() {
    return natsURL;
  }
  public void setNatsURL(String natsURL) {
    this.natsURL = natsURL;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("natsClusterID")
  public String getNatsClusterID() {
    return natsClusterID;
  }
  public void setNatsClusterID(String natsClusterID) {
    this.natsClusterID = natsClusterID;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("kubernetes")
  public Boolean isKubernetes() {
    return kubernetes;
  }
  public void setKubernetes(Boolean kubernetes) {
    this.kubernetes = kubernetes;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("cacheConfig")
  public Boolean isCacheConfig() {
    return cacheConfig;
  }
  public void setCacheConfig(Boolean cacheConfig) {
    this.cacheConfig = cacheConfig;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("metricsIntervalSeconds")
  public Integer getMetricsIntervalSeconds() {
    return metricsIntervalSeconds;
  }
  public void setMetricsIntervalSeconds(Integer metricsIntervalSeconds) {
    this.metricsIntervalSeconds = metricsIntervalSeconds;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Cluster cluster = (Cluster) o;
    return Objects.equals(enabled, cluster.enabled) &&
        Objects.equals(natsURL, cluster.natsURL) &&
        Objects.equals(natsClusterID, cluster.natsClusterID) &&
        Objects.equals(kubernetes, cluster.kubernetes) &&
        Objects.equals(cacheConfig, cluster.cacheConfig) &&
        Objects.equals(metricsIntervalSeconds, cluster.metricsIntervalSeconds);
  }

  @Override
  public int hashCode() {
    return Objects.hash(enabled, natsURL, natsClusterID, kubernetes, cacheConfig, metricsIntervalSeconds);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Cluster {\n");
    
    sb.append("    enabled: ").append(toIndentedString(enabled)).append("\n");
    sb.append("    natsURL: ").append(toIndentedString(natsURL)).append("\n");
    sb.append("    natsClusterID: ").append(toIndentedString(natsClusterID)).append("\n");
    sb.append("    kubernetes: ").append(toIndentedString(kubernetes)).append("\n");
    sb.append("    cacheConfig: ").append(toIndentedString(cacheConfig)).append("\n");
    sb.append("    metricsIntervalSeconds: ").append(toIndentedString(metricsIntervalSeconds)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
