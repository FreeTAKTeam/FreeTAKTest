package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.ConnectionInfoCertIssuerDN;
import io.swagger.model.ConnectionInfoCertPublicKey;
import io.swagger.model.ConnectionInfoCertSubjectX500Principal;
import java.util.Date;
import java.util.List;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class ConnectionInfoCert   {
  private String type = null;  private ConnectionInfoCertSubjectX500Principal subjectX500Principal = null;  private ConnectionInfoCertSubjectX500Principal issuerX500Principal = null;  private List<byte[]> signature = new ArrayList<byte[]>();  private Integer basicConstraints = null;  private Integer version = null;  private ConnectionInfoCertIssuerDN issuerDN = null;  private ConnectionInfoCertIssuerDN subjectDN = null;  private String sigAlgOID = null;  private List<byte[]> sigAlgParams = new ArrayList<byte[]>();  private List<Boolean> issuerUniqueID = new ArrayList<Boolean>();  private List<Boolean> subjectUniqueID = new ArrayList<Boolean>();  private List<Boolean> keyUsage = new ArrayList<Boolean>();  private List<List<Object>> subjectAlternativeNames = new ArrayList<List<Object>>();  private List<List<Object>> issuerAlternativeNames = new ArrayList<List<Object>>();  private Integer serialNumber = null;  private List<String> extendedKeyUsage = new ArrayList<String>();  private List<byte[]> tbscertificate = new ArrayList<byte[]>();  private String sigAlgName = null;  private Date notAfter = null;  private Date notBefore = null;  private List<String> criticalExtensionOIDs = new ArrayList<String>();  private List<String> nonCriticalExtensionOIDs = new ArrayList<String>();  private List<byte[]> encoded = new ArrayList<byte[]>();  private ConnectionInfoCertPublicKey publicKey = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("type")
  public String getType() {
    return type;
  }
  public void setType(String type) {
    this.type = type;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("subjectX500Principal")
  public ConnectionInfoCertSubjectX500Principal getSubjectX500Principal() {
    return subjectX500Principal;
  }
  public void setSubjectX500Principal(ConnectionInfoCertSubjectX500Principal subjectX500Principal) {
    this.subjectX500Principal = subjectX500Principal;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("issuerX500Principal")
  public ConnectionInfoCertSubjectX500Principal getIssuerX500Principal() {
    return issuerX500Principal;
  }
  public void setIssuerX500Principal(ConnectionInfoCertSubjectX500Principal issuerX500Principal) {
    this.issuerX500Principal = issuerX500Principal;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("signature")
  public List<byte[]> getSignature() {
    return signature;
  }
  public void setSignature(List<byte[]> signature) {
    this.signature = signature;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("basicConstraints")
  public Integer getBasicConstraints() {
    return basicConstraints;
  }
  public void setBasicConstraints(Integer basicConstraints) {
    this.basicConstraints = basicConstraints;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("version")
  public Integer getVersion() {
    return version;
  }
  public void setVersion(Integer version) {
    this.version = version;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("issuerDN")
  public ConnectionInfoCertIssuerDN getIssuerDN() {
    return issuerDN;
  }
  public void setIssuerDN(ConnectionInfoCertIssuerDN issuerDN) {
    this.issuerDN = issuerDN;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("subjectDN")
  public ConnectionInfoCertIssuerDN getSubjectDN() {
    return subjectDN;
  }
  public void setSubjectDN(ConnectionInfoCertIssuerDN subjectDN) {
    this.subjectDN = subjectDN;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("sigAlgOID")
  public String getSigAlgOID() {
    return sigAlgOID;
  }
  public void setSigAlgOID(String sigAlgOID) {
    this.sigAlgOID = sigAlgOID;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("sigAlgParams")
  public List<byte[]> getSigAlgParams() {
    return sigAlgParams;
  }
  public void setSigAlgParams(List<byte[]> sigAlgParams) {
    this.sigAlgParams = sigAlgParams;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("issuerUniqueID")
  public List<Boolean> getIssuerUniqueID() {
    return issuerUniqueID;
  }
  public void setIssuerUniqueID(List<Boolean> issuerUniqueID) {
    this.issuerUniqueID = issuerUniqueID;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("subjectUniqueID")
  public List<Boolean> getSubjectUniqueID() {
    return subjectUniqueID;
  }
  public void setSubjectUniqueID(List<Boolean> subjectUniqueID) {
    this.subjectUniqueID = subjectUniqueID;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("keyUsage")
  public List<Boolean> getKeyUsage() {
    return keyUsage;
  }
  public void setKeyUsage(List<Boolean> keyUsage) {
    this.keyUsage = keyUsage;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("subjectAlternativeNames")
  public List<List<Object>> getSubjectAlternativeNames() {
    return subjectAlternativeNames;
  }
  public void setSubjectAlternativeNames(List<List<Object>> subjectAlternativeNames) {
    this.subjectAlternativeNames = subjectAlternativeNames;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("issuerAlternativeNames")
  public List<List<Object>> getIssuerAlternativeNames() {
    return issuerAlternativeNames;
  }
  public void setIssuerAlternativeNames(List<List<Object>> issuerAlternativeNames) {
    this.issuerAlternativeNames = issuerAlternativeNames;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("serialNumber")
  public Integer getSerialNumber() {
    return serialNumber;
  }
  public void setSerialNumber(Integer serialNumber) {
    this.serialNumber = serialNumber;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("extendedKeyUsage")
  public List<String> getExtendedKeyUsage() {
    return extendedKeyUsage;
  }
  public void setExtendedKeyUsage(List<String> extendedKeyUsage) {
    this.extendedKeyUsage = extendedKeyUsage;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("tbscertificate")
  public List<byte[]> getTbscertificate() {
    return tbscertificate;
  }
  public void setTbscertificate(List<byte[]> tbscertificate) {
    this.tbscertificate = tbscertificate;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("sigAlgName")
  public String getSigAlgName() {
    return sigAlgName;
  }
  public void setSigAlgName(String sigAlgName) {
    this.sigAlgName = sigAlgName;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("notAfter")
  public Date getNotAfter() {
    return notAfter;
  }
  public void setNotAfter(Date notAfter) {
    this.notAfter = notAfter;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("notBefore")
  public Date getNotBefore() {
    return notBefore;
  }
  public void setNotBefore(Date notBefore) {
    this.notBefore = notBefore;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("criticalExtensionOIDs")
  public List<String> getCriticalExtensionOIDs() {
    return criticalExtensionOIDs;
  }
  public void setCriticalExtensionOIDs(List<String> criticalExtensionOIDs) {
    this.criticalExtensionOIDs = criticalExtensionOIDs;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("nonCriticalExtensionOIDs")
  public List<String> getNonCriticalExtensionOIDs() {
    return nonCriticalExtensionOIDs;
  }
  public void setNonCriticalExtensionOIDs(List<String> nonCriticalExtensionOIDs) {
    this.nonCriticalExtensionOIDs = nonCriticalExtensionOIDs;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("encoded")
  public List<byte[]> getEncoded() {
    return encoded;
  }
  public void setEncoded(List<byte[]> encoded) {
    this.encoded = encoded;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("publicKey")
  public ConnectionInfoCertPublicKey getPublicKey() {
    return publicKey;
  }
  public void setPublicKey(ConnectionInfoCertPublicKey publicKey) {
    this.publicKey = publicKey;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ConnectionInfoCert connectionInfoCert = (ConnectionInfoCert) o;
    return Objects.equals(type, connectionInfoCert.type) &&
        Objects.equals(subjectX500Principal, connectionInfoCert.subjectX500Principal) &&
        Objects.equals(issuerX500Principal, connectionInfoCert.issuerX500Principal) &&
        Objects.equals(signature, connectionInfoCert.signature) &&
        Objects.equals(basicConstraints, connectionInfoCert.basicConstraints) &&
        Objects.equals(version, connectionInfoCert.version) &&
        Objects.equals(issuerDN, connectionInfoCert.issuerDN) &&
        Objects.equals(subjectDN, connectionInfoCert.subjectDN) &&
        Objects.equals(sigAlgOID, connectionInfoCert.sigAlgOID) &&
        Objects.equals(sigAlgParams, connectionInfoCert.sigAlgParams) &&
        Objects.equals(issuerUniqueID, connectionInfoCert.issuerUniqueID) &&
        Objects.equals(subjectUniqueID, connectionInfoCert.subjectUniqueID) &&
        Objects.equals(keyUsage, connectionInfoCert.keyUsage) &&
        Objects.equals(subjectAlternativeNames, connectionInfoCert.subjectAlternativeNames) &&
        Objects.equals(issuerAlternativeNames, connectionInfoCert.issuerAlternativeNames) &&
        Objects.equals(serialNumber, connectionInfoCert.serialNumber) &&
        Objects.equals(extendedKeyUsage, connectionInfoCert.extendedKeyUsage) &&
        Objects.equals(tbscertificate, connectionInfoCert.tbscertificate) &&
        Objects.equals(sigAlgName, connectionInfoCert.sigAlgName) &&
        Objects.equals(notAfter, connectionInfoCert.notAfter) &&
        Objects.equals(notBefore, connectionInfoCert.notBefore) &&
        Objects.equals(criticalExtensionOIDs, connectionInfoCert.criticalExtensionOIDs) &&
        Objects.equals(nonCriticalExtensionOIDs, connectionInfoCert.nonCriticalExtensionOIDs) &&
        Objects.equals(encoded, connectionInfoCert.encoded) &&
        Objects.equals(publicKey, connectionInfoCert.publicKey);
  }

  @Override
  public int hashCode() {
    return Objects.hash(type, subjectX500Principal, issuerX500Principal, signature, basicConstraints, version, issuerDN, subjectDN, sigAlgOID, sigAlgParams, issuerUniqueID, subjectUniqueID, keyUsage, subjectAlternativeNames, issuerAlternativeNames, serialNumber, extendedKeyUsage, tbscertificate, sigAlgName, notAfter, notBefore, criticalExtensionOIDs, nonCriticalExtensionOIDs, encoded, publicKey);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ConnectionInfoCert {\n");
    
    sb.append("    type: ").append(toIndentedString(type)).append("\n");
    sb.append("    subjectX500Principal: ").append(toIndentedString(subjectX500Principal)).append("\n");
    sb.append("    issuerX500Principal: ").append(toIndentedString(issuerX500Principal)).append("\n");
    sb.append("    signature: ").append(toIndentedString(signature)).append("\n");
    sb.append("    basicConstraints: ").append(toIndentedString(basicConstraints)).append("\n");
    sb.append("    version: ").append(toIndentedString(version)).append("\n");
    sb.append("    issuerDN: ").append(toIndentedString(issuerDN)).append("\n");
    sb.append("    subjectDN: ").append(toIndentedString(subjectDN)).append("\n");
    sb.append("    sigAlgOID: ").append(toIndentedString(sigAlgOID)).append("\n");
    sb.append("    sigAlgParams: ").append(toIndentedString(sigAlgParams)).append("\n");
    sb.append("    issuerUniqueID: ").append(toIndentedString(issuerUniqueID)).append("\n");
    sb.append("    subjectUniqueID: ").append(toIndentedString(subjectUniqueID)).append("\n");
    sb.append("    keyUsage: ").append(toIndentedString(keyUsage)).append("\n");
    sb.append("    subjectAlternativeNames: ").append(toIndentedString(subjectAlternativeNames)).append("\n");
    sb.append("    issuerAlternativeNames: ").append(toIndentedString(issuerAlternativeNames)).append("\n");
    sb.append("    serialNumber: ").append(toIndentedString(serialNumber)).append("\n");
    sb.append("    extendedKeyUsage: ").append(toIndentedString(extendedKeyUsage)).append("\n");
    sb.append("    tbscertificate: ").append(toIndentedString(tbscertificate)).append("\n");
    sb.append("    sigAlgName: ").append(toIndentedString(sigAlgName)).append("\n");
    sb.append("    notAfter: ").append(toIndentedString(notAfter)).append("\n");
    sb.append("    notBefore: ").append(toIndentedString(notBefore)).append("\n");
    sb.append("    criticalExtensionOIDs: ").append(toIndentedString(criticalExtensionOIDs)).append("\n");
    sb.append("    nonCriticalExtensionOIDs: ").append(toIndentedString(nonCriticalExtensionOIDs)).append("\n");
    sb.append("    encoded: ").append(toIndentedString(encoded)).append("\n");
    sb.append("    publicKey: ").append(toIndentedString(publicKey)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
