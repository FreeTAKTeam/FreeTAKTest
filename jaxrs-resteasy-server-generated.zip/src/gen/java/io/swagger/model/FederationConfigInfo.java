package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.FederationPort;
import io.swagger.model.Mission;
import io.swagger.model.V1Tls;
import java.util.List;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class FederationConfigInfo   {
  private Boolean serverPortEnabled = null;  private Integer serverPortv1 = null;  private Integer serverPortv2 = null;  private Boolean serverPortEnabledv2 = null;  private String truststorePath = null;  private String truststorePass = null;  private String tlsVersion = null;  private String webBaseURL = null;  private Boolean allowMissionFederation = null;  private Boolean allowDataFeedFederation = null;  private Boolean allowFederatedDelete = null;  private Boolean enableMissionFederationDisruptionTolerance = null;  private Long missionFederationDisruptionToleranceRecencySeconds = null;  private List<Mission> missionInterval = new ArrayList<Mission>();  private Integer coreVersion = null;  private List<FederationPort> v1Ports = new ArrayList<FederationPort>();  private List<V1Tls> v1Tls = new ArrayList<V1Tls>();  private Boolean federatedGroupMapping = null;  private Boolean automaticGroupMapping = null;  private Boolean enableDataPackageAndMissionFileFilter = null;  private List<String> fileExtension = new ArrayList<String>();  private Boolean enabled = null;  private Boolean enableMissionFederationFileFilter = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("serverPortEnabled")
  public Boolean isServerPortEnabled() {
    return serverPortEnabled;
  }
  public void setServerPortEnabled(Boolean serverPortEnabled) {
    this.serverPortEnabled = serverPortEnabled;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("serverPortv1")
  public Integer getServerPortv1() {
    return serverPortv1;
  }
  public void setServerPortv1(Integer serverPortv1) {
    this.serverPortv1 = serverPortv1;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("serverPortv2")
  public Integer getServerPortv2() {
    return serverPortv2;
  }
  public void setServerPortv2(Integer serverPortv2) {
    this.serverPortv2 = serverPortv2;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("serverPortEnabledv2")
  public Boolean isServerPortEnabledv2() {
    return serverPortEnabledv2;
  }
  public void setServerPortEnabledv2(Boolean serverPortEnabledv2) {
    this.serverPortEnabledv2 = serverPortEnabledv2;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("truststorePath")
  public String getTruststorePath() {
    return truststorePath;
  }
  public void setTruststorePath(String truststorePath) {
    this.truststorePath = truststorePath;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("truststorePass")
  public String getTruststorePass() {
    return truststorePass;
  }
  public void setTruststorePass(String truststorePass) {
    this.truststorePass = truststorePass;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("tlsVersion")
  public String getTlsVersion() {
    return tlsVersion;
  }
  public void setTlsVersion(String tlsVersion) {
    this.tlsVersion = tlsVersion;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("webBaseURL")
  public String getWebBaseURL() {
    return webBaseURL;
  }
  public void setWebBaseURL(String webBaseURL) {
    this.webBaseURL = webBaseURL;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("allowMissionFederation")
  public Boolean isAllowMissionFederation() {
    return allowMissionFederation;
  }
  public void setAllowMissionFederation(Boolean allowMissionFederation) {
    this.allowMissionFederation = allowMissionFederation;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("allowDataFeedFederation")
  public Boolean isAllowDataFeedFederation() {
    return allowDataFeedFederation;
  }
  public void setAllowDataFeedFederation(Boolean allowDataFeedFederation) {
    this.allowDataFeedFederation = allowDataFeedFederation;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("allowFederatedDelete")
  public Boolean isAllowFederatedDelete() {
    return allowFederatedDelete;
  }
  public void setAllowFederatedDelete(Boolean allowFederatedDelete) {
    this.allowFederatedDelete = allowFederatedDelete;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("enableMissionFederationDisruptionTolerance")
  public Boolean isEnableMissionFederationDisruptionTolerance() {
    return enableMissionFederationDisruptionTolerance;
  }
  public void setEnableMissionFederationDisruptionTolerance(Boolean enableMissionFederationDisruptionTolerance) {
    this.enableMissionFederationDisruptionTolerance = enableMissionFederationDisruptionTolerance;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("missionFederationDisruptionToleranceRecencySeconds")
  public Long getMissionFederationDisruptionToleranceRecencySeconds() {
    return missionFederationDisruptionToleranceRecencySeconds;
  }
  public void setMissionFederationDisruptionToleranceRecencySeconds(Long missionFederationDisruptionToleranceRecencySeconds) {
    this.missionFederationDisruptionToleranceRecencySeconds = missionFederationDisruptionToleranceRecencySeconds;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("missionInterval")
  public List<Mission> getMissionInterval() {
    return missionInterval;
  }
  public void setMissionInterval(List<Mission> missionInterval) {
    this.missionInterval = missionInterval;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("coreVersion")
  public Integer getCoreVersion() {
    return coreVersion;
  }
  public void setCoreVersion(Integer coreVersion) {
    this.coreVersion = coreVersion;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("v1Ports")
  public List<FederationPort> getV1Ports() {
    return v1Ports;
  }
  public void setV1Ports(List<FederationPort> v1Ports) {
    this.v1Ports = v1Ports;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("v1Tls")
  public List<V1Tls> getV1Tls() {
    return v1Tls;
  }
  public void setV1Tls(List<V1Tls> v1Tls) {
    this.v1Tls = v1Tls;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("federatedGroupMapping")
  public Boolean isFederatedGroupMapping() {
    return federatedGroupMapping;
  }
  public void setFederatedGroupMapping(Boolean federatedGroupMapping) {
    this.federatedGroupMapping = federatedGroupMapping;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("automaticGroupMapping")
  public Boolean isAutomaticGroupMapping() {
    return automaticGroupMapping;
  }
  public void setAutomaticGroupMapping(Boolean automaticGroupMapping) {
    this.automaticGroupMapping = automaticGroupMapping;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("enableDataPackageAndMissionFileFilter")
  public Boolean isEnableDataPackageAndMissionFileFilter() {
    return enableDataPackageAndMissionFileFilter;
  }
  public void setEnableDataPackageAndMissionFileFilter(Boolean enableDataPackageAndMissionFileFilter) {
    this.enableDataPackageAndMissionFileFilter = enableDataPackageAndMissionFileFilter;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("fileExtension")
  public List<String> getFileExtension() {
    return fileExtension;
  }
  public void setFileExtension(List<String> fileExtension) {
    this.fileExtension = fileExtension;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("enabled")
  public Boolean isEnabled() {
    return enabled;
  }
  public void setEnabled(Boolean enabled) {
    this.enabled = enabled;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("enableMissionFederationFileFilter")
  public Boolean isEnableMissionFederationFileFilter() {
    return enableMissionFederationFileFilter;
  }
  public void setEnableMissionFederationFileFilter(Boolean enableMissionFederationFileFilter) {
    this.enableMissionFederationFileFilter = enableMissionFederationFileFilter;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    FederationConfigInfo federationConfigInfo = (FederationConfigInfo) o;
    return Objects.equals(serverPortEnabled, federationConfigInfo.serverPortEnabled) &&
        Objects.equals(serverPortv1, federationConfigInfo.serverPortv1) &&
        Objects.equals(serverPortv2, federationConfigInfo.serverPortv2) &&
        Objects.equals(serverPortEnabledv2, federationConfigInfo.serverPortEnabledv2) &&
        Objects.equals(truststorePath, federationConfigInfo.truststorePath) &&
        Objects.equals(truststorePass, federationConfigInfo.truststorePass) &&
        Objects.equals(tlsVersion, federationConfigInfo.tlsVersion) &&
        Objects.equals(webBaseURL, federationConfigInfo.webBaseURL) &&
        Objects.equals(allowMissionFederation, federationConfigInfo.allowMissionFederation) &&
        Objects.equals(allowDataFeedFederation, federationConfigInfo.allowDataFeedFederation) &&
        Objects.equals(allowFederatedDelete, federationConfigInfo.allowFederatedDelete) &&
        Objects.equals(enableMissionFederationDisruptionTolerance, federationConfigInfo.enableMissionFederationDisruptionTolerance) &&
        Objects.equals(missionFederationDisruptionToleranceRecencySeconds, federationConfigInfo.missionFederationDisruptionToleranceRecencySeconds) &&
        Objects.equals(missionInterval, federationConfigInfo.missionInterval) &&
        Objects.equals(coreVersion, federationConfigInfo.coreVersion) &&
        Objects.equals(v1Ports, federationConfigInfo.v1Ports) &&
        Objects.equals(v1Tls, federationConfigInfo.v1Tls) &&
        Objects.equals(federatedGroupMapping, federationConfigInfo.federatedGroupMapping) &&
        Objects.equals(automaticGroupMapping, federationConfigInfo.automaticGroupMapping) &&
        Objects.equals(enableDataPackageAndMissionFileFilter, federationConfigInfo.enableDataPackageAndMissionFileFilter) &&
        Objects.equals(fileExtension, federationConfigInfo.fileExtension) &&
        Objects.equals(enabled, federationConfigInfo.enabled) &&
        Objects.equals(enableMissionFederationFileFilter, federationConfigInfo.enableMissionFederationFileFilter);
  }

  @Override
  public int hashCode() {
    return Objects.hash(serverPortEnabled, serverPortv1, serverPortv2, serverPortEnabledv2, truststorePath, truststorePass, tlsVersion, webBaseURL, allowMissionFederation, allowDataFeedFederation, allowFederatedDelete, enableMissionFederationDisruptionTolerance, missionFederationDisruptionToleranceRecencySeconds, missionInterval, coreVersion, v1Ports, v1Tls, federatedGroupMapping, automaticGroupMapping, enableDataPackageAndMissionFileFilter, fileExtension, enabled, enableMissionFederationFileFilter);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class FederationConfigInfo {\n");
    
    sb.append("    serverPortEnabled: ").append(toIndentedString(serverPortEnabled)).append("\n");
    sb.append("    serverPortv1: ").append(toIndentedString(serverPortv1)).append("\n");
    sb.append("    serverPortv2: ").append(toIndentedString(serverPortv2)).append("\n");
    sb.append("    serverPortEnabledv2: ").append(toIndentedString(serverPortEnabledv2)).append("\n");
    sb.append("    truststorePath: ").append(toIndentedString(truststorePath)).append("\n");
    sb.append("    truststorePass: ").append(toIndentedString(truststorePass)).append("\n");
    sb.append("    tlsVersion: ").append(toIndentedString(tlsVersion)).append("\n");
    sb.append("    webBaseURL: ").append(toIndentedString(webBaseURL)).append("\n");
    sb.append("    allowMissionFederation: ").append(toIndentedString(allowMissionFederation)).append("\n");
    sb.append("    allowDataFeedFederation: ").append(toIndentedString(allowDataFeedFederation)).append("\n");
    sb.append("    allowFederatedDelete: ").append(toIndentedString(allowFederatedDelete)).append("\n");
    sb.append("    enableMissionFederationDisruptionTolerance: ").append(toIndentedString(enableMissionFederationDisruptionTolerance)).append("\n");
    sb.append("    missionFederationDisruptionToleranceRecencySeconds: ").append(toIndentedString(missionFederationDisruptionToleranceRecencySeconds)).append("\n");
    sb.append("    missionInterval: ").append(toIndentedString(missionInterval)).append("\n");
    sb.append("    coreVersion: ").append(toIndentedString(coreVersion)).append("\n");
    sb.append("    v1Ports: ").append(toIndentedString(v1Ports)).append("\n");
    sb.append("    v1Tls: ").append(toIndentedString(v1Tls)).append("\n");
    sb.append("    federatedGroupMapping: ").append(toIndentedString(federatedGroupMapping)).append("\n");
    sb.append("    automaticGroupMapping: ").append(toIndentedString(automaticGroupMapping)).append("\n");
    sb.append("    enableDataPackageAndMissionFileFilter: ").append(toIndentedString(enableDataPackageAndMissionFileFilter)).append("\n");
    sb.append("    fileExtension: ").append(toIndentedString(fileExtension)).append("\n");
    sb.append("    enabled: ").append(toIndentedString(enabled)).append("\n");
    sb.append("    enableMissionFederationFileFilter: ").append(toIndentedString(enableMissionFederationFileFilter)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
