package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import java.util.List;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class NewUserModel   {
  private String username = null;  private String password = null;  private List<String> groupList = new ArrayList<String>();  private List<String> groupListIN = new ArrayList<String>();  private List<String> groupListOUT = new ArrayList<String>();

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("username")
  public String getUsername() {
    return username;
  }
  public void setUsername(String username) {
    this.username = username;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("password")
  public String getPassword() {
    return password;
  }
  public void setPassword(String password) {
    this.password = password;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("groupList")
  public List<String> getGroupList() {
    return groupList;
  }
  public void setGroupList(List<String> groupList) {
    this.groupList = groupList;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("groupListIN")
  public List<String> getGroupListIN() {
    return groupListIN;
  }
  public void setGroupListIN(List<String> groupListIN) {
    this.groupListIN = groupListIN;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("groupListOUT")
  public List<String> getGroupListOUT() {
    return groupListOUT;
  }
  public void setGroupListOUT(List<String> groupListOUT) {
    this.groupListOUT = groupListOUT;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    NewUserModel newUserModel = (NewUserModel) o;
    return Objects.equals(username, newUserModel.username) &&
        Objects.equals(password, newUserModel.password) &&
        Objects.equals(groupList, newUserModel.groupList) &&
        Objects.equals(groupListIN, newUserModel.groupListIN) &&
        Objects.equals(groupListOUT, newUserModel.groupListOUT);
  }

  @Override
  public int hashCode() {
    return Objects.hash(username, password, groupList, groupListIN, groupListOUT);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class NewUserModel {\n");
    
    sb.append("    username: ").append(toIndentedString(username)).append("\n");
    sb.append("    password: ").append(toIndentedString(password)).append("\n");
    sb.append("    groupList: ").append(toIndentedString(groupList)).append("\n");
    sb.append("    groupListIN: ").append(toIndentedString(groupListIN)).append("\n");
    sb.append("    groupListOUT: ").append(toIndentedString(groupListOUT)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
