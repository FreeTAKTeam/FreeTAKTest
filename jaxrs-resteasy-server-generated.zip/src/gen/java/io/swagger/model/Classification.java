package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.Caveat;
import java.util.List;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class Classification   {
  private String level = null;  private List<Caveat> caveats = new ArrayList<Caveat>();

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("level")
  public String getLevel() {
    return level;
  }
  public void setLevel(String level) {
    this.level = level;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("caveats")
  public List<Caveat> getCaveats() {
    return caveats;
  }
  public void setCaveats(List<Caveat> caveats) {
    this.caveats = caveats;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Classification classification = (Classification) o;
    return Objects.equals(level, classification.level) &&
        Objects.equals(caveats, classification.caveats);
  }

  @Override
  public int hashCode() {
    return Objects.hash(level, caveats);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Classification {\n");
    
    sb.append("    level: ").append(toIndentedString(level)).append("\n");
    sb.append("    caveats: ").append(toIndentedString(caveats)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
