package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.Filter;
import java.util.List;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class ModelStatic   {
  private List<String> filtergroup = new ArrayList<String>();  private Filter filter = null;  private String name = null;  private String protocol = null;  private String address = null;  private Integer port = null;  private String xpath = null;  private Boolean federated = null;  private String iface = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("filtergroup")
  public List<String> getFiltergroup() {
    return filtergroup;
  }
  public void setFiltergroup(List<String> filtergroup) {
    this.filtergroup = filtergroup;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("filter")
  public Filter getFilter() {
    return filter;
  }
  public void setFilter(Filter filter) {
    this.filter = filter;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("name")
  public String getName() {
    return name;
  }
  public void setName(String name) {
    this.name = name;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("protocol")
  public String getProtocol() {
    return protocol;
  }
  public void setProtocol(String protocol) {
    this.protocol = protocol;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("address")
  public String getAddress() {
    return address;
  }
  public void setAddress(String address) {
    this.address = address;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("port")
  public Integer getPort() {
    return port;
  }
  public void setPort(Integer port) {
    this.port = port;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("xpath")
  public String getXpath() {
    return xpath;
  }
  public void setXpath(String xpath) {
    this.xpath = xpath;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("federated")
  public Boolean isFederated() {
    return federated;
  }
  public void setFederated(Boolean federated) {
    this.federated = federated;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("iface")
  public String getIface() {
    return iface;
  }
  public void setIface(String iface) {
    this.iface = iface;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ModelStatic _static = (ModelStatic) o;
    return Objects.equals(filtergroup, _static.filtergroup) &&
        Objects.equals(filter, _static.filter) &&
        Objects.equals(name, _static.name) &&
        Objects.equals(protocol, _static.protocol) &&
        Objects.equals(address, _static.address) &&
        Objects.equals(port, _static.port) &&
        Objects.equals(xpath, _static.xpath) &&
        Objects.equals(federated, _static.federated) &&
        Objects.equals(iface, _static.iface);
  }

  @Override
  public int hashCode() {
    return Objects.hash(filtergroup, filter, name, protocol, address, port, xpath, federated, iface);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ModelStatic {\n");
    
    sb.append("    filtergroup: ").append(toIndentedString(filtergroup)).append("\n");
    sb.append("    filter: ").append(toIndentedString(filter)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    protocol: ").append(toIndentedString(protocol)).append("\n");
    sb.append("    address: ").append(toIndentedString(address)).append("\n");
    sb.append("    port: ").append(toIndentedString(port)).append("\n");
    sb.append("    xpath: ").append(toIndentedString(xpath)).append("\n");
    sb.append("    federated: ").append(toIndentedString(federated)).append("\n");
    sb.append("    iface: ").append(toIndentedString(iface)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
