package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import io.swagger.model.CertificateConfig;
import io.swagger.model.MicrosoftCAConfig;
import io.swagger.model.TAKServerCAConfig;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class CertificateSigning   {
  private CertificateConfig certificateConfig = null;  private MicrosoftCAConfig microsoftCAConfig = null;  /**
   * Gets or Sets ca
   */
  public enum CaEnum {
    MICROSOFT_CA("MICROSOFT_CA"),
    TAK_SERVER("TAK_SERVER");
    private String value;

    CaEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }
  }
  private CaEnum ca = null;  private TAKServerCAConfig takserverCAConfig = null;

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("certificateConfig")
  @NotNull
  public CertificateConfig getCertificateConfig() {
    return certificateConfig;
  }
  public void setCertificateConfig(CertificateConfig certificateConfig) {
    this.certificateConfig = certificateConfig;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("microsoftCAConfig")
  public MicrosoftCAConfig getMicrosoftCAConfig() {
    return microsoftCAConfig;
  }
  public void setMicrosoftCAConfig(MicrosoftCAConfig microsoftCAConfig) {
    this.microsoftCAConfig = microsoftCAConfig;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("ca")
  public CaEnum getCa() {
    return ca;
  }
  public void setCa(CaEnum ca) {
    this.ca = ca;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("takserverCAConfig")
  public TAKServerCAConfig getTakserverCAConfig() {
    return takserverCAConfig;
  }
  public void setTakserverCAConfig(TAKServerCAConfig takserverCAConfig) {
    this.takserverCAConfig = takserverCAConfig;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    CertificateSigning certificateSigning = (CertificateSigning) o;
    return Objects.equals(certificateConfig, certificateSigning.certificateConfig) &&
        Objects.equals(microsoftCAConfig, certificateSigning.microsoftCAConfig) &&
        Objects.equals(ca, certificateSigning.ca) &&
        Objects.equals(takserverCAConfig, certificateSigning.takserverCAConfig);
  }

  @Override
  public int hashCode() {
    return Objects.hash(certificateConfig, microsoftCAConfig, ca, takserverCAConfig);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class CertificateSigning {\n");
    
    sb.append("    certificateConfig: ").append(toIndentedString(certificateConfig)).append("\n");
    sb.append("    microsoftCAConfig: ").append(toIndentedString(microsoftCAConfig)).append("\n");
    sb.append("    ca: ").append(toIndentedString(ca)).append("\n");
    sb.append("    takserverCAConfig: ").append(toIndentedString(takserverCAConfig)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
