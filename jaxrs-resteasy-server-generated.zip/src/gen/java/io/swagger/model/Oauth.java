package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.AuthServer;
import io.swagger.model.Client;
import java.util.List;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class Oauth   {
  private List<Client> client = new ArrayList<Client>();  private AuthServer authServer = null;  private Boolean oauthAddAnonymous = null;  private String readOnlyGroup = null;  private String readGroupSuffix = null;  private String writeGroupSuffix = null;  private String groupprefix = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("client")
  public List<Client> getClient() {
    return client;
  }
  public void setClient(List<Client> client) {
    this.client = client;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("authServer")
  public AuthServer getAuthServer() {
    return authServer;
  }
  public void setAuthServer(AuthServer authServer) {
    this.authServer = authServer;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("oauthAddAnonymous")
  public Boolean isOauthAddAnonymous() {
    return oauthAddAnonymous;
  }
  public void setOauthAddAnonymous(Boolean oauthAddAnonymous) {
    this.oauthAddAnonymous = oauthAddAnonymous;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("readOnlyGroup")
  public String getReadOnlyGroup() {
    return readOnlyGroup;
  }
  public void setReadOnlyGroup(String readOnlyGroup) {
    this.readOnlyGroup = readOnlyGroup;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("readGroupSuffix")
  public String getReadGroupSuffix() {
    return readGroupSuffix;
  }
  public void setReadGroupSuffix(String readGroupSuffix) {
    this.readGroupSuffix = readGroupSuffix;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("writeGroupSuffix")
  public String getWriteGroupSuffix() {
    return writeGroupSuffix;
  }
  public void setWriteGroupSuffix(String writeGroupSuffix) {
    this.writeGroupSuffix = writeGroupSuffix;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("groupprefix")
  public String getGroupprefix() {
    return groupprefix;
  }
  public void setGroupprefix(String groupprefix) {
    this.groupprefix = groupprefix;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Oauth oauth = (Oauth) o;
    return Objects.equals(client, oauth.client) &&
        Objects.equals(authServer, oauth.authServer) &&
        Objects.equals(oauthAddAnonymous, oauth.oauthAddAnonymous) &&
        Objects.equals(readOnlyGroup, oauth.readOnlyGroup) &&
        Objects.equals(readGroupSuffix, oauth.readGroupSuffix) &&
        Objects.equals(writeGroupSuffix, oauth.writeGroupSuffix) &&
        Objects.equals(groupprefix, oauth.groupprefix);
  }

  @Override
  public int hashCode() {
    return Objects.hash(client, authServer, oauthAddAnonymous, readOnlyGroup, readGroupSuffix, writeGroupSuffix, groupprefix);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Oauth {\n");
    
    sb.append("    client: ").append(toIndentedString(client)).append("\n");
    sb.append("    authServer: ").append(toIndentedString(authServer)).append("\n");
    sb.append("    oauthAddAnonymous: ").append(toIndentedString(oauthAddAnonymous)).append("\n");
    sb.append("    readOnlyGroup: ").append(toIndentedString(readOnlyGroup)).append("\n");
    sb.append("    readGroupSuffix: ").append(toIndentedString(readGroupSuffix)).append("\n");
    sb.append("    writeGroupSuffix: ").append(toIndentedString(writeGroupSuffix)).append("\n");
    sb.append("    groupprefix: ").append(toIndentedString(groupprefix)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
