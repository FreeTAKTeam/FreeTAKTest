package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class SecurityConfigInfo   {
  private String keystoreFile = null;  private String truststoreFile = null;  private String keystorePass = null;  private String truststorePass = null;  private String tlsVersion = null;  private Boolean x509Groups = null;  private Boolean x509addAnon = null;  private Boolean enableEnrollment = null;  private String caType = null;  private String signingKeystoreFile = null;  private String signingKeystorePass = null;  private Integer validityDays = null;  private String mscaUserName = null;  private String mscaPassword = null;  private String mscaTruststore = null;  private String mscaTruststorePass = null;  private String mscaTemplateName = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("keystoreFile")
  public String getKeystoreFile() {
    return keystoreFile;
  }
  public void setKeystoreFile(String keystoreFile) {
    this.keystoreFile = keystoreFile;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("truststoreFile")
  public String getTruststoreFile() {
    return truststoreFile;
  }
  public void setTruststoreFile(String truststoreFile) {
    this.truststoreFile = truststoreFile;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("keystorePass")
  public String getKeystorePass() {
    return keystorePass;
  }
  public void setKeystorePass(String keystorePass) {
    this.keystorePass = keystorePass;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("truststorePass")
  public String getTruststorePass() {
    return truststorePass;
  }
  public void setTruststorePass(String truststorePass) {
    this.truststorePass = truststorePass;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("tlsVersion")
  public String getTlsVersion() {
    return tlsVersion;
  }
  public void setTlsVersion(String tlsVersion) {
    this.tlsVersion = tlsVersion;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("x509Groups")
  public Boolean isX509Groups() {
    return x509Groups;
  }
  public void setX509Groups(Boolean x509Groups) {
    this.x509Groups = x509Groups;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("x509addAnon")
  public Boolean isX509addAnon() {
    return x509addAnon;
  }
  public void setX509addAnon(Boolean x509addAnon) {
    this.x509addAnon = x509addAnon;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("enableEnrollment")
  public Boolean isEnableEnrollment() {
    return enableEnrollment;
  }
  public void setEnableEnrollment(Boolean enableEnrollment) {
    this.enableEnrollment = enableEnrollment;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("caType")
  public String getCaType() {
    return caType;
  }
  public void setCaType(String caType) {
    this.caType = caType;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("signingKeystoreFile")
  public String getSigningKeystoreFile() {
    return signingKeystoreFile;
  }
  public void setSigningKeystoreFile(String signingKeystoreFile) {
    this.signingKeystoreFile = signingKeystoreFile;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("signingKeystorePass")
  public String getSigningKeystorePass() {
    return signingKeystorePass;
  }
  public void setSigningKeystorePass(String signingKeystorePass) {
    this.signingKeystorePass = signingKeystorePass;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("validityDays")
  public Integer getValidityDays() {
    return validityDays;
  }
  public void setValidityDays(Integer validityDays) {
    this.validityDays = validityDays;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("mscaUserName")
  public String getMscaUserName() {
    return mscaUserName;
  }
  public void setMscaUserName(String mscaUserName) {
    this.mscaUserName = mscaUserName;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("mscaPassword")
  public String getMscaPassword() {
    return mscaPassword;
  }
  public void setMscaPassword(String mscaPassword) {
    this.mscaPassword = mscaPassword;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("mscaTruststore")
  public String getMscaTruststore() {
    return mscaTruststore;
  }
  public void setMscaTruststore(String mscaTruststore) {
    this.mscaTruststore = mscaTruststore;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("mscaTruststorePass")
  public String getMscaTruststorePass() {
    return mscaTruststorePass;
  }
  public void setMscaTruststorePass(String mscaTruststorePass) {
    this.mscaTruststorePass = mscaTruststorePass;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("mscaTemplateName")
  public String getMscaTemplateName() {
    return mscaTemplateName;
  }
  public void setMscaTemplateName(String mscaTemplateName) {
    this.mscaTemplateName = mscaTemplateName;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    SecurityConfigInfo securityConfigInfo = (SecurityConfigInfo) o;
    return Objects.equals(keystoreFile, securityConfigInfo.keystoreFile) &&
        Objects.equals(truststoreFile, securityConfigInfo.truststoreFile) &&
        Objects.equals(keystorePass, securityConfigInfo.keystorePass) &&
        Objects.equals(truststorePass, securityConfigInfo.truststorePass) &&
        Objects.equals(tlsVersion, securityConfigInfo.tlsVersion) &&
        Objects.equals(x509Groups, securityConfigInfo.x509Groups) &&
        Objects.equals(x509addAnon, securityConfigInfo.x509addAnon) &&
        Objects.equals(enableEnrollment, securityConfigInfo.enableEnrollment) &&
        Objects.equals(caType, securityConfigInfo.caType) &&
        Objects.equals(signingKeystoreFile, securityConfigInfo.signingKeystoreFile) &&
        Objects.equals(signingKeystorePass, securityConfigInfo.signingKeystorePass) &&
        Objects.equals(validityDays, securityConfigInfo.validityDays) &&
        Objects.equals(mscaUserName, securityConfigInfo.mscaUserName) &&
        Objects.equals(mscaPassword, securityConfigInfo.mscaPassword) &&
        Objects.equals(mscaTruststore, securityConfigInfo.mscaTruststore) &&
        Objects.equals(mscaTruststorePass, securityConfigInfo.mscaTruststorePass) &&
        Objects.equals(mscaTemplateName, securityConfigInfo.mscaTemplateName);
  }

  @Override
  public int hashCode() {
    return Objects.hash(keystoreFile, truststoreFile, keystorePass, truststorePass, tlsVersion, x509Groups, x509addAnon, enableEnrollment, caType, signingKeystoreFile, signingKeystorePass, validityDays, mscaUserName, mscaPassword, mscaTruststore, mscaTruststorePass, mscaTemplateName);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SecurityConfigInfo {\n");
    
    sb.append("    keystoreFile: ").append(toIndentedString(keystoreFile)).append("\n");
    sb.append("    truststoreFile: ").append(toIndentedString(truststoreFile)).append("\n");
    sb.append("    keystorePass: ").append(toIndentedString(keystorePass)).append("\n");
    sb.append("    truststorePass: ").append(toIndentedString(truststorePass)).append("\n");
    sb.append("    tlsVersion: ").append(toIndentedString(tlsVersion)).append("\n");
    sb.append("    x509Groups: ").append(toIndentedString(x509Groups)).append("\n");
    sb.append("    x509addAnon: ").append(toIndentedString(x509addAnon)).append("\n");
    sb.append("    enableEnrollment: ").append(toIndentedString(enableEnrollment)).append("\n");
    sb.append("    caType: ").append(toIndentedString(caType)).append("\n");
    sb.append("    signingKeystoreFile: ").append(toIndentedString(signingKeystoreFile)).append("\n");
    sb.append("    signingKeystorePass: ").append(toIndentedString(signingKeystorePass)).append("\n");
    sb.append("    validityDays: ").append(toIndentedString(validityDays)).append("\n");
    sb.append("    mscaUserName: ").append(toIndentedString(mscaUserName)).append("\n");
    sb.append("    mscaPassword: ").append(toIndentedString(mscaPassword)).append("\n");
    sb.append("    mscaTruststore: ").append(toIndentedString(mscaTruststore)).append("\n");
    sb.append("    mscaTruststorePass: ").append(toIndentedString(mscaTruststorePass)).append("\n");
    sb.append("    mscaTemplateName: ").append(toIndentedString(mscaTemplateName)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
