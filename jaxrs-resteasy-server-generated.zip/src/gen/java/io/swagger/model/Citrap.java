package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class Citrap   {
  private Boolean enableNotifications = null;  private String notificationCot = null;  private String nonsubscriberCotFilter = null;  private Integer searchRadius = null;  private Integer searchSecago = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("enableNotifications")
  public Boolean isEnableNotifications() {
    return enableNotifications;
  }
  public void setEnableNotifications(Boolean enableNotifications) {
    this.enableNotifications = enableNotifications;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("notificationCot")
  public String getNotificationCot() {
    return notificationCot;
  }
  public void setNotificationCot(String notificationCot) {
    this.notificationCot = notificationCot;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("nonsubscriberCotFilter")
  public String getNonsubscriberCotFilter() {
    return nonsubscriberCotFilter;
  }
  public void setNonsubscriberCotFilter(String nonsubscriberCotFilter) {
    this.nonsubscriberCotFilter = nonsubscriberCotFilter;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("searchRadius")
  public Integer getSearchRadius() {
    return searchRadius;
  }
  public void setSearchRadius(Integer searchRadius) {
    this.searchRadius = searchRadius;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("searchSecago")
  public Integer getSearchSecago() {
    return searchSecago;
  }
  public void setSearchSecago(Integer searchSecago) {
    this.searchSecago = searchSecago;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Citrap citrap = (Citrap) o;
    return Objects.equals(enableNotifications, citrap.enableNotifications) &&
        Objects.equals(notificationCot, citrap.notificationCot) &&
        Objects.equals(nonsubscriberCotFilter, citrap.nonsubscriberCotFilter) &&
        Objects.equals(searchRadius, citrap.searchRadius) &&
        Objects.equals(searchSecago, citrap.searchSecago);
  }

  @Override
  public int hashCode() {
    return Objects.hash(enableNotifications, notificationCot, nonsubscriberCotFilter, searchRadius, searchSecago);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Citrap {\n");
    
    sb.append("    enableNotifications: ").append(toIndentedString(enableNotifications)).append("\n");
    sb.append("    notificationCot: ").append(toIndentedString(notificationCot)).append("\n");
    sb.append("    nonsubscriberCotFilter: ").append(toIndentedString(nonsubscriberCotFilter)).append("\n");
    sb.append("    searchRadius: ").append(toIndentedString(searchRadius)).append("\n");
    sb.append("    searchSecago: ").append(toIndentedString(searchSecago)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
