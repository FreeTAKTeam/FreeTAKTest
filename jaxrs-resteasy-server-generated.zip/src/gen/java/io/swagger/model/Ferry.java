package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.Endpoint;
import java.util.List;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class Ferry   {
  private List<Endpoint> endpoint = new ArrayList<Endpoint>();  private Boolean enable = null;  private Integer stale = null;  private String webserver = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("endpoint")
  public List<Endpoint> getEndpoint() {
    return endpoint;
  }
  public void setEndpoint(List<Endpoint> endpoint) {
    this.endpoint = endpoint;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("enable")
  public Boolean isEnable() {
    return enable;
  }
  public void setEnable(Boolean enable) {
    this.enable = enable;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("stale")
  public Integer getStale() {
    return stale;
  }
  public void setStale(Integer stale) {
    this.stale = stale;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("webserver")
  public String getWebserver() {
    return webserver;
  }
  public void setWebserver(String webserver) {
    this.webserver = webserver;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Ferry ferry = (Ferry) o;
    return Objects.equals(endpoint, ferry.endpoint) &&
        Objects.equals(enable, ferry.enable) &&
        Objects.equals(stale, ferry.stale) &&
        Objects.equals(webserver, ferry.webserver);
  }

  @Override
  public int hashCode() {
    return Objects.hash(endpoint, enable, stale, webserver);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Ferry {\n");
    
    sb.append("    endpoint: ").append(toIndentedString(endpoint)).append("\n");
    sb.append("    enable: ").append(toIndentedString(enable)).append("\n");
    sb.append("    stale: ").append(toIndentedString(stale)).append("\n");
    sb.append("    webserver: ").append(toIndentedString(webserver)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
