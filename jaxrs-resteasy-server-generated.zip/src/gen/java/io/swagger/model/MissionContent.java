package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import java.util.List;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class MissionContent   {
  private List<String> hashes = new ArrayList<String>();  private List<String> uids = new ArrayList<String>();

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("hashes")
  public List<String> getHashes() {
    return hashes;
  }
  public void setHashes(List<String> hashes) {
    this.hashes = hashes;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("uids")
  public List<String> getUids() {
    return uids;
  }
  public void setUids(List<String> uids) {
    this.uids = uids;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    MissionContent missionContent = (MissionContent) o;
    return Objects.equals(hashes, missionContent.hashes) &&
        Objects.equals(uids, missionContent.uids);
  }

  @Override
  public int hashCode() {
    return Objects.hash(hashes, uids);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class MissionContent {\n");
    
    sb.append("    hashes: ").append(toIndentedString(hashes)).append("\n");
    sb.append("    uids: ").append(toIndentedString(uids)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
