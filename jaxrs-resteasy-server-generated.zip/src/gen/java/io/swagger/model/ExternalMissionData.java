package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class ExternalMissionData   {
  private String name = null;  private String tool = null;  private String urlData = null;  private String notes = null;  private String uid = null;  private String urlView = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("name")
  public String getName() {
    return name;
  }
  public void setName(String name) {
    this.name = name;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("tool")
  public String getTool() {
    return tool;
  }
  public void setTool(String tool) {
    this.tool = tool;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("urlData")
  public String getUrlData() {
    return urlData;
  }
  public void setUrlData(String urlData) {
    this.urlData = urlData;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("notes")
  public String getNotes() {
    return notes;
  }
  public void setNotes(String notes) {
    this.notes = notes;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("uid")
  public String getUid() {
    return uid;
  }
  public void setUid(String uid) {
    this.uid = uid;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("urlView")
  public String getUrlView() {
    return urlView;
  }
  public void setUrlView(String urlView) {
    this.urlView = urlView;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ExternalMissionData externalMissionData = (ExternalMissionData) o;
    return Objects.equals(name, externalMissionData.name) &&
        Objects.equals(tool, externalMissionData.tool) &&
        Objects.equals(urlData, externalMissionData.urlData) &&
        Objects.equals(notes, externalMissionData.notes) &&
        Objects.equals(uid, externalMissionData.uid) &&
        Objects.equals(urlView, externalMissionData.urlView);
  }

  @Override
  public int hashCode() {
    return Objects.hash(name, tool, urlData, notes, uid, urlView);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ExternalMissionData {\n");
    
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    tool: ").append(toIndentedString(tool)).append("\n");
    sb.append("    urlData: ").append(toIndentedString(urlData)).append("\n");
    sb.append("    notes: ").append(toIndentedString(notes)).append("\n");
    sb.append("    uid: ").append(toIndentedString(uid)).append("\n");
    sb.append("    urlView: ").append(toIndentedString(urlView)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
