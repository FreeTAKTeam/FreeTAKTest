package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.DeliveryRateLimiter;
import io.swagger.model.DosRateLimiter;
import io.swagger.model.ReadRateLimiter;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class Qos   {
  private DeliveryRateLimiter deliveryRateLimiter = null;  private ReadRateLimiter readRateLimiter = null;  private DosRateLimiter dosRateLimiter = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("deliveryRateLimiter")
  public DeliveryRateLimiter getDeliveryRateLimiter() {
    return deliveryRateLimiter;
  }
  public void setDeliveryRateLimiter(DeliveryRateLimiter deliveryRateLimiter) {
    this.deliveryRateLimiter = deliveryRateLimiter;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("readRateLimiter")
  public ReadRateLimiter getReadRateLimiter() {
    return readRateLimiter;
  }
  public void setReadRateLimiter(ReadRateLimiter readRateLimiter) {
    this.readRateLimiter = readRateLimiter;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("dosRateLimiter")
  public DosRateLimiter getDosRateLimiter() {
    return dosRateLimiter;
  }
  public void setDosRateLimiter(DosRateLimiter dosRateLimiter) {
    this.dosRateLimiter = dosRateLimiter;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Qos qos = (Qos) o;
    return Objects.equals(deliveryRateLimiter, qos.deliveryRateLimiter) &&
        Objects.equals(readRateLimiter, qos.readRateLimiter) &&
        Objects.equals(dosRateLimiter, qos.dosRateLimiter);
  }

  @Override
  public int hashCode() {
    return Objects.hash(deliveryRateLimiter, readRateLimiter, dosRateLimiter);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Qos {\n");
    
    sb.append("    deliveryRateLimiter: ").append(toIndentedString(deliveryRateLimiter)).append("\n");
    sb.append("    readRateLimiter: ").append(toIndentedString(readRateLimiter)).append("\n");
    sb.append("    dosRateLimiter: ").append(toIndentedString(dosRateLimiter)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
