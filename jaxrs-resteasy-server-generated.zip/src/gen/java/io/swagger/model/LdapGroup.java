package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class LdapGroup   {
  private String cn = null;  private String dn = null;  private String description = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("cn")
  public String getCn() {
    return cn;
  }
  public void setCn(String cn) {
    this.cn = cn;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("dn")
  public String getDn() {
    return dn;
  }
  public void setDn(String dn) {
    this.dn = dn;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("description")
  public String getDescription() {
    return description;
  }
  public void setDescription(String description) {
    this.description = description;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    LdapGroup ldapGroup = (LdapGroup) o;
    return Objects.equals(cn, ldapGroup.cn) &&
        Objects.equals(dn, ldapGroup.dn) &&
        Objects.equals(description, ldapGroup.description);
  }

  @Override
  public int hashCode() {
    return Objects.hash(cn, dn, description);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class LdapGroup {\n");
    
    sb.append("    cn: ").append(toIndentedString(cn)).append("\n");
    sb.append("    dn: ").append(toIndentedString(dn)).append("\n");
    sb.append("    description: ").append(toIndentedString(description)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
