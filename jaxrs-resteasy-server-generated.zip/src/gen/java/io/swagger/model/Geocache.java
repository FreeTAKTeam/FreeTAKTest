package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class Geocache   {
  private Boolean enable = null;  private String connectId = null;  private Integer maxTilesPerGoal = null;  private Integer maxSizeOfCacheInMb = null;  private String cacheDir = null;  private Integer numThreads = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("enable")
  public Boolean isEnable() {
    return enable;
  }
  public void setEnable(Boolean enable) {
    this.enable = enable;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("connectId")
  public String getConnectId() {
    return connectId;
  }
  public void setConnectId(String connectId) {
    this.connectId = connectId;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("maxTilesPerGoal")
  public Integer getMaxTilesPerGoal() {
    return maxTilesPerGoal;
  }
  public void setMaxTilesPerGoal(Integer maxTilesPerGoal) {
    this.maxTilesPerGoal = maxTilesPerGoal;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("maxSizeOfCacheInMb")
  public Integer getMaxSizeOfCacheInMb() {
    return maxSizeOfCacheInMb;
  }
  public void setMaxSizeOfCacheInMb(Integer maxSizeOfCacheInMb) {
    this.maxSizeOfCacheInMb = maxSizeOfCacheInMb;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("cacheDir")
  public String getCacheDir() {
    return cacheDir;
  }
  public void setCacheDir(String cacheDir) {
    this.cacheDir = cacheDir;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("numThreads")
  public Integer getNumThreads() {
    return numThreads;
  }
  public void setNumThreads(Integer numThreads) {
    this.numThreads = numThreads;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Geocache geocache = (Geocache) o;
    return Objects.equals(enable, geocache.enable) &&
        Objects.equals(connectId, geocache.connectId) &&
        Objects.equals(maxTilesPerGoal, geocache.maxTilesPerGoal) &&
        Objects.equals(maxSizeOfCacheInMb, geocache.maxSizeOfCacheInMb) &&
        Objects.equals(cacheDir, geocache.cacheDir) &&
        Objects.equals(numThreads, geocache.numThreads);
  }

  @Override
  public int hashCode() {
    return Objects.hash(enable, connectId, maxTilesPerGoal, maxSizeOfCacheInMb, cacheDir, numThreads);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Geocache {\n");
    
    sb.append("    enable: ").append(toIndentedString(enable)).append("\n");
    sb.append("    connectId: ").append(toIndentedString(connectId)).append("\n");
    sb.append("    maxTilesPerGoal: ").append(toIndentedString(maxTilesPerGoal)).append("\n");
    sb.append("    maxSizeOfCacheInMb: ").append(toIndentedString(maxSizeOfCacheInMb)).append("\n");
    sb.append("    cacheDir: ").append(toIndentedString(cacheDir)).append("\n");
    sb.append("    numThreads: ").append(toIndentedString(numThreads)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
