package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import java.util.Date;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class Repeatable   {
  private String uid = null;  private String repeatType = null;  private String cotType = null;  private Date dateTimeActivated = null;  private String xml = null;  private String callsign = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("uid")
  public String getUid() {
    return uid;
  }
  public void setUid(String uid) {
    this.uid = uid;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("repeatType")
  public String getRepeatType() {
    return repeatType;
  }
  public void setRepeatType(String repeatType) {
    this.repeatType = repeatType;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("cotType")
  public String getCotType() {
    return cotType;
  }
  public void setCotType(String cotType) {
    this.cotType = cotType;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("dateTimeActivated")
  public Date getDateTimeActivated() {
    return dateTimeActivated;
  }
  public void setDateTimeActivated(Date dateTimeActivated) {
    this.dateTimeActivated = dateTimeActivated;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("xml")
  public String getXml() {
    return xml;
  }
  public void setXml(String xml) {
    this.xml = xml;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("callsign")
  public String getCallsign() {
    return callsign;
  }
  public void setCallsign(String callsign) {
    this.callsign = callsign;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Repeatable repeatable = (Repeatable) o;
    return Objects.equals(uid, repeatable.uid) &&
        Objects.equals(repeatType, repeatable.repeatType) &&
        Objects.equals(cotType, repeatable.cotType) &&
        Objects.equals(dateTimeActivated, repeatable.dateTimeActivated) &&
        Objects.equals(xml, repeatable.xml) &&
        Objects.equals(callsign, repeatable.callsign);
  }

  @Override
  public int hashCode() {
    return Objects.hash(uid, repeatType, cotType, dateTimeActivated, xml, callsign);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Repeatable {\n");
    
    sb.append("    uid: ").append(toIndentedString(uid)).append("\n");
    sb.append("    repeatType: ").append(toIndentedString(repeatType)).append("\n");
    sb.append("    cotType: ").append(toIndentedString(cotType)).append("\n");
    sb.append("    dateTimeActivated: ").append(toIndentedString(dateTimeActivated)).append("\n");
    sb.append("    xml: ").append(toIndentedString(xml)).append("\n");
    sb.append("    callsign: ").append(toIndentedString(callsign)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
