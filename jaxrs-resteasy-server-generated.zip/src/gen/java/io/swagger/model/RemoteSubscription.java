package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import java.util.List;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class RemoteSubscription   {
  private List<String> filterGroups = new ArrayList<String>();  private String notes = null;  private String callsign = null;  private String team = null;  private String role = null;  private String takv = null;  private String uid = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("filterGroups")
  public List<String> getFilterGroups() {
    return filterGroups;
  }
  public void setFilterGroups(List<String> filterGroups) {
    this.filterGroups = filterGroups;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("notes")
  public String getNotes() {
    return notes;
  }
  public void setNotes(String notes) {
    this.notes = notes;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("callsign")
  public String getCallsign() {
    return callsign;
  }
  public void setCallsign(String callsign) {
    this.callsign = callsign;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("team")
  public String getTeam() {
    return team;
  }
  public void setTeam(String team) {
    this.team = team;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("role")
  public String getRole() {
    return role;
  }
  public void setRole(String role) {
    this.role = role;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("takv")
  public String getTakv() {
    return takv;
  }
  public void setTakv(String takv) {
    this.takv = takv;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("uid")
  public String getUid() {
    return uid;
  }
  public void setUid(String uid) {
    this.uid = uid;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    RemoteSubscription remoteSubscription = (RemoteSubscription) o;
    return Objects.equals(filterGroups, remoteSubscription.filterGroups) &&
        Objects.equals(notes, remoteSubscription.notes) &&
        Objects.equals(callsign, remoteSubscription.callsign) &&
        Objects.equals(team, remoteSubscription.team) &&
        Objects.equals(role, remoteSubscription.role) &&
        Objects.equals(takv, remoteSubscription.takv) &&
        Objects.equals(uid, remoteSubscription.uid);
  }

  @Override
  public int hashCode() {
    return Objects.hash(filterGroups, notes, callsign, team, role, takv, uid);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class RemoteSubscription {\n");
    
    sb.append("    filterGroups: ").append(toIndentedString(filterGroups)).append("\n");
    sb.append("    notes: ").append(toIndentedString(notes)).append("\n");
    sb.append("    callsign: ").append(toIndentedString(callsign)).append("\n");
    sb.append("    team: ").append(toIndentedString(team)).append("\n");
    sb.append("    role: ").append(toIndentedString(role)).append("\n");
    sb.append("    takv: ").append(toIndentedString(takv)).append("\n");
    sb.append("    uid: ").append(toIndentedString(uid)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
