package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class Plugins   {
  private Boolean usePluginMessageQueue = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("usePluginMessageQueue")
  public Boolean isUsePluginMessageQueue() {
    return usePluginMessageQueue;
  }
  public void setUsePluginMessageQueue(Boolean usePluginMessageQueue) {
    this.usePluginMessageQueue = usePluginMessageQueue;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Plugins plugins = (Plugins) o;
    return Objects.equals(usePluginMessageQueue, plugins.usePluginMessageQueue);
  }

  @Override
  public int hashCode() {
    return Objects.hash(usePluginMessageQueue);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Plugins {\n");
    
    sb.append("    usePluginMessageQueue: ").append(toIndentedString(usePluginMessageQueue)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
