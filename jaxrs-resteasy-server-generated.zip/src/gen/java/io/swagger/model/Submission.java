package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class Submission   {
  private Boolean ignoreStaleMessages = null;  private Boolean validateXml = null;  private Boolean dropMesssagesIfAnyServiceIsFull = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("ignoreStaleMessages")
  public Boolean isIgnoreStaleMessages() {
    return ignoreStaleMessages;
  }
  public void setIgnoreStaleMessages(Boolean ignoreStaleMessages) {
    this.ignoreStaleMessages = ignoreStaleMessages;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("validateXml")
  public Boolean isValidateXml() {
    return validateXml;
  }
  public void setValidateXml(Boolean validateXml) {
    this.validateXml = validateXml;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("dropMesssagesIfAnyServiceIsFull")
  public Boolean isDropMesssagesIfAnyServiceIsFull() {
    return dropMesssagesIfAnyServiceIsFull;
  }
  public void setDropMesssagesIfAnyServiceIsFull(Boolean dropMesssagesIfAnyServiceIsFull) {
    this.dropMesssagesIfAnyServiceIsFull = dropMesssagesIfAnyServiceIsFull;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Submission submission = (Submission) o;
    return Objects.equals(ignoreStaleMessages, submission.ignoreStaleMessages) &&
        Objects.equals(validateXml, submission.validateXml) &&
        Objects.equals(dropMesssagesIfAnyServiceIsFull, submission.dropMesssagesIfAnyServiceIsFull);
  }

  @Override
  public int hashCode() {
    return Objects.hash(ignoreStaleMessages, validateXml, dropMesssagesIfAnyServiceIsFull);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Submission {\n");
    
    sb.append("    ignoreStaleMessages: ").append(toIndentedString(ignoreStaleMessages)).append("\n");
    sb.append("    validateXml: ").append(toIndentedString(validateXml)).append("\n");
    sb.append("    dropMesssagesIfAnyServiceIsFull: ").append(toIndentedString(dropMesssagesIfAnyServiceIsFull)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
