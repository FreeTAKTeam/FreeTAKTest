package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class MissionArchiveConfig   {
  private String cronExpression = null;  private Boolean archiveMissionByNoContentActivity = null;  private Boolean archiveMissionByNoSubscriptionActivity = null;  private Double timeToArchiveAfterNoActivityDays = null;  private Double removeFromArchiveAfterDays = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("cronExpression")
  public String getCronExpression() {
    return cronExpression;
  }
  public void setCronExpression(String cronExpression) {
    this.cronExpression = cronExpression;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("archiveMissionByNoContentActivity")
  public Boolean isArchiveMissionByNoContentActivity() {
    return archiveMissionByNoContentActivity;
  }
  public void setArchiveMissionByNoContentActivity(Boolean archiveMissionByNoContentActivity) {
    this.archiveMissionByNoContentActivity = archiveMissionByNoContentActivity;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("archiveMissionByNoSubscriptionActivity")
  public Boolean isArchiveMissionByNoSubscriptionActivity() {
    return archiveMissionByNoSubscriptionActivity;
  }
  public void setArchiveMissionByNoSubscriptionActivity(Boolean archiveMissionByNoSubscriptionActivity) {
    this.archiveMissionByNoSubscriptionActivity = archiveMissionByNoSubscriptionActivity;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("timeToArchiveAfterNoActivityDays")
  public Double getTimeToArchiveAfterNoActivityDays() {
    return timeToArchiveAfterNoActivityDays;
  }
  public void setTimeToArchiveAfterNoActivityDays(Double timeToArchiveAfterNoActivityDays) {
    this.timeToArchiveAfterNoActivityDays = timeToArchiveAfterNoActivityDays;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("removeFromArchiveAfterDays")
  public Double getRemoveFromArchiveAfterDays() {
    return removeFromArchiveAfterDays;
  }
  public void setRemoveFromArchiveAfterDays(Double removeFromArchiveAfterDays) {
    this.removeFromArchiveAfterDays = removeFromArchiveAfterDays;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    MissionArchiveConfig missionArchiveConfig = (MissionArchiveConfig) o;
    return Objects.equals(cronExpression, missionArchiveConfig.cronExpression) &&
        Objects.equals(archiveMissionByNoContentActivity, missionArchiveConfig.archiveMissionByNoContentActivity) &&
        Objects.equals(archiveMissionByNoSubscriptionActivity, missionArchiveConfig.archiveMissionByNoSubscriptionActivity) &&
        Objects.equals(timeToArchiveAfterNoActivityDays, missionArchiveConfig.timeToArchiveAfterNoActivityDays) &&
        Objects.equals(removeFromArchiveAfterDays, missionArchiveConfig.removeFromArchiveAfterDays);
  }

  @Override
  public int hashCode() {
    return Objects.hash(cronExpression, archiveMissionByNoContentActivity, archiveMissionByNoSubscriptionActivity, timeToArchiveAfterNoActivityDays, removeFromArchiveAfterDays);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class MissionArchiveConfig {\n");
    
    sb.append("    cronExpression: ").append(toIndentedString(cronExpression)).append("\n");
    sb.append("    archiveMissionByNoContentActivity: ").append(toIndentedString(archiveMissionByNoContentActivity)).append("\n");
    sb.append("    archiveMissionByNoSubscriptionActivity: ").append(toIndentedString(archiveMissionByNoSubscriptionActivity)).append("\n");
    sb.append("    timeToArchiveAfterNoActivityDays: ").append(toIndentedString(timeToArchiveAfterNoActivityDays)).append("\n");
    sb.append("    removeFromArchiveAfterDays: ").append(toIndentedString(removeFromArchiveAfterDays)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
