package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class ConnectionInfoReadCount   {
  private Integer opaque = null;  private Integer acquire = null;  private Integer release = null;  private Integer andIncrement = null;  private Integer andDecrement = null;  private Integer plain = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("opaque")
  public Integer getOpaque() {
    return opaque;
  }
  public void setOpaque(Integer opaque) {
    this.opaque = opaque;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("acquire")
  public Integer getAcquire() {
    return acquire;
  }
  public void setAcquire(Integer acquire) {
    this.acquire = acquire;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("release")
  public Integer getRelease() {
    return release;
  }
  public void setRelease(Integer release) {
    this.release = release;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("andIncrement")
  public Integer getAndIncrement() {
    return andIncrement;
  }
  public void setAndIncrement(Integer andIncrement) {
    this.andIncrement = andIncrement;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("andDecrement")
  public Integer getAndDecrement() {
    return andDecrement;
  }
  public void setAndDecrement(Integer andDecrement) {
    this.andDecrement = andDecrement;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("plain")
  public Integer getPlain() {
    return plain;
  }
  public void setPlain(Integer plain) {
    this.plain = plain;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ConnectionInfoReadCount connectionInfoReadCount = (ConnectionInfoReadCount) o;
    return Objects.equals(opaque, connectionInfoReadCount.opaque) &&
        Objects.equals(acquire, connectionInfoReadCount.acquire) &&
        Objects.equals(release, connectionInfoReadCount.release) &&
        Objects.equals(andIncrement, connectionInfoReadCount.andIncrement) &&
        Objects.equals(andDecrement, connectionInfoReadCount.andDecrement) &&
        Objects.equals(plain, connectionInfoReadCount.plain);
  }

  @Override
  public int hashCode() {
    return Objects.hash(opaque, acquire, release, andIncrement, andDecrement, plain);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ConnectionInfoReadCount {\n");
    
    sb.append("    opaque: ").append(toIndentedString(opaque)).append("\n");
    sb.append("    acquire: ").append(toIndentedString(acquire)).append("\n");
    sb.append("    release: ").append(toIndentedString(release)).append("\n");
    sb.append("    andIncrement: ").append(toIndentedString(andIncrement)).append("\n");
    sb.append("    andDecrement: ").append(toIndentedString(andDecrement)).append("\n");
    sb.append("    plain: ").append(toIndentedString(plain)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
