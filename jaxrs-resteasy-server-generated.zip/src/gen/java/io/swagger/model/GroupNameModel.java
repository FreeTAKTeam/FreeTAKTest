package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class GroupNameModel   {
  private String groupname = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("groupname")
  public String getGroupname() {
    return groupname;
  }
  public void setGroupname(String groupname) {
    this.groupname = groupname;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    GroupNameModel groupNameModel = (GroupNameModel) o;
    return Objects.equals(groupname, groupNameModel.groupname);
  }

  @Override
  public int hashCode() {
    return Objects.hash(groupname);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class GroupNameModel {\n");
    
    sb.append("    groupname: ").append(toIndentedString(groupname)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
