package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.FeedV2;
import java.util.List;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class VideoConnection   {
  private Boolean active = null;  private String alias = null;  private String thumbnail = null;  private String classification = null;  private List<FeedV2> feeds = new ArrayList<FeedV2>();  private String uuid = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("active")
  public Boolean isActive() {
    return active;
  }
  public void setActive(Boolean active) {
    this.active = active;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("alias")
  public String getAlias() {
    return alias;
  }
  public void setAlias(String alias) {
    this.alias = alias;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("thumbnail")
  public String getThumbnail() {
    return thumbnail;
  }
  public void setThumbnail(String thumbnail) {
    this.thumbnail = thumbnail;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("classification")
  public String getClassification() {
    return classification;
  }
  public void setClassification(String classification) {
    this.classification = classification;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("feeds")
  public List<FeedV2> getFeeds() {
    return feeds;
  }
  public void setFeeds(List<FeedV2> feeds) {
    this.feeds = feeds;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("uuid")
  public String getUuid() {
    return uuid;
  }
  public void setUuid(String uuid) {
    this.uuid = uuid;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    VideoConnection videoConnection = (VideoConnection) o;
    return Objects.equals(active, videoConnection.active) &&
        Objects.equals(alias, videoConnection.alias) &&
        Objects.equals(thumbnail, videoConnection.thumbnail) &&
        Objects.equals(classification, videoConnection.classification) &&
        Objects.equals(feeds, videoConnection.feeds) &&
        Objects.equals(uuid, videoConnection.uuid);
  }

  @Override
  public int hashCode() {
    return Objects.hash(active, alias, thumbnail, classification, feeds, uuid);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class VideoConnection {\n");
    
    sb.append("    active: ").append(toIndentedString(active)).append("\n");
    sb.append("    alias: ").append(toIndentedString(alias)).append("\n");
    sb.append("    thumbnail: ").append(toIndentedString(thumbnail)).append("\n");
    sb.append("    classification: ").append(toIndentedString(classification)).append("\n");
    sb.append("    feeds: ").append(toIndentedString(feeds)).append("\n");
    sb.append("    uuid: ").append(toIndentedString(uuid)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
