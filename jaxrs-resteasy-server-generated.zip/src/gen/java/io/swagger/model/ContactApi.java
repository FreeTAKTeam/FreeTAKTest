package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class ContactApi   {
  private String groupName = null;  private Boolean writeOnly = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("groupName")
  public String getGroupName() {
    return groupName;
  }
  public void setGroupName(String groupName) {
    this.groupName = groupName;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("writeOnly")
  public Boolean isWriteOnly() {
    return writeOnly;
  }
  public void setWriteOnly(Boolean writeOnly) {
    this.writeOnly = writeOnly;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ContactApi contactApi = (ContactApi) o;
    return Objects.equals(groupName, contactApi.groupName) &&
        Objects.equals(writeOnly, contactApi.writeOnly);
  }

  @Override
  public int hashCode() {
    return Objects.hash(groupName, writeOnly);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ContactApi {\n");
    
    sb.append("    groupName: ").append(toIndentedString(groupName)).append("\n");
    sb.append("    writeOnly: ").append(toIndentedString(writeOnly)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
