package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.Priority;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class Queue   {
  private Priority priority = null;  private Boolean monitor = null;  private Integer capacity = null;  private Integer pubSubCapacity = null;  private Integer outboundCapacity = null;  private Integer inboundCapacity = null;  private Integer codecWrapperCapacity = null;  private Integer tcpWriteQueueCapacity = null;  private Boolean disconnectOnFull = null;  private Integer maxWriteQueueSize = null;  private Integer defaultExecQueueSize = null;  private Integer defaultMaxPoolSize = null;  private Integer defaultMaxPoolFactor = null;  private Integer messageWriteQueueSize = null;  private Integer messageWriteExecutorQueueSize = null;  private Integer codecViewPendingCapacity = null;  private Integer queueSizeInitial = null;  private Integer queueSizeIncrement = null;  private Integer coreExecutorCapacity = null;  private Boolean throwOnAssertionFail = null;  private Boolean disconnectOnPendingExceeded = null;  private Integer flushInterval = null;  private Integer websocketSendBufferSizeLimit = null;  private Integer websocketMaxBinaryMessageBufferSize = null;  private Long websocketMaxSessionIdleTimeout = null;  private Integer websocketSendTimeoutMs = null;  private Integer missionUidLimit = null;  private Integer missionContentLimit = null;  private Integer nearCacheMaxSize = null;  private Integer cotCacheMaxSize = null;  private Integer cotCacheBatchSize = null;  private Integer cotCacheMaxMemorySize = null;  private Integer springCacheMaxSize = null;  private Integer springCacheBatchSize = null;  private Integer springCacheMaxMemorySize = null;  private Integer springCacheSizeScalingFactor = null;  private Boolean onHeapEnabled = null;  private Long cacheOffHeapMaxSizeBytes = null;  private Long cacheOffHeapInitialSizeBytes = null;  private Float cacheOffHeapDefaultPercentage = null;  private Float cacheOffHeapEvictionThreshold = null;  private Integer cacheLastTouchedExpiryMinutes = null;  private Boolean enableCacheGroup = null;  private Boolean enableCacheWarmer = null;  private Integer ignitePoolSize = null;  private Boolean cacheCotInRepository = null;  private Boolean enableCachePersistence = null;  private Long messageTimestampCacheSizeItems = null;  private Boolean enableStoreForwardChat = null;  private Long storeForwardQueryBufferMs = null;  private Long storeForwardSendBufferMs = null;  private Boolean enableClientEndpointCache = null;  private Long contactCacheUpdateRateLimitSeconds = null;  private Long contactCacheRecencyLimitSeconds = null;  private Integer pluginDatafeedCacheSeconds = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("priority")
  public Priority getPriority() {
    return priority;
  }
  public void setPriority(Priority priority) {
    this.priority = priority;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("monitor")
  public Boolean isMonitor() {
    return monitor;
  }
  public void setMonitor(Boolean monitor) {
    this.monitor = monitor;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("capacity")
  public Integer getCapacity() {
    return capacity;
  }
  public void setCapacity(Integer capacity) {
    this.capacity = capacity;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("pubSubCapacity")
  public Integer getPubSubCapacity() {
    return pubSubCapacity;
  }
  public void setPubSubCapacity(Integer pubSubCapacity) {
    this.pubSubCapacity = pubSubCapacity;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("outboundCapacity")
  public Integer getOutboundCapacity() {
    return outboundCapacity;
  }
  public void setOutboundCapacity(Integer outboundCapacity) {
    this.outboundCapacity = outboundCapacity;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("inboundCapacity")
  public Integer getInboundCapacity() {
    return inboundCapacity;
  }
  public void setInboundCapacity(Integer inboundCapacity) {
    this.inboundCapacity = inboundCapacity;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("codecWrapperCapacity")
  public Integer getCodecWrapperCapacity() {
    return codecWrapperCapacity;
  }
  public void setCodecWrapperCapacity(Integer codecWrapperCapacity) {
    this.codecWrapperCapacity = codecWrapperCapacity;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("tcpWriteQueueCapacity")
  public Integer getTcpWriteQueueCapacity() {
    return tcpWriteQueueCapacity;
  }
  public void setTcpWriteQueueCapacity(Integer tcpWriteQueueCapacity) {
    this.tcpWriteQueueCapacity = tcpWriteQueueCapacity;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("disconnectOnFull")
  public Boolean isDisconnectOnFull() {
    return disconnectOnFull;
  }
  public void setDisconnectOnFull(Boolean disconnectOnFull) {
    this.disconnectOnFull = disconnectOnFull;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("maxWriteQueueSize")
  public Integer getMaxWriteQueueSize() {
    return maxWriteQueueSize;
  }
  public void setMaxWriteQueueSize(Integer maxWriteQueueSize) {
    this.maxWriteQueueSize = maxWriteQueueSize;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("defaultExecQueueSize")
  public Integer getDefaultExecQueueSize() {
    return defaultExecQueueSize;
  }
  public void setDefaultExecQueueSize(Integer defaultExecQueueSize) {
    this.defaultExecQueueSize = defaultExecQueueSize;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("defaultMaxPoolSize")
  public Integer getDefaultMaxPoolSize() {
    return defaultMaxPoolSize;
  }
  public void setDefaultMaxPoolSize(Integer defaultMaxPoolSize) {
    this.defaultMaxPoolSize = defaultMaxPoolSize;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("defaultMaxPoolFactor")
  public Integer getDefaultMaxPoolFactor() {
    return defaultMaxPoolFactor;
  }
  public void setDefaultMaxPoolFactor(Integer defaultMaxPoolFactor) {
    this.defaultMaxPoolFactor = defaultMaxPoolFactor;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("messageWriteQueueSize")
  public Integer getMessageWriteQueueSize() {
    return messageWriteQueueSize;
  }
  public void setMessageWriteQueueSize(Integer messageWriteQueueSize) {
    this.messageWriteQueueSize = messageWriteQueueSize;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("messageWriteExecutorQueueSize")
  public Integer getMessageWriteExecutorQueueSize() {
    return messageWriteExecutorQueueSize;
  }
  public void setMessageWriteExecutorQueueSize(Integer messageWriteExecutorQueueSize) {
    this.messageWriteExecutorQueueSize = messageWriteExecutorQueueSize;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("codecViewPendingCapacity")
  public Integer getCodecViewPendingCapacity() {
    return codecViewPendingCapacity;
  }
  public void setCodecViewPendingCapacity(Integer codecViewPendingCapacity) {
    this.codecViewPendingCapacity = codecViewPendingCapacity;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("queueSizeInitial")
  public Integer getQueueSizeInitial() {
    return queueSizeInitial;
  }
  public void setQueueSizeInitial(Integer queueSizeInitial) {
    this.queueSizeInitial = queueSizeInitial;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("queueSizeIncrement")
  public Integer getQueueSizeIncrement() {
    return queueSizeIncrement;
  }
  public void setQueueSizeIncrement(Integer queueSizeIncrement) {
    this.queueSizeIncrement = queueSizeIncrement;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("coreExecutorCapacity")
  public Integer getCoreExecutorCapacity() {
    return coreExecutorCapacity;
  }
  public void setCoreExecutorCapacity(Integer coreExecutorCapacity) {
    this.coreExecutorCapacity = coreExecutorCapacity;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("throwOnAssertionFail")
  public Boolean isThrowOnAssertionFail() {
    return throwOnAssertionFail;
  }
  public void setThrowOnAssertionFail(Boolean throwOnAssertionFail) {
    this.throwOnAssertionFail = throwOnAssertionFail;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("disconnectOnPendingExceeded")
  public Boolean isDisconnectOnPendingExceeded() {
    return disconnectOnPendingExceeded;
  }
  public void setDisconnectOnPendingExceeded(Boolean disconnectOnPendingExceeded) {
    this.disconnectOnPendingExceeded = disconnectOnPendingExceeded;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("flushInterval")
  public Integer getFlushInterval() {
    return flushInterval;
  }
  public void setFlushInterval(Integer flushInterval) {
    this.flushInterval = flushInterval;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("websocketSendBufferSizeLimit")
  public Integer getWebsocketSendBufferSizeLimit() {
    return websocketSendBufferSizeLimit;
  }
  public void setWebsocketSendBufferSizeLimit(Integer websocketSendBufferSizeLimit) {
    this.websocketSendBufferSizeLimit = websocketSendBufferSizeLimit;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("websocketMaxBinaryMessageBufferSize")
  public Integer getWebsocketMaxBinaryMessageBufferSize() {
    return websocketMaxBinaryMessageBufferSize;
  }
  public void setWebsocketMaxBinaryMessageBufferSize(Integer websocketMaxBinaryMessageBufferSize) {
    this.websocketMaxBinaryMessageBufferSize = websocketMaxBinaryMessageBufferSize;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("websocketMaxSessionIdleTimeout")
  public Long getWebsocketMaxSessionIdleTimeout() {
    return websocketMaxSessionIdleTimeout;
  }
  public void setWebsocketMaxSessionIdleTimeout(Long websocketMaxSessionIdleTimeout) {
    this.websocketMaxSessionIdleTimeout = websocketMaxSessionIdleTimeout;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("websocketSendTimeoutMs")
  public Integer getWebsocketSendTimeoutMs() {
    return websocketSendTimeoutMs;
  }
  public void setWebsocketSendTimeoutMs(Integer websocketSendTimeoutMs) {
    this.websocketSendTimeoutMs = websocketSendTimeoutMs;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("missionUidLimit")
  public Integer getMissionUidLimit() {
    return missionUidLimit;
  }
  public void setMissionUidLimit(Integer missionUidLimit) {
    this.missionUidLimit = missionUidLimit;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("missionContentLimit")
  public Integer getMissionContentLimit() {
    return missionContentLimit;
  }
  public void setMissionContentLimit(Integer missionContentLimit) {
    this.missionContentLimit = missionContentLimit;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("nearCacheMaxSize")
  public Integer getNearCacheMaxSize() {
    return nearCacheMaxSize;
  }
  public void setNearCacheMaxSize(Integer nearCacheMaxSize) {
    this.nearCacheMaxSize = nearCacheMaxSize;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("cotCacheMaxSize")
  public Integer getCotCacheMaxSize() {
    return cotCacheMaxSize;
  }
  public void setCotCacheMaxSize(Integer cotCacheMaxSize) {
    this.cotCacheMaxSize = cotCacheMaxSize;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("cotCacheBatchSize")
  public Integer getCotCacheBatchSize() {
    return cotCacheBatchSize;
  }
  public void setCotCacheBatchSize(Integer cotCacheBatchSize) {
    this.cotCacheBatchSize = cotCacheBatchSize;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("cotCacheMaxMemorySize")
  public Integer getCotCacheMaxMemorySize() {
    return cotCacheMaxMemorySize;
  }
  public void setCotCacheMaxMemorySize(Integer cotCacheMaxMemorySize) {
    this.cotCacheMaxMemorySize = cotCacheMaxMemorySize;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("springCacheMaxSize")
  public Integer getSpringCacheMaxSize() {
    return springCacheMaxSize;
  }
  public void setSpringCacheMaxSize(Integer springCacheMaxSize) {
    this.springCacheMaxSize = springCacheMaxSize;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("springCacheBatchSize")
  public Integer getSpringCacheBatchSize() {
    return springCacheBatchSize;
  }
  public void setSpringCacheBatchSize(Integer springCacheBatchSize) {
    this.springCacheBatchSize = springCacheBatchSize;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("springCacheMaxMemorySize")
  public Integer getSpringCacheMaxMemorySize() {
    return springCacheMaxMemorySize;
  }
  public void setSpringCacheMaxMemorySize(Integer springCacheMaxMemorySize) {
    this.springCacheMaxMemorySize = springCacheMaxMemorySize;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("springCacheSizeScalingFactor")
  public Integer getSpringCacheSizeScalingFactor() {
    return springCacheSizeScalingFactor;
  }
  public void setSpringCacheSizeScalingFactor(Integer springCacheSizeScalingFactor) {
    this.springCacheSizeScalingFactor = springCacheSizeScalingFactor;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("onHeapEnabled")
  public Boolean isOnHeapEnabled() {
    return onHeapEnabled;
  }
  public void setOnHeapEnabled(Boolean onHeapEnabled) {
    this.onHeapEnabled = onHeapEnabled;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("cacheOffHeapMaxSizeBytes")
  public Long getCacheOffHeapMaxSizeBytes() {
    return cacheOffHeapMaxSizeBytes;
  }
  public void setCacheOffHeapMaxSizeBytes(Long cacheOffHeapMaxSizeBytes) {
    this.cacheOffHeapMaxSizeBytes = cacheOffHeapMaxSizeBytes;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("cacheOffHeapInitialSizeBytes")
  public Long getCacheOffHeapInitialSizeBytes() {
    return cacheOffHeapInitialSizeBytes;
  }
  public void setCacheOffHeapInitialSizeBytes(Long cacheOffHeapInitialSizeBytes) {
    this.cacheOffHeapInitialSizeBytes = cacheOffHeapInitialSizeBytes;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("cacheOffHeapDefaultPercentage")
  public Float getCacheOffHeapDefaultPercentage() {
    return cacheOffHeapDefaultPercentage;
  }
  public void setCacheOffHeapDefaultPercentage(Float cacheOffHeapDefaultPercentage) {
    this.cacheOffHeapDefaultPercentage = cacheOffHeapDefaultPercentage;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("cacheOffHeapEvictionThreshold")
  public Float getCacheOffHeapEvictionThreshold() {
    return cacheOffHeapEvictionThreshold;
  }
  public void setCacheOffHeapEvictionThreshold(Float cacheOffHeapEvictionThreshold) {
    this.cacheOffHeapEvictionThreshold = cacheOffHeapEvictionThreshold;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("cacheLastTouchedExpiryMinutes")
  public Integer getCacheLastTouchedExpiryMinutes() {
    return cacheLastTouchedExpiryMinutes;
  }
  public void setCacheLastTouchedExpiryMinutes(Integer cacheLastTouchedExpiryMinutes) {
    this.cacheLastTouchedExpiryMinutes = cacheLastTouchedExpiryMinutes;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("enableCacheGroup")
  public Boolean isEnableCacheGroup() {
    return enableCacheGroup;
  }
  public void setEnableCacheGroup(Boolean enableCacheGroup) {
    this.enableCacheGroup = enableCacheGroup;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("enableCacheWarmer")
  public Boolean isEnableCacheWarmer() {
    return enableCacheWarmer;
  }
  public void setEnableCacheWarmer(Boolean enableCacheWarmer) {
    this.enableCacheWarmer = enableCacheWarmer;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("ignitePoolSize")
  public Integer getIgnitePoolSize() {
    return ignitePoolSize;
  }
  public void setIgnitePoolSize(Integer ignitePoolSize) {
    this.ignitePoolSize = ignitePoolSize;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("cacheCotInRepository")
  public Boolean isCacheCotInRepository() {
    return cacheCotInRepository;
  }
  public void setCacheCotInRepository(Boolean cacheCotInRepository) {
    this.cacheCotInRepository = cacheCotInRepository;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("enableCachePersistence")
  public Boolean isEnableCachePersistence() {
    return enableCachePersistence;
  }
  public void setEnableCachePersistence(Boolean enableCachePersistence) {
    this.enableCachePersistence = enableCachePersistence;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("messageTimestampCacheSizeItems")
  public Long getMessageTimestampCacheSizeItems() {
    return messageTimestampCacheSizeItems;
  }
  public void setMessageTimestampCacheSizeItems(Long messageTimestampCacheSizeItems) {
    this.messageTimestampCacheSizeItems = messageTimestampCacheSizeItems;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("enableStoreForwardChat")
  public Boolean isEnableStoreForwardChat() {
    return enableStoreForwardChat;
  }
  public void setEnableStoreForwardChat(Boolean enableStoreForwardChat) {
    this.enableStoreForwardChat = enableStoreForwardChat;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("storeForwardQueryBufferMs")
  public Long getStoreForwardQueryBufferMs() {
    return storeForwardQueryBufferMs;
  }
  public void setStoreForwardQueryBufferMs(Long storeForwardQueryBufferMs) {
    this.storeForwardQueryBufferMs = storeForwardQueryBufferMs;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("storeForwardSendBufferMs")
  public Long getStoreForwardSendBufferMs() {
    return storeForwardSendBufferMs;
  }
  public void setStoreForwardSendBufferMs(Long storeForwardSendBufferMs) {
    this.storeForwardSendBufferMs = storeForwardSendBufferMs;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("enableClientEndpointCache")
  public Boolean isEnableClientEndpointCache() {
    return enableClientEndpointCache;
  }
  public void setEnableClientEndpointCache(Boolean enableClientEndpointCache) {
    this.enableClientEndpointCache = enableClientEndpointCache;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("contactCacheUpdateRateLimitSeconds")
  public Long getContactCacheUpdateRateLimitSeconds() {
    return contactCacheUpdateRateLimitSeconds;
  }
  public void setContactCacheUpdateRateLimitSeconds(Long contactCacheUpdateRateLimitSeconds) {
    this.contactCacheUpdateRateLimitSeconds = contactCacheUpdateRateLimitSeconds;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("contactCacheRecencyLimitSeconds")
  public Long getContactCacheRecencyLimitSeconds() {
    return contactCacheRecencyLimitSeconds;
  }
  public void setContactCacheRecencyLimitSeconds(Long contactCacheRecencyLimitSeconds) {
    this.contactCacheRecencyLimitSeconds = contactCacheRecencyLimitSeconds;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("pluginDatafeedCacheSeconds")
  public Integer getPluginDatafeedCacheSeconds() {
    return pluginDatafeedCacheSeconds;
  }
  public void setPluginDatafeedCacheSeconds(Integer pluginDatafeedCacheSeconds) {
    this.pluginDatafeedCacheSeconds = pluginDatafeedCacheSeconds;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Queue queue = (Queue) o;
    return Objects.equals(priority, queue.priority) &&
        Objects.equals(monitor, queue.monitor) &&
        Objects.equals(capacity, queue.capacity) &&
        Objects.equals(pubSubCapacity, queue.pubSubCapacity) &&
        Objects.equals(outboundCapacity, queue.outboundCapacity) &&
        Objects.equals(inboundCapacity, queue.inboundCapacity) &&
        Objects.equals(codecWrapperCapacity, queue.codecWrapperCapacity) &&
        Objects.equals(tcpWriteQueueCapacity, queue.tcpWriteQueueCapacity) &&
        Objects.equals(disconnectOnFull, queue.disconnectOnFull) &&
        Objects.equals(maxWriteQueueSize, queue.maxWriteQueueSize) &&
        Objects.equals(defaultExecQueueSize, queue.defaultExecQueueSize) &&
        Objects.equals(defaultMaxPoolSize, queue.defaultMaxPoolSize) &&
        Objects.equals(defaultMaxPoolFactor, queue.defaultMaxPoolFactor) &&
        Objects.equals(messageWriteQueueSize, queue.messageWriteQueueSize) &&
        Objects.equals(messageWriteExecutorQueueSize, queue.messageWriteExecutorQueueSize) &&
        Objects.equals(codecViewPendingCapacity, queue.codecViewPendingCapacity) &&
        Objects.equals(queueSizeInitial, queue.queueSizeInitial) &&
        Objects.equals(queueSizeIncrement, queue.queueSizeIncrement) &&
        Objects.equals(coreExecutorCapacity, queue.coreExecutorCapacity) &&
        Objects.equals(throwOnAssertionFail, queue.throwOnAssertionFail) &&
        Objects.equals(disconnectOnPendingExceeded, queue.disconnectOnPendingExceeded) &&
        Objects.equals(flushInterval, queue.flushInterval) &&
        Objects.equals(websocketSendBufferSizeLimit, queue.websocketSendBufferSizeLimit) &&
        Objects.equals(websocketMaxBinaryMessageBufferSize, queue.websocketMaxBinaryMessageBufferSize) &&
        Objects.equals(websocketMaxSessionIdleTimeout, queue.websocketMaxSessionIdleTimeout) &&
        Objects.equals(websocketSendTimeoutMs, queue.websocketSendTimeoutMs) &&
        Objects.equals(missionUidLimit, queue.missionUidLimit) &&
        Objects.equals(missionContentLimit, queue.missionContentLimit) &&
        Objects.equals(nearCacheMaxSize, queue.nearCacheMaxSize) &&
        Objects.equals(cotCacheMaxSize, queue.cotCacheMaxSize) &&
        Objects.equals(cotCacheBatchSize, queue.cotCacheBatchSize) &&
        Objects.equals(cotCacheMaxMemorySize, queue.cotCacheMaxMemorySize) &&
        Objects.equals(springCacheMaxSize, queue.springCacheMaxSize) &&
        Objects.equals(springCacheBatchSize, queue.springCacheBatchSize) &&
        Objects.equals(springCacheMaxMemorySize, queue.springCacheMaxMemorySize) &&
        Objects.equals(springCacheSizeScalingFactor, queue.springCacheSizeScalingFactor) &&
        Objects.equals(onHeapEnabled, queue.onHeapEnabled) &&
        Objects.equals(cacheOffHeapMaxSizeBytes, queue.cacheOffHeapMaxSizeBytes) &&
        Objects.equals(cacheOffHeapInitialSizeBytes, queue.cacheOffHeapInitialSizeBytes) &&
        Objects.equals(cacheOffHeapDefaultPercentage, queue.cacheOffHeapDefaultPercentage) &&
        Objects.equals(cacheOffHeapEvictionThreshold, queue.cacheOffHeapEvictionThreshold) &&
        Objects.equals(cacheLastTouchedExpiryMinutes, queue.cacheLastTouchedExpiryMinutes) &&
        Objects.equals(enableCacheGroup, queue.enableCacheGroup) &&
        Objects.equals(enableCacheWarmer, queue.enableCacheWarmer) &&
        Objects.equals(ignitePoolSize, queue.ignitePoolSize) &&
        Objects.equals(cacheCotInRepository, queue.cacheCotInRepository) &&
        Objects.equals(enableCachePersistence, queue.enableCachePersistence) &&
        Objects.equals(messageTimestampCacheSizeItems, queue.messageTimestampCacheSizeItems) &&
        Objects.equals(enableStoreForwardChat, queue.enableStoreForwardChat) &&
        Objects.equals(storeForwardQueryBufferMs, queue.storeForwardQueryBufferMs) &&
        Objects.equals(storeForwardSendBufferMs, queue.storeForwardSendBufferMs) &&
        Objects.equals(enableClientEndpointCache, queue.enableClientEndpointCache) &&
        Objects.equals(contactCacheUpdateRateLimitSeconds, queue.contactCacheUpdateRateLimitSeconds) &&
        Objects.equals(contactCacheRecencyLimitSeconds, queue.contactCacheRecencyLimitSeconds) &&
        Objects.equals(pluginDatafeedCacheSeconds, queue.pluginDatafeedCacheSeconds);
  }

  @Override
  public int hashCode() {
    return Objects.hash(priority, monitor, capacity, pubSubCapacity, outboundCapacity, inboundCapacity, codecWrapperCapacity, tcpWriteQueueCapacity, disconnectOnFull, maxWriteQueueSize, defaultExecQueueSize, defaultMaxPoolSize, defaultMaxPoolFactor, messageWriteQueueSize, messageWriteExecutorQueueSize, codecViewPendingCapacity, queueSizeInitial, queueSizeIncrement, coreExecutorCapacity, throwOnAssertionFail, disconnectOnPendingExceeded, flushInterval, websocketSendBufferSizeLimit, websocketMaxBinaryMessageBufferSize, websocketMaxSessionIdleTimeout, websocketSendTimeoutMs, missionUidLimit, missionContentLimit, nearCacheMaxSize, cotCacheMaxSize, cotCacheBatchSize, cotCacheMaxMemorySize, springCacheMaxSize, springCacheBatchSize, springCacheMaxMemorySize, springCacheSizeScalingFactor, onHeapEnabled, cacheOffHeapMaxSizeBytes, cacheOffHeapInitialSizeBytes, cacheOffHeapDefaultPercentage, cacheOffHeapEvictionThreshold, cacheLastTouchedExpiryMinutes, enableCacheGroup, enableCacheWarmer, ignitePoolSize, cacheCotInRepository, enableCachePersistence, messageTimestampCacheSizeItems, enableStoreForwardChat, storeForwardQueryBufferMs, storeForwardSendBufferMs, enableClientEndpointCache, contactCacheUpdateRateLimitSeconds, contactCacheRecencyLimitSeconds, pluginDatafeedCacheSeconds);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Queue {\n");
    
    sb.append("    priority: ").append(toIndentedString(priority)).append("\n");
    sb.append("    monitor: ").append(toIndentedString(monitor)).append("\n");
    sb.append("    capacity: ").append(toIndentedString(capacity)).append("\n");
    sb.append("    pubSubCapacity: ").append(toIndentedString(pubSubCapacity)).append("\n");
    sb.append("    outboundCapacity: ").append(toIndentedString(outboundCapacity)).append("\n");
    sb.append("    inboundCapacity: ").append(toIndentedString(inboundCapacity)).append("\n");
    sb.append("    codecWrapperCapacity: ").append(toIndentedString(codecWrapperCapacity)).append("\n");
    sb.append("    tcpWriteQueueCapacity: ").append(toIndentedString(tcpWriteQueueCapacity)).append("\n");
    sb.append("    disconnectOnFull: ").append(toIndentedString(disconnectOnFull)).append("\n");
    sb.append("    maxWriteQueueSize: ").append(toIndentedString(maxWriteQueueSize)).append("\n");
    sb.append("    defaultExecQueueSize: ").append(toIndentedString(defaultExecQueueSize)).append("\n");
    sb.append("    defaultMaxPoolSize: ").append(toIndentedString(defaultMaxPoolSize)).append("\n");
    sb.append("    defaultMaxPoolFactor: ").append(toIndentedString(defaultMaxPoolFactor)).append("\n");
    sb.append("    messageWriteQueueSize: ").append(toIndentedString(messageWriteQueueSize)).append("\n");
    sb.append("    messageWriteExecutorQueueSize: ").append(toIndentedString(messageWriteExecutorQueueSize)).append("\n");
    sb.append("    codecViewPendingCapacity: ").append(toIndentedString(codecViewPendingCapacity)).append("\n");
    sb.append("    queueSizeInitial: ").append(toIndentedString(queueSizeInitial)).append("\n");
    sb.append("    queueSizeIncrement: ").append(toIndentedString(queueSizeIncrement)).append("\n");
    sb.append("    coreExecutorCapacity: ").append(toIndentedString(coreExecutorCapacity)).append("\n");
    sb.append("    throwOnAssertionFail: ").append(toIndentedString(throwOnAssertionFail)).append("\n");
    sb.append("    disconnectOnPendingExceeded: ").append(toIndentedString(disconnectOnPendingExceeded)).append("\n");
    sb.append("    flushInterval: ").append(toIndentedString(flushInterval)).append("\n");
    sb.append("    websocketSendBufferSizeLimit: ").append(toIndentedString(websocketSendBufferSizeLimit)).append("\n");
    sb.append("    websocketMaxBinaryMessageBufferSize: ").append(toIndentedString(websocketMaxBinaryMessageBufferSize)).append("\n");
    sb.append("    websocketMaxSessionIdleTimeout: ").append(toIndentedString(websocketMaxSessionIdleTimeout)).append("\n");
    sb.append("    websocketSendTimeoutMs: ").append(toIndentedString(websocketSendTimeoutMs)).append("\n");
    sb.append("    missionUidLimit: ").append(toIndentedString(missionUidLimit)).append("\n");
    sb.append("    missionContentLimit: ").append(toIndentedString(missionContentLimit)).append("\n");
    sb.append("    nearCacheMaxSize: ").append(toIndentedString(nearCacheMaxSize)).append("\n");
    sb.append("    cotCacheMaxSize: ").append(toIndentedString(cotCacheMaxSize)).append("\n");
    sb.append("    cotCacheBatchSize: ").append(toIndentedString(cotCacheBatchSize)).append("\n");
    sb.append("    cotCacheMaxMemorySize: ").append(toIndentedString(cotCacheMaxMemorySize)).append("\n");
    sb.append("    springCacheMaxSize: ").append(toIndentedString(springCacheMaxSize)).append("\n");
    sb.append("    springCacheBatchSize: ").append(toIndentedString(springCacheBatchSize)).append("\n");
    sb.append("    springCacheMaxMemorySize: ").append(toIndentedString(springCacheMaxMemorySize)).append("\n");
    sb.append("    springCacheSizeScalingFactor: ").append(toIndentedString(springCacheSizeScalingFactor)).append("\n");
    sb.append("    onHeapEnabled: ").append(toIndentedString(onHeapEnabled)).append("\n");
    sb.append("    cacheOffHeapMaxSizeBytes: ").append(toIndentedString(cacheOffHeapMaxSizeBytes)).append("\n");
    sb.append("    cacheOffHeapInitialSizeBytes: ").append(toIndentedString(cacheOffHeapInitialSizeBytes)).append("\n");
    sb.append("    cacheOffHeapDefaultPercentage: ").append(toIndentedString(cacheOffHeapDefaultPercentage)).append("\n");
    sb.append("    cacheOffHeapEvictionThreshold: ").append(toIndentedString(cacheOffHeapEvictionThreshold)).append("\n");
    sb.append("    cacheLastTouchedExpiryMinutes: ").append(toIndentedString(cacheLastTouchedExpiryMinutes)).append("\n");
    sb.append("    enableCacheGroup: ").append(toIndentedString(enableCacheGroup)).append("\n");
    sb.append("    enableCacheWarmer: ").append(toIndentedString(enableCacheWarmer)).append("\n");
    sb.append("    ignitePoolSize: ").append(toIndentedString(ignitePoolSize)).append("\n");
    sb.append("    cacheCotInRepository: ").append(toIndentedString(cacheCotInRepository)).append("\n");
    sb.append("    enableCachePersistence: ").append(toIndentedString(enableCachePersistence)).append("\n");
    sb.append("    messageTimestampCacheSizeItems: ").append(toIndentedString(messageTimestampCacheSizeItems)).append("\n");
    sb.append("    enableStoreForwardChat: ").append(toIndentedString(enableStoreForwardChat)).append("\n");
    sb.append("    storeForwardQueryBufferMs: ").append(toIndentedString(storeForwardQueryBufferMs)).append("\n");
    sb.append("    storeForwardSendBufferMs: ").append(toIndentedString(storeForwardSendBufferMs)).append("\n");
    sb.append("    enableClientEndpointCache: ").append(toIndentedString(enableClientEndpointCache)).append("\n");
    sb.append("    contactCacheUpdateRateLimitSeconds: ").append(toIndentedString(contactCacheUpdateRateLimitSeconds)).append("\n");
    sb.append("    contactCacheRecencyLimitSeconds: ").append(toIndentedString(contactCacheRecencyLimitSeconds)).append("\n");
    sb.append("    pluginDatafeedCacheSeconds: ").append(toIndentedString(pluginDatafeedCacheSeconds)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
