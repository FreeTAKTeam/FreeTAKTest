package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class Envelope   {
  private Boolean _null = null;  private Double diameter = null;  private Double width = null;  private Double height = null;  private Double area = null;  private Double maxX = null;  private Double maxY = null;  private Double minX = null;  private Double minY = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("null")
  public Boolean isNull() {
    return _null;
  }
  public void setNull(Boolean _null) {
    this._null = _null;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("diameter")
  public Double getDiameter() {
    return diameter;
  }
  public void setDiameter(Double diameter) {
    this.diameter = diameter;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("width")
  public Double getWidth() {
    return width;
  }
  public void setWidth(Double width) {
    this.width = width;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("height")
  public Double getHeight() {
    return height;
  }
  public void setHeight(Double height) {
    this.height = height;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("area")
  public Double getArea() {
    return area;
  }
  public void setArea(Double area) {
    this.area = area;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("maxX")
  public Double getMaxX() {
    return maxX;
  }
  public void setMaxX(Double maxX) {
    this.maxX = maxX;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("maxY")
  public Double getMaxY() {
    return maxY;
  }
  public void setMaxY(Double maxY) {
    this.maxY = maxY;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("minX")
  public Double getMinX() {
    return minX;
  }
  public void setMinX(Double minX) {
    this.minX = minX;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("minY")
  public Double getMinY() {
    return minY;
  }
  public void setMinY(Double minY) {
    this.minY = minY;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Envelope envelope = (Envelope) o;
    return Objects.equals(_null, envelope._null) &&
        Objects.equals(diameter, envelope.diameter) &&
        Objects.equals(width, envelope.width) &&
        Objects.equals(height, envelope.height) &&
        Objects.equals(area, envelope.area) &&
        Objects.equals(maxX, envelope.maxX) &&
        Objects.equals(maxY, envelope.maxY) &&
        Objects.equals(minX, envelope.minX) &&
        Objects.equals(minY, envelope.minY);
  }

  @Override
  public int hashCode() {
    return Objects.hash(_null, diameter, width, height, area, maxX, maxY, minX, minY);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Envelope {\n");
    
    sb.append("    _null: ").append(toIndentedString(_null)).append("\n");
    sb.append("    diameter: ").append(toIndentedString(diameter)).append("\n");
    sb.append("    width: ").append(toIndentedString(width)).append("\n");
    sb.append("    height: ").append(toIndentedString(height)).append("\n");
    sb.append("    area: ").append(toIndentedString(area)).append("\n");
    sb.append("    maxX: ").append(toIndentedString(maxX)).append("\n");
    sb.append("    maxY: ").append(toIndentedString(maxY)).append("\n");
    sb.append("    minX: ").append(toIndentedString(minX)).append("\n");
    sb.append("    minY: ").append(toIndentedString(minY)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
