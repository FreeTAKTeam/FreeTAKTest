package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.CoordinateSequenceFactory;
import io.swagger.model.PrecisionModel;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class GeometryFactory   {
  private PrecisionModel precisionModel = null;  private CoordinateSequenceFactory coordinateSequenceFactory = null;  private Integer srid = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("precisionModel")
  public PrecisionModel getPrecisionModel() {
    return precisionModel;
  }
  public void setPrecisionModel(PrecisionModel precisionModel) {
    this.precisionModel = precisionModel;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("coordinateSequenceFactory")
  public CoordinateSequenceFactory getCoordinateSequenceFactory() {
    return coordinateSequenceFactory;
  }
  public void setCoordinateSequenceFactory(CoordinateSequenceFactory coordinateSequenceFactory) {
    this.coordinateSequenceFactory = coordinateSequenceFactory;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("srid")
  public Integer getSrid() {
    return srid;
  }
  public void setSrid(Integer srid) {
    this.srid = srid;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    GeometryFactory geometryFactory = (GeometryFactory) o;
    return Objects.equals(precisionModel, geometryFactory.precisionModel) &&
        Objects.equals(coordinateSequenceFactory, geometryFactory.coordinateSequenceFactory) &&
        Objects.equals(srid, geometryFactory.srid);
  }

  @Override
  public int hashCode() {
    return Objects.hash(precisionModel, coordinateSequenceFactory, srid);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class GeometryFactory {\n");
    
    sb.append("    precisionModel: ").append(toIndentedString(precisionModel)).append("\n");
    sb.append("    coordinateSequenceFactory: ").append(toIndentedString(coordinateSequenceFactory)).append("\n");
    sb.append("    srid: ").append(toIndentedString(srid)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
