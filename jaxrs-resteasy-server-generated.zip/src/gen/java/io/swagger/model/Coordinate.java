package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.Coordinate;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class Coordinate   {
  private Double x = null;  private Double y = null;  private Double z = null;  private Double m = null;  private Coordinate coordinate = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("x")
  public Double getX() {
    return x;
  }
  public void setX(Double x) {
    this.x = x;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("y")
  public Double getY() {
    return y;
  }
  public void setY(Double y) {
    this.y = y;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("z")
  public Double getZ() {
    return z;
  }
  public void setZ(Double z) {
    this.z = z;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("m")
  public Double getM() {
    return m;
  }
  public void setM(Double m) {
    this.m = m;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("coordinate")
  public Coordinate getCoordinate() {
    return coordinate;
  }
  public void setCoordinate(Coordinate coordinate) {
    this.coordinate = coordinate;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Coordinate coordinate = (Coordinate) o;
    return Objects.equals(x, coordinate.x) &&
        Objects.equals(y, coordinate.y) &&
        Objects.equals(z, coordinate.z) &&
        Objects.equals(m, coordinate.m) &&
        Objects.equals(coordinate, coordinate.coordinate);
  }

  @Override
  public int hashCode() {
    return Objects.hash(x, y, z, m, coordinate);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Coordinate {\n");
    
    sb.append("    x: ").append(toIndentedString(x)).append("\n");
    sb.append("    y: ").append(toIndentedString(y)).append("\n");
    sb.append("    z: ").append(toIndentedString(z)).append("\n");
    sb.append("    m: ").append(toIndentedString(m)).append("\n");
    sb.append("    coordinate: ").append(toIndentedString(coordinate)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
