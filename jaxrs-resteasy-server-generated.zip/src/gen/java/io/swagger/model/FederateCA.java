package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import java.util.List;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class FederateCA   {
  private List<String> inboundGroup = new ArrayList<String>();  private List<String> outboundGroup = new ArrayList<String>();  private String fingerprint = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("inboundGroup")
  public List<String> getInboundGroup() {
    return inboundGroup;
  }
  public void setInboundGroup(List<String> inboundGroup) {
    this.inboundGroup = inboundGroup;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("outboundGroup")
  public List<String> getOutboundGroup() {
    return outboundGroup;
  }
  public void setOutboundGroup(List<String> outboundGroup) {
    this.outboundGroup = outboundGroup;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("fingerprint")
  public String getFingerprint() {
    return fingerprint;
  }
  public void setFingerprint(String fingerprint) {
    this.fingerprint = fingerprint;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    FederateCA federateCA = (FederateCA) o;
    return Objects.equals(inboundGroup, federateCA.inboundGroup) &&
        Objects.equals(outboundGroup, federateCA.outboundGroup) &&
        Objects.equals(fingerprint, federateCA.fingerprint);
  }

  @Override
  public int hashCode() {
    return Objects.hash(inboundGroup, outboundGroup, fingerprint);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class FederateCA {\n");
    
    sb.append("    inboundGroup: ").append(toIndentedString(inboundGroup)).append("\n");
    sb.append("    outboundGroup: ").append(toIndentedString(outboundGroup)).append("\n");
    sb.append("    fingerprint: ").append(toIndentedString(fingerprint)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
