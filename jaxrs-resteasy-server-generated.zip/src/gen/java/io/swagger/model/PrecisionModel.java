package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.Type;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class PrecisionModel   {
  private Double scale = null;  private Type type = null;  private Boolean floating = null;  private Integer maximumSignificantDigits = null;  private Double offsetX = null;  private Double offsetY = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("scale")
  public Double getScale() {
    return scale;
  }
  public void setScale(Double scale) {
    this.scale = scale;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("type")
  public Type getType() {
    return type;
  }
  public void setType(Type type) {
    this.type = type;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("floating")
  public Boolean isFloating() {
    return floating;
  }
  public void setFloating(Boolean floating) {
    this.floating = floating;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("maximumSignificantDigits")
  public Integer getMaximumSignificantDigits() {
    return maximumSignificantDigits;
  }
  public void setMaximumSignificantDigits(Integer maximumSignificantDigits) {
    this.maximumSignificantDigits = maximumSignificantDigits;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("offsetX")
  public Double getOffsetX() {
    return offsetX;
  }
  public void setOffsetX(Double offsetX) {
    this.offsetX = offsetX;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("offsetY")
  public Double getOffsetY() {
    return offsetY;
  }
  public void setOffsetY(Double offsetY) {
    this.offsetY = offsetY;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    PrecisionModel precisionModel = (PrecisionModel) o;
    return Objects.equals(scale, precisionModel.scale) &&
        Objects.equals(type, precisionModel.type) &&
        Objects.equals(floating, precisionModel.floating) &&
        Objects.equals(maximumSignificantDigits, precisionModel.maximumSignificantDigits) &&
        Objects.equals(offsetX, precisionModel.offsetX) &&
        Objects.equals(offsetY, precisionModel.offsetY);
  }

  @Override
  public int hashCode() {
    return Objects.hash(scale, type, floating, maximumSignificantDigits, offsetX, offsetY);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PrecisionModel {\n");
    
    sb.append("    scale: ").append(toIndentedString(scale)).append("\n");
    sb.append("    type: ").append(toIndentedString(type)).append("\n");
    sb.append("    floating: ").append(toIndentedString(floating)).append("\n");
    sb.append("    maximumSignificantDigits: ").append(toIndentedString(maximumSignificantDigits)).append("\n");
    sb.append("    offsetX: ").append(toIndentedString(offsetX)).append("\n");
    sb.append("    offsetY: ").append(toIndentedString(offsetY)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
