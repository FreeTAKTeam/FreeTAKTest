package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class MicrosoftCAConfig   {
  private String username = null;  private String password = null;  private String truststore = null;  private String truststorePass = null;  private String svcUrl = null;  private String templateName = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("username")
  public String getUsername() {
    return username;
  }
  public void setUsername(String username) {
    this.username = username;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("password")
  public String getPassword() {
    return password;
  }
  public void setPassword(String password) {
    this.password = password;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("truststore")
  public String getTruststore() {
    return truststore;
  }
  public void setTruststore(String truststore) {
    this.truststore = truststore;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("truststorePass")
  public String getTruststorePass() {
    return truststorePass;
  }
  public void setTruststorePass(String truststorePass) {
    this.truststorePass = truststorePass;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("svcUrl")
  public String getSvcUrl() {
    return svcUrl;
  }
  public void setSvcUrl(String svcUrl) {
    this.svcUrl = svcUrl;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("templateName")
  public String getTemplateName() {
    return templateName;
  }
  public void setTemplateName(String templateName) {
    this.templateName = templateName;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    MicrosoftCAConfig microsoftCAConfig = (MicrosoftCAConfig) o;
    return Objects.equals(username, microsoftCAConfig.username) &&
        Objects.equals(password, microsoftCAConfig.password) &&
        Objects.equals(truststore, microsoftCAConfig.truststore) &&
        Objects.equals(truststorePass, microsoftCAConfig.truststorePass) &&
        Objects.equals(svcUrl, microsoftCAConfig.svcUrl) &&
        Objects.equals(templateName, microsoftCAConfig.templateName);
  }

  @Override
  public int hashCode() {
    return Objects.hash(username, password, truststore, truststorePass, svcUrl, templateName);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class MicrosoftCAConfig {\n");
    
    sb.append("    username: ").append(toIndentedString(username)).append("\n");
    sb.append("    password: ").append(toIndentedString(password)).append("\n");
    sb.append("    truststore: ").append(toIndentedString(truststore)).append("\n");
    sb.append("    truststorePass: ").append(toIndentedString(truststorePass)).append("\n");
    sb.append("    svcUrl: ").append(toIndentedString(svcUrl)).append("\n");
    sb.append("    templateName: ").append(toIndentedString(templateName)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
