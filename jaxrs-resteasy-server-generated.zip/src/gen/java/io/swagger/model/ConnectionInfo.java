package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.ConnectionInfoCert;
import io.swagger.model.ConnectionInfoReadCount;
import io.swagger.model.Input;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class ConnectionInfo   {
  private String connectionId = null;  private String nodeId = null;  private Integer port = null;  private String address = null;  private Boolean tls = null;  private Input input = null;  private ConnectionInfoCert cert = null;  private ConnectionInfoCert caCert = null;  private Boolean client = null;  private Object handler = null;  private ConnectionInfoReadCount readCount = null;  private ConnectionInfoReadCount processedCount = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("connectionId")
  public String getConnectionId() {
    return connectionId;
  }
  public void setConnectionId(String connectionId) {
    this.connectionId = connectionId;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("nodeId")
  public String getNodeId() {
    return nodeId;
  }
  public void setNodeId(String nodeId) {
    this.nodeId = nodeId;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("port")
  public Integer getPort() {
    return port;
  }
  public void setPort(Integer port) {
    this.port = port;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("address")
  public String getAddress() {
    return address;
  }
  public void setAddress(String address) {
    this.address = address;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("tls")
  public Boolean isTls() {
    return tls;
  }
  public void setTls(Boolean tls) {
    this.tls = tls;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("input")
  public Input getInput() {
    return input;
  }
  public void setInput(Input input) {
    this.input = input;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("cert")
  public ConnectionInfoCert getCert() {
    return cert;
  }
  public void setCert(ConnectionInfoCert cert) {
    this.cert = cert;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("caCert")
  public ConnectionInfoCert getCaCert() {
    return caCert;
  }
  public void setCaCert(ConnectionInfoCert caCert) {
    this.caCert = caCert;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("client")
  public Boolean isClient() {
    return client;
  }
  public void setClient(Boolean client) {
    this.client = client;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("handler")
  public Object getHandler() {
    return handler;
  }
  public void setHandler(Object handler) {
    this.handler = handler;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("readCount")
  public ConnectionInfoReadCount getReadCount() {
    return readCount;
  }
  public void setReadCount(ConnectionInfoReadCount readCount) {
    this.readCount = readCount;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("processedCount")
  public ConnectionInfoReadCount getProcessedCount() {
    return processedCount;
  }
  public void setProcessedCount(ConnectionInfoReadCount processedCount) {
    this.processedCount = processedCount;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ConnectionInfo connectionInfo = (ConnectionInfo) o;
    return Objects.equals(connectionId, connectionInfo.connectionId) &&
        Objects.equals(nodeId, connectionInfo.nodeId) &&
        Objects.equals(port, connectionInfo.port) &&
        Objects.equals(address, connectionInfo.address) &&
        Objects.equals(tls, connectionInfo.tls) &&
        Objects.equals(input, connectionInfo.input) &&
        Objects.equals(cert, connectionInfo.cert) &&
        Objects.equals(caCert, connectionInfo.caCert) &&
        Objects.equals(client, connectionInfo.client) &&
        Objects.equals(handler, connectionInfo.handler) &&
        Objects.equals(readCount, connectionInfo.readCount) &&
        Objects.equals(processedCount, connectionInfo.processedCount);
  }

  @Override
  public int hashCode() {
    return Objects.hash(connectionId, nodeId, port, address, tls, input, cert, caCert, client, handler, readCount, processedCount);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ConnectionInfo {\n");
    
    sb.append("    connectionId: ").append(toIndentedString(connectionId)).append("\n");
    sb.append("    nodeId: ").append(toIndentedString(nodeId)).append("\n");
    sb.append("    port: ").append(toIndentedString(port)).append("\n");
    sb.append("    address: ").append(toIndentedString(address)).append("\n");
    sb.append("    tls: ").append(toIndentedString(tls)).append("\n");
    sb.append("    input: ").append(toIndentedString(input)).append("\n");
    sb.append("    cert: ").append(toIndentedString(cert)).append("\n");
    sb.append("    caCert: ").append(toIndentedString(caCert)).append("\n");
    sb.append("    client: ").append(toIndentedString(client)).append("\n");
    sb.append("    handler: ").append(toIndentedString(handler)).append("\n");
    sb.append("    readCount: ").append(toIndentedString(readCount)).append("\n");
    sb.append("    processedCount: ").append(toIndentedString(processedCount)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
