package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import java.util.List;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class SimpleGroupWithUsersModel   {
  private String groupname = null;  private List<String> usersInGroupList = new ArrayList<String>();  private List<String> usersInGroupListIN = new ArrayList<String>();  private List<String> usersInGroupListOUT = new ArrayList<String>();

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("groupname")
  public String getGroupname() {
    return groupname;
  }
  public void setGroupname(String groupname) {
    this.groupname = groupname;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("usersInGroupList")
  public List<String> getUsersInGroupList() {
    return usersInGroupList;
  }
  public void setUsersInGroupList(List<String> usersInGroupList) {
    this.usersInGroupList = usersInGroupList;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("usersInGroupListIN")
  public List<String> getUsersInGroupListIN() {
    return usersInGroupListIN;
  }
  public void setUsersInGroupListIN(List<String> usersInGroupListIN) {
    this.usersInGroupListIN = usersInGroupListIN;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("usersInGroupListOUT")
  public List<String> getUsersInGroupListOUT() {
    return usersInGroupListOUT;
  }
  public void setUsersInGroupListOUT(List<String> usersInGroupListOUT) {
    this.usersInGroupListOUT = usersInGroupListOUT;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    SimpleGroupWithUsersModel simpleGroupWithUsersModel = (SimpleGroupWithUsersModel) o;
    return Objects.equals(groupname, simpleGroupWithUsersModel.groupname) &&
        Objects.equals(usersInGroupList, simpleGroupWithUsersModel.usersInGroupList) &&
        Objects.equals(usersInGroupListIN, simpleGroupWithUsersModel.usersInGroupListIN) &&
        Objects.equals(usersInGroupListOUT, simpleGroupWithUsersModel.usersInGroupListOUT);
  }

  @Override
  public int hashCode() {
    return Objects.hash(groupname, usersInGroupList, usersInGroupListIN, usersInGroupListOUT);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SimpleGroupWithUsersModel {\n");
    
    sb.append("    groupname: ").append(toIndentedString(groupname)).append("\n");
    sb.append("    usersInGroupList: ").append(toIndentedString(usersInGroupList)).append("\n");
    sb.append("    usersInGroupListIN: ").append(toIndentedString(usersInGroupListIN)).append("\n");
    sb.append("    usersInGroupListOUT: ").append(toIndentedString(usersInGroupListOUT)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
