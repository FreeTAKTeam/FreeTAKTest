package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.Group;
import io.swagger.model.RemoteSubscriptionMetrics;
import java.util.List;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class SubscriptionInfo   {
  private String dn = null;  private String callsign = null;  private String clientUid = null;  private Long lastReportMilliseconds = null;  private String takClient = null;  private String takVersion = null;  private String username = null;  private List<Group> groups = new ArrayList<Group>();  private String role = null;  private String team = null;  private String ipAddress = null;  private String port = null;  private Long pendingWrites = null;  private Long numProcessed = null;  private String protocol = null;  private String xpath = null;  private String subscriptionUid = null;  private String appFramerate = null;  private String battery = null;  private String batteryStatus = null;  private String batteryTemp = null;  private String deviceDataRx = null;  private String deviceDataTx = null;  private String heapCurrentSize = null;  private String heapFreeSize = null;  private String heapMaxSize = null;  private String deviceIPAddress = null;  private String storageAvailable = null;  private String storageTotal = null;  private Boolean incognito = null;  private String handlerType = null;  private Long lastReportDiffMilliseconds = null;  private RemoteSubscriptionMetrics metrics = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("dn")
  public String getDn() {
    return dn;
  }
  public void setDn(String dn) {
    this.dn = dn;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("callsign")
  public String getCallsign() {
    return callsign;
  }
  public void setCallsign(String callsign) {
    this.callsign = callsign;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("clientUid")
  public String getClientUid() {
    return clientUid;
  }
  public void setClientUid(String clientUid) {
    this.clientUid = clientUid;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("lastReportMilliseconds")
  public Long getLastReportMilliseconds() {
    return lastReportMilliseconds;
  }
  public void setLastReportMilliseconds(Long lastReportMilliseconds) {
    this.lastReportMilliseconds = lastReportMilliseconds;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("takClient")
  public String getTakClient() {
    return takClient;
  }
  public void setTakClient(String takClient) {
    this.takClient = takClient;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("takVersion")
  public String getTakVersion() {
    return takVersion;
  }
  public void setTakVersion(String takVersion) {
    this.takVersion = takVersion;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("username")
  public String getUsername() {
    return username;
  }
  public void setUsername(String username) {
    this.username = username;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("groups")
  public List<Group> getGroups() {
    return groups;
  }
  public void setGroups(List<Group> groups) {
    this.groups = groups;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("role")
  public String getRole() {
    return role;
  }
  public void setRole(String role) {
    this.role = role;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("team")
  public String getTeam() {
    return team;
  }
  public void setTeam(String team) {
    this.team = team;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("ipAddress")
  public String getIpAddress() {
    return ipAddress;
  }
  public void setIpAddress(String ipAddress) {
    this.ipAddress = ipAddress;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("port")
  public String getPort() {
    return port;
  }
  public void setPort(String port) {
    this.port = port;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("pendingWrites")
  public Long getPendingWrites() {
    return pendingWrites;
  }
  public void setPendingWrites(Long pendingWrites) {
    this.pendingWrites = pendingWrites;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("numProcessed")
  public Long getNumProcessed() {
    return numProcessed;
  }
  public void setNumProcessed(Long numProcessed) {
    this.numProcessed = numProcessed;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("protocol")
  public String getProtocol() {
    return protocol;
  }
  public void setProtocol(String protocol) {
    this.protocol = protocol;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("xpath")
  public String getXpath() {
    return xpath;
  }
  public void setXpath(String xpath) {
    this.xpath = xpath;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("subscriptionUid")
  public String getSubscriptionUid() {
    return subscriptionUid;
  }
  public void setSubscriptionUid(String subscriptionUid) {
    this.subscriptionUid = subscriptionUid;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("appFramerate")
  public String getAppFramerate() {
    return appFramerate;
  }
  public void setAppFramerate(String appFramerate) {
    this.appFramerate = appFramerate;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("battery")
  public String getBattery() {
    return battery;
  }
  public void setBattery(String battery) {
    this.battery = battery;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("batteryStatus")
  public String getBatteryStatus() {
    return batteryStatus;
  }
  public void setBatteryStatus(String batteryStatus) {
    this.batteryStatus = batteryStatus;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("batteryTemp")
  public String getBatteryTemp() {
    return batteryTemp;
  }
  public void setBatteryTemp(String batteryTemp) {
    this.batteryTemp = batteryTemp;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("deviceDataRx")
  public String getDeviceDataRx() {
    return deviceDataRx;
  }
  public void setDeviceDataRx(String deviceDataRx) {
    this.deviceDataRx = deviceDataRx;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("deviceDataTx")
  public String getDeviceDataTx() {
    return deviceDataTx;
  }
  public void setDeviceDataTx(String deviceDataTx) {
    this.deviceDataTx = deviceDataTx;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("heapCurrentSize")
  public String getHeapCurrentSize() {
    return heapCurrentSize;
  }
  public void setHeapCurrentSize(String heapCurrentSize) {
    this.heapCurrentSize = heapCurrentSize;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("heapFreeSize")
  public String getHeapFreeSize() {
    return heapFreeSize;
  }
  public void setHeapFreeSize(String heapFreeSize) {
    this.heapFreeSize = heapFreeSize;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("heapMaxSize")
  public String getHeapMaxSize() {
    return heapMaxSize;
  }
  public void setHeapMaxSize(String heapMaxSize) {
    this.heapMaxSize = heapMaxSize;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("deviceIPAddress")
  public String getDeviceIPAddress() {
    return deviceIPAddress;
  }
  public void setDeviceIPAddress(String deviceIPAddress) {
    this.deviceIPAddress = deviceIPAddress;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("storageAvailable")
  public String getStorageAvailable() {
    return storageAvailable;
  }
  public void setStorageAvailable(String storageAvailable) {
    this.storageAvailable = storageAvailable;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("storageTotal")
  public String getStorageTotal() {
    return storageTotal;
  }
  public void setStorageTotal(String storageTotal) {
    this.storageTotal = storageTotal;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("incognito")
  public Boolean isIncognito() {
    return incognito;
  }
  public void setIncognito(Boolean incognito) {
    this.incognito = incognito;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("handlerType")
  public String getHandlerType() {
    return handlerType;
  }
  public void setHandlerType(String handlerType) {
    this.handlerType = handlerType;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("lastReportDiffMilliseconds")
  public Long getLastReportDiffMilliseconds() {
    return lastReportDiffMilliseconds;
  }
  public void setLastReportDiffMilliseconds(Long lastReportDiffMilliseconds) {
    this.lastReportDiffMilliseconds = lastReportDiffMilliseconds;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("metrics")
  public RemoteSubscriptionMetrics getMetrics() {
    return metrics;
  }
  public void setMetrics(RemoteSubscriptionMetrics metrics) {
    this.metrics = metrics;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    SubscriptionInfo subscriptionInfo = (SubscriptionInfo) o;
    return Objects.equals(dn, subscriptionInfo.dn) &&
        Objects.equals(callsign, subscriptionInfo.callsign) &&
        Objects.equals(clientUid, subscriptionInfo.clientUid) &&
        Objects.equals(lastReportMilliseconds, subscriptionInfo.lastReportMilliseconds) &&
        Objects.equals(takClient, subscriptionInfo.takClient) &&
        Objects.equals(takVersion, subscriptionInfo.takVersion) &&
        Objects.equals(username, subscriptionInfo.username) &&
        Objects.equals(groups, subscriptionInfo.groups) &&
        Objects.equals(role, subscriptionInfo.role) &&
        Objects.equals(team, subscriptionInfo.team) &&
        Objects.equals(ipAddress, subscriptionInfo.ipAddress) &&
        Objects.equals(port, subscriptionInfo.port) &&
        Objects.equals(pendingWrites, subscriptionInfo.pendingWrites) &&
        Objects.equals(numProcessed, subscriptionInfo.numProcessed) &&
        Objects.equals(protocol, subscriptionInfo.protocol) &&
        Objects.equals(xpath, subscriptionInfo.xpath) &&
        Objects.equals(subscriptionUid, subscriptionInfo.subscriptionUid) &&
        Objects.equals(appFramerate, subscriptionInfo.appFramerate) &&
        Objects.equals(battery, subscriptionInfo.battery) &&
        Objects.equals(batteryStatus, subscriptionInfo.batteryStatus) &&
        Objects.equals(batteryTemp, subscriptionInfo.batteryTemp) &&
        Objects.equals(deviceDataRx, subscriptionInfo.deviceDataRx) &&
        Objects.equals(deviceDataTx, subscriptionInfo.deviceDataTx) &&
        Objects.equals(heapCurrentSize, subscriptionInfo.heapCurrentSize) &&
        Objects.equals(heapFreeSize, subscriptionInfo.heapFreeSize) &&
        Objects.equals(heapMaxSize, subscriptionInfo.heapMaxSize) &&
        Objects.equals(deviceIPAddress, subscriptionInfo.deviceIPAddress) &&
        Objects.equals(storageAvailable, subscriptionInfo.storageAvailable) &&
        Objects.equals(storageTotal, subscriptionInfo.storageTotal) &&
        Objects.equals(incognito, subscriptionInfo.incognito) &&
        Objects.equals(handlerType, subscriptionInfo.handlerType) &&
        Objects.equals(lastReportDiffMilliseconds, subscriptionInfo.lastReportDiffMilliseconds) &&
        Objects.equals(metrics, subscriptionInfo.metrics);
  }

  @Override
  public int hashCode() {
    return Objects.hash(dn, callsign, clientUid, lastReportMilliseconds, takClient, takVersion, username, groups, role, team, ipAddress, port, pendingWrites, numProcessed, protocol, xpath, subscriptionUid, appFramerate, battery, batteryStatus, batteryTemp, deviceDataRx, deviceDataTx, heapCurrentSize, heapFreeSize, heapMaxSize, deviceIPAddress, storageAvailable, storageTotal, incognito, handlerType, lastReportDiffMilliseconds, metrics);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class SubscriptionInfo {\n");
    
    sb.append("    dn: ").append(toIndentedString(dn)).append("\n");
    sb.append("    callsign: ").append(toIndentedString(callsign)).append("\n");
    sb.append("    clientUid: ").append(toIndentedString(clientUid)).append("\n");
    sb.append("    lastReportMilliseconds: ").append(toIndentedString(lastReportMilliseconds)).append("\n");
    sb.append("    takClient: ").append(toIndentedString(takClient)).append("\n");
    sb.append("    takVersion: ").append(toIndentedString(takVersion)).append("\n");
    sb.append("    username: ").append(toIndentedString(username)).append("\n");
    sb.append("    groups: ").append(toIndentedString(groups)).append("\n");
    sb.append("    role: ").append(toIndentedString(role)).append("\n");
    sb.append("    team: ").append(toIndentedString(team)).append("\n");
    sb.append("    ipAddress: ").append(toIndentedString(ipAddress)).append("\n");
    sb.append("    port: ").append(toIndentedString(port)).append("\n");
    sb.append("    pendingWrites: ").append(toIndentedString(pendingWrites)).append("\n");
    sb.append("    numProcessed: ").append(toIndentedString(numProcessed)).append("\n");
    sb.append("    protocol: ").append(toIndentedString(protocol)).append("\n");
    sb.append("    xpath: ").append(toIndentedString(xpath)).append("\n");
    sb.append("    subscriptionUid: ").append(toIndentedString(subscriptionUid)).append("\n");
    sb.append("    appFramerate: ").append(toIndentedString(appFramerate)).append("\n");
    sb.append("    battery: ").append(toIndentedString(battery)).append("\n");
    sb.append("    batteryStatus: ").append(toIndentedString(batteryStatus)).append("\n");
    sb.append("    batteryTemp: ").append(toIndentedString(batteryTemp)).append("\n");
    sb.append("    deviceDataRx: ").append(toIndentedString(deviceDataRx)).append("\n");
    sb.append("    deviceDataTx: ").append(toIndentedString(deviceDataTx)).append("\n");
    sb.append("    heapCurrentSize: ").append(toIndentedString(heapCurrentSize)).append("\n");
    sb.append("    heapFreeSize: ").append(toIndentedString(heapFreeSize)).append("\n");
    sb.append("    heapMaxSize: ").append(toIndentedString(heapMaxSize)).append("\n");
    sb.append("    deviceIPAddress: ").append(toIndentedString(deviceIPAddress)).append("\n");
    sb.append("    storageAvailable: ").append(toIndentedString(storageAvailable)).append("\n");
    sb.append("    storageTotal: ").append(toIndentedString(storageTotal)).append("\n");
    sb.append("    incognito: ").append(toIndentedString(incognito)).append("\n");
    sb.append("    handlerType: ").append(toIndentedString(handlerType)).append("\n");
    sb.append("    lastReportDiffMilliseconds: ").append(toIndentedString(lastReportDiffMilliseconds)).append("\n");
    sb.append("    metrics: ").append(toIndentedString(metrics)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
