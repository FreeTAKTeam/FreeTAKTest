package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class IdAttachmentBody   {
  private Integer _short = null;  private String _char = null;  private Integer _int = null;  private Long _long = null;  private Float _float = null;  private Double _double = null;  private Boolean direct = null;  private Boolean readOnly = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("short")
  public Integer getShort() {
    return _short;
  }
  public void setShort(Integer _short) {
    this._short = _short;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("char")
  public String getChar() {
    return _char;
  }
  public void setChar(String _char) {
    this._char = _char;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("int")
  public Integer getInt() {
    return _int;
  }
  public void setInt(Integer _int) {
    this._int = _int;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("long")
  public Long getLong() {
    return _long;
  }
  public void setLong(Long _long) {
    this._long = _long;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("float")
  public Float getFloat() {
    return _float;
  }
  public void setFloat(Float _float) {
    this._float = _float;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("double")
  public Double getDouble() {
    return _double;
  }
  public void setDouble(Double _double) {
    this._double = _double;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("direct")
  public Boolean isDirect() {
    return direct;
  }
  public void setDirect(Boolean direct) {
    this.direct = direct;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("readOnly")
  public Boolean isReadOnly() {
    return readOnly;
  }
  public void setReadOnly(Boolean readOnly) {
    this.readOnly = readOnly;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    IdAttachmentBody idAttachmentBody = (IdAttachmentBody) o;
    return Objects.equals(_short, idAttachmentBody._short) &&
        Objects.equals(_char, idAttachmentBody._char) &&
        Objects.equals(_int, idAttachmentBody._int) &&
        Objects.equals(_long, idAttachmentBody._long) &&
        Objects.equals(_float, idAttachmentBody._float) &&
        Objects.equals(_double, idAttachmentBody._double) &&
        Objects.equals(direct, idAttachmentBody.direct) &&
        Objects.equals(readOnly, idAttachmentBody.readOnly);
  }

  @Override
  public int hashCode() {
    return Objects.hash(_short, _char, _int, _long, _float, _double, direct, readOnly);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class IdAttachmentBody {\n");
    
    sb.append("    _short: ").append(toIndentedString(_short)).append("\n");
    sb.append("    _char: ").append(toIndentedString(_char)).append("\n");
    sb.append("    _int: ").append(toIndentedString(_int)).append("\n");
    sb.append("    _long: ").append(toIndentedString(_long)).append("\n");
    sb.append("    _float: ").append(toIndentedString(_float)).append("\n");
    sb.append("    _double: ").append(toIndentedString(_double)).append("\n");
    sb.append("    direct: ").append(toIndentedString(direct)).append("\n");
    sb.append("    readOnly: ").append(toIndentedString(readOnly)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
