package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import java.util.List;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class Whitelist   {
  private List<String> groups = new ArrayList<String>();  private String domain = null;  private String token = null;  private Boolean privateGroup = null;  private String group = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("groups")
  public List<String> getGroups() {
    return groups;
  }
  public void setGroups(List<String> groups) {
    this.groups = groups;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("domain")
  public String getDomain() {
    return domain;
  }
  public void setDomain(String domain) {
    this.domain = domain;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("token")
  public String getToken() {
    return token;
  }
  public void setToken(String token) {
    this.token = token;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("privateGroup")
  public Boolean isPrivateGroup() {
    return privateGroup;
  }
  public void setPrivateGroup(Boolean privateGroup) {
    this.privateGroup = privateGroup;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("group")
  public String getGroup() {
    return group;
  }
  public void setGroup(String group) {
    this.group = group;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Whitelist whitelist = (Whitelist) o;
    return Objects.equals(groups, whitelist.groups) &&
        Objects.equals(domain, whitelist.domain) &&
        Objects.equals(token, whitelist.token) &&
        Objects.equals(privateGroup, whitelist.privateGroup) &&
        Objects.equals(group, whitelist.group);
  }

  @Override
  public int hashCode() {
    return Objects.hash(groups, domain, token, privateGroup, group);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Whitelist {\n");
    
    sb.append("    groups: ").append(toIndentedString(groups)).append("\n");
    sb.append("    domain: ").append(toIndentedString(domain)).append("\n");
    sb.append("    token: ").append(toIndentedString(token)).append("\n");
    sb.append("    privateGroup: ").append(toIndentedString(privateGroup)).append("\n");
    sb.append("    group: ").append(toIndentedString(group)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
