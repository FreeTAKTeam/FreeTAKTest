package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class VersionInfo   {
  private Long major = null;  private Long minor = null;  private Long patch = null;  private String branch = null;  private String variant = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("major")
  public Long getMajor() {
    return major;
  }
  public void setMajor(Long major) {
    this.major = major;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("minor")
  public Long getMinor() {
    return minor;
  }
  public void setMinor(Long minor) {
    this.minor = minor;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("patch")
  public Long getPatch() {
    return patch;
  }
  public void setPatch(Long patch) {
    this.patch = patch;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("branch")
  public String getBranch() {
    return branch;
  }
  public void setBranch(String branch) {
    this.branch = branch;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("variant")
  public String getVariant() {
    return variant;
  }
  public void setVariant(String variant) {
    this.variant = variant;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    VersionInfo versionInfo = (VersionInfo) o;
    return Objects.equals(major, versionInfo.major) &&
        Objects.equals(minor, versionInfo.minor) &&
        Objects.equals(patch, versionInfo.patch) &&
        Objects.equals(branch, versionInfo.branch) &&
        Objects.equals(variant, versionInfo.variant);
  }

  @Override
  public int hashCode() {
    return Objects.hash(major, minor, patch, branch, variant);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class VersionInfo {\n");
    
    sb.append("    major: ").append(toIndentedString(major)).append("\n");
    sb.append("    minor: ").append(toIndentedString(minor)).append("\n");
    sb.append("    patch: ").append(toIndentedString(patch)).append("\n");
    sb.append("    branch: ").append(toIndentedString(branch)).append("\n");
    sb.append("    variant: ").append(toIndentedString(variant)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
