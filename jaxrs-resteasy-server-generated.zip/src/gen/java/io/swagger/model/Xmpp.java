package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class Xmpp   {
  private String xmppHost = null;  private Integer xmppPort = null;  private String takServerHost = null;  private Integer takServerPort = null;  private String xmppSharedSecret = null;  private Integer xmppComponentRetryCount = null;  private Integer xmppComponentRetryDelay = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("xmppHost")
  public String getXmppHost() {
    return xmppHost;
  }
  public void setXmppHost(String xmppHost) {
    this.xmppHost = xmppHost;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("xmppPort")
  public Integer getXmppPort() {
    return xmppPort;
  }
  public void setXmppPort(Integer xmppPort) {
    this.xmppPort = xmppPort;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("takServerHost")
  public String getTakServerHost() {
    return takServerHost;
  }
  public void setTakServerHost(String takServerHost) {
    this.takServerHost = takServerHost;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("takServerPort")
  public Integer getTakServerPort() {
    return takServerPort;
  }
  public void setTakServerPort(Integer takServerPort) {
    this.takServerPort = takServerPort;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("xmppSharedSecret")
  public String getXmppSharedSecret() {
    return xmppSharedSecret;
  }
  public void setXmppSharedSecret(String xmppSharedSecret) {
    this.xmppSharedSecret = xmppSharedSecret;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("xmppComponentRetryCount")
  public Integer getXmppComponentRetryCount() {
    return xmppComponentRetryCount;
  }
  public void setXmppComponentRetryCount(Integer xmppComponentRetryCount) {
    this.xmppComponentRetryCount = xmppComponentRetryCount;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("xmppComponentRetryDelay")
  public Integer getXmppComponentRetryDelay() {
    return xmppComponentRetryDelay;
  }
  public void setXmppComponentRetryDelay(Integer xmppComponentRetryDelay) {
    this.xmppComponentRetryDelay = xmppComponentRetryDelay;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Xmpp xmpp = (Xmpp) o;
    return Objects.equals(xmppHost, xmpp.xmppHost) &&
        Objects.equals(xmppPort, xmpp.xmppPort) &&
        Objects.equals(takServerHost, xmpp.takServerHost) &&
        Objects.equals(takServerPort, xmpp.takServerPort) &&
        Objects.equals(xmppSharedSecret, xmpp.xmppSharedSecret) &&
        Objects.equals(xmppComponentRetryCount, xmpp.xmppComponentRetryCount) &&
        Objects.equals(xmppComponentRetryDelay, xmpp.xmppComponentRetryDelay);
  }

  @Override
  public int hashCode() {
    return Objects.hash(xmppHost, xmppPort, takServerHost, takServerPort, xmppSharedSecret, xmppComponentRetryCount, xmppComponentRetryDelay);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Xmpp {\n");
    
    sb.append("    xmppHost: ").append(toIndentedString(xmppHost)).append("\n");
    sb.append("    xmppPort: ").append(toIndentedString(xmppPort)).append("\n");
    sb.append("    takServerHost: ").append(toIndentedString(takServerHost)).append("\n");
    sb.append("    takServerPort: ").append(toIndentedString(takServerPort)).append("\n");
    sb.append("    xmppSharedSecret: ").append(toIndentedString(xmppSharedSecret)).append("\n");
    sb.append("    xmppComponentRetryCount: ").append(toIndentedString(xmppComponentRetryCount)).append("\n");
    sb.append("    xmppComponentRetryDelay: ").append(toIndentedString(xmppComponentRetryDelay)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
