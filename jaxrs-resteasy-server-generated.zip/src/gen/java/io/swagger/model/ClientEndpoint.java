package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import java.util.Date;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class ClientEndpoint   {
  private String callsign = null;  private String uid = null;  private String username = null;  private Date lastEventTime = null;  private String lastStatus = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("callsign")
  public String getCallsign() {
    return callsign;
  }
  public void setCallsign(String callsign) {
    this.callsign = callsign;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("uid")
  public String getUid() {
    return uid;
  }
  public void setUid(String uid) {
    this.uid = uid;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("username")
  public String getUsername() {
    return username;
  }
  public void setUsername(String username) {
    this.username = username;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("lastEventTime")
  public Date getLastEventTime() {
    return lastEventTime;
  }
  public void setLastEventTime(Date lastEventTime) {
    this.lastEventTime = lastEventTime;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("lastStatus")
  public String getLastStatus() {
    return lastStatus;
  }
  public void setLastStatus(String lastStatus) {
    this.lastStatus = lastStatus;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ClientEndpoint clientEndpoint = (ClientEndpoint) o;
    return Objects.equals(callsign, clientEndpoint.callsign) &&
        Objects.equals(uid, clientEndpoint.uid) &&
        Objects.equals(username, clientEndpoint.username) &&
        Objects.equals(lastEventTime, clientEndpoint.lastEventTime) &&
        Objects.equals(lastStatus, clientEndpoint.lastStatus);
  }

  @Override
  public int hashCode() {
    return Objects.hash(callsign, uid, username, lastEventTime, lastStatus);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ClientEndpoint {\n");
    
    sb.append("    callsign: ").append(toIndentedString(callsign)).append("\n");
    sb.append("    uid: ").append(toIndentedString(uid)).append("\n");
    sb.append("    username: ").append(toIndentedString(username)).append("\n");
    sb.append("    lastEventTime: ").append(toIndentedString(lastEventTime)).append("\n");
    sb.append("    lastStatus: ").append(toIndentedString(lastStatus)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
