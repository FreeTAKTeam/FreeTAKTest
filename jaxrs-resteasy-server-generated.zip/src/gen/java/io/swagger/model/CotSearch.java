package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import java.util.Date;
import java.util.List;
import java.util.Map;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class CotSearch   {
  /**
   * Gets or Sets status
   */
  public enum StatusEnum {
    NEW("NEW"),
    SUBMITTED("SUBMITTED"),
    PROCESSING("PROCESSING"),
    SENDING("SENDING"),
    REPLAYING("REPLAYING"),
    DONE("DONE"),
    ERROR("ERROR");
    private String value;

    StatusEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }
  }
  private StatusEnum status = null;  private String id = null;  private String message = null;  private Long bytesSent = null;  private Long count = null;  private Date timestamp = null;  private Boolean active = null;  private Long tag = null;  private Map<String, Date> statusTimestamps = new HashMap<String, Date>();

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("status")
  public StatusEnum getStatus() {
    return status;
  }
  public void setStatus(StatusEnum status) {
    this.status = status;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("id")
  public String getId() {
    return id;
  }
  public void setId(String id) {
    this.id = id;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("message")
  public String getMessage() {
    return message;
  }
  public void setMessage(String message) {
    this.message = message;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("bytesSent")
  public Long getBytesSent() {
    return bytesSent;
  }
  public void setBytesSent(Long bytesSent) {
    this.bytesSent = bytesSent;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("count")
  public Long getCount() {
    return count;
  }
  public void setCount(Long count) {
    this.count = count;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("timestamp")
  public Date getTimestamp() {
    return timestamp;
  }
  public void setTimestamp(Date timestamp) {
    this.timestamp = timestamp;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("active")
  public Boolean isActive() {
    return active;
  }
  public void setActive(Boolean active) {
    this.active = active;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("tag")
  public Long getTag() {
    return tag;
  }
  public void setTag(Long tag) {
    this.tag = tag;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("statusTimestamps")
  public Map<String, Date> getStatusTimestamps() {
    return statusTimestamps;
  }
  public void setStatusTimestamps(Map<String, Date> statusTimestamps) {
    this.statusTimestamps = statusTimestamps;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    CotSearch cotSearch = (CotSearch) o;
    return Objects.equals(status, cotSearch.status) &&
        Objects.equals(id, cotSearch.id) &&
        Objects.equals(message, cotSearch.message) &&
        Objects.equals(bytesSent, cotSearch.bytesSent) &&
        Objects.equals(count, cotSearch.count) &&
        Objects.equals(timestamp, cotSearch.timestamp) &&
        Objects.equals(active, cotSearch.active) &&
        Objects.equals(tag, cotSearch.tag) &&
        Objects.equals(statusTimestamps, cotSearch.statusTimestamps);
  }

  @Override
  public int hashCode() {
    return Objects.hash(status, id, message, bytesSent, count, timestamp, active, tag, statusTimestamps);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class CotSearch {\n");
    
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    message: ").append(toIndentedString(message)).append("\n");
    sb.append("    bytesSent: ").append(toIndentedString(bytesSent)).append("\n");
    sb.append("    count: ").append(toIndentedString(count)).append("\n");
    sb.append("    timestamp: ").append(toIndentedString(timestamp)).append("\n");
    sb.append("    active: ").append(toIndentedString(active)).append("\n");
    sb.append("    tag: ").append(toIndentedString(tag)).append("\n");
    sb.append("    statusTimestamps: ").append(toIndentedString(statusTimestamps)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
