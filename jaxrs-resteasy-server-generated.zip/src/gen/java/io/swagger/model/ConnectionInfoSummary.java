package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import io.swagger.model.Federate;
import io.swagger.model.Group;
import io.swagger.model.User;
import java.util.List;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class ConnectionInfoSummary   {
  private String federateId = null;  private String federateName = null;  private String remoteAddress = null;  private Integer remotePort = null;  private Boolean client = null;  private Integer readCount = null;  private Integer processedCount = null;  /**
   * Gets or Sets connectionStatusValue
   */
  public enum ConnectionStatusValueEnum {
    DISABLED("DISABLED"),
    CONNECTED("CONNECTED"),
    CONNECTING("CONNECTING"),
    WAITING_TO_RETRY("WAITING_TO_RETRY"),
    RETRY_SCHEDULED("RETRY_SCHEDULED");
    private String value;

    ConnectionStatusValueEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }
  }
  private ConnectionStatusValueEnum connectionStatusValue = null;  private String lastError = null;  private Federate federateConfig = null;  private User user = null;  private List<Group> groups = new ArrayList<Group>();

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("federateId")
  public String getFederateId() {
    return federateId;
  }
  public void setFederateId(String federateId) {
    this.federateId = federateId;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("federateName")
  public String getFederateName() {
    return federateName;
  }
  public void setFederateName(String federateName) {
    this.federateName = federateName;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("remoteAddress")
  public String getRemoteAddress() {
    return remoteAddress;
  }
  public void setRemoteAddress(String remoteAddress) {
    this.remoteAddress = remoteAddress;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("remotePort")
  public Integer getRemotePort() {
    return remotePort;
  }
  public void setRemotePort(Integer remotePort) {
    this.remotePort = remotePort;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("client")
  public Boolean isClient() {
    return client;
  }
  public void setClient(Boolean client) {
    this.client = client;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("readCount")
  public Integer getReadCount() {
    return readCount;
  }
  public void setReadCount(Integer readCount) {
    this.readCount = readCount;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("processedCount")
  public Integer getProcessedCount() {
    return processedCount;
  }
  public void setProcessedCount(Integer processedCount) {
    this.processedCount = processedCount;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("connectionStatusValue")
  public ConnectionStatusValueEnum getConnectionStatusValue() {
    return connectionStatusValue;
  }
  public void setConnectionStatusValue(ConnectionStatusValueEnum connectionStatusValue) {
    this.connectionStatusValue = connectionStatusValue;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("lastError")
  public String getLastError() {
    return lastError;
  }
  public void setLastError(String lastError) {
    this.lastError = lastError;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("federateConfig")
  public Federate getFederateConfig() {
    return federateConfig;
  }
  public void setFederateConfig(Federate federateConfig) {
    this.federateConfig = federateConfig;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("user")
  public User getUser() {
    return user;
  }
  public void setUser(User user) {
    this.user = user;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("groups")
  public List<Group> getGroups() {
    return groups;
  }
  public void setGroups(List<Group> groups) {
    this.groups = groups;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ConnectionInfoSummary connectionInfoSummary = (ConnectionInfoSummary) o;
    return Objects.equals(federateId, connectionInfoSummary.federateId) &&
        Objects.equals(federateName, connectionInfoSummary.federateName) &&
        Objects.equals(remoteAddress, connectionInfoSummary.remoteAddress) &&
        Objects.equals(remotePort, connectionInfoSummary.remotePort) &&
        Objects.equals(client, connectionInfoSummary.client) &&
        Objects.equals(readCount, connectionInfoSummary.readCount) &&
        Objects.equals(processedCount, connectionInfoSummary.processedCount) &&
        Objects.equals(connectionStatusValue, connectionInfoSummary.connectionStatusValue) &&
        Objects.equals(lastError, connectionInfoSummary.lastError) &&
        Objects.equals(federateConfig, connectionInfoSummary.federateConfig) &&
        Objects.equals(user, connectionInfoSummary.user) &&
        Objects.equals(groups, connectionInfoSummary.groups);
  }

  @Override
  public int hashCode() {
    return Objects.hash(federateId, federateName, remoteAddress, remotePort, client, readCount, processedCount, connectionStatusValue, lastError, federateConfig, user, groups);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ConnectionInfoSummary {\n");
    
    sb.append("    federateId: ").append(toIndentedString(federateId)).append("\n");
    sb.append("    federateName: ").append(toIndentedString(federateName)).append("\n");
    sb.append("    remoteAddress: ").append(toIndentedString(remoteAddress)).append("\n");
    sb.append("    remotePort: ").append(toIndentedString(remotePort)).append("\n");
    sb.append("    client: ").append(toIndentedString(client)).append("\n");
    sb.append("    readCount: ").append(toIndentedString(readCount)).append("\n");
    sb.append("    processedCount: ").append(toIndentedString(processedCount)).append("\n");
    sb.append("    connectionStatusValue: ").append(toIndentedString(connectionStatusValue)).append("\n");
    sb.append("    lastError: ").append(toIndentedString(lastError)).append("\n");
    sb.append("    federateConfig: ").append(toIndentedString(federateConfig)).append("\n");
    sb.append("    user: ").append(toIndentedString(user)).append("\n");
    sb.append("    groups: ").append(toIndentedString(groups)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
