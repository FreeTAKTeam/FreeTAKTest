package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.Federate;
import io.swagger.model.FederateCA;
import io.swagger.model.FederationOutgoing;
import io.swagger.model.FederationServer;
import io.swagger.model.FileFilter;
import io.swagger.model.MissionDisruptionTolerance;
import java.util.List;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class Federation   {
  private FederationServer federationServer = null;  private List<FederationOutgoing> federationOutgoing = new ArrayList<FederationOutgoing>();  private MissionDisruptionTolerance missionDisruptionTolerance = null;  private List<Federate> federate = new ArrayList<Federate>();  private FileFilter fileFilter = null;  private List<FederateCA> federateCA = new ArrayList<FederateCA>();  private Boolean allowDuplicate = null;  private Boolean allowFederatedDelete = null;  private Boolean allowMissionFederation = null;  private Boolean allowDataFeedFederation = null;  private Boolean enableMissionFederationDisruptionTolerance = null;  private Long missionFederationDisruptionToleranceRecencySeconds = null;  private Boolean federateOnlyPublicMissions = null;  private Boolean enableFederation = null;  private Boolean federatedGroupMapping = null;  private Boolean automaticGroupMapping = null;  private Boolean enableDataPackageAndMissionFileFilter = null;  private Boolean ivoidMyWarrantyAndWantToForwardFederationTraffic = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("federationServer")
  public FederationServer getFederationServer() {
    return federationServer;
  }
  public void setFederationServer(FederationServer federationServer) {
    this.federationServer = federationServer;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("federationOutgoing")
  public List<FederationOutgoing> getFederationOutgoing() {
    return federationOutgoing;
  }
  public void setFederationOutgoing(List<FederationOutgoing> federationOutgoing) {
    this.federationOutgoing = federationOutgoing;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("missionDisruptionTolerance")
  public MissionDisruptionTolerance getMissionDisruptionTolerance() {
    return missionDisruptionTolerance;
  }
  public void setMissionDisruptionTolerance(MissionDisruptionTolerance missionDisruptionTolerance) {
    this.missionDisruptionTolerance = missionDisruptionTolerance;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("federate")
  public List<Federate> getFederate() {
    return federate;
  }
  public void setFederate(List<Federate> federate) {
    this.federate = federate;
  }

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("fileFilter")
  @NotNull
  public FileFilter getFileFilter() {
    return fileFilter;
  }
  public void setFileFilter(FileFilter fileFilter) {
    this.fileFilter = fileFilter;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("federateCA")
  public List<FederateCA> getFederateCA() {
    return federateCA;
  }
  public void setFederateCA(List<FederateCA> federateCA) {
    this.federateCA = federateCA;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("allowDuplicate")
  public Boolean isAllowDuplicate() {
    return allowDuplicate;
  }
  public void setAllowDuplicate(Boolean allowDuplicate) {
    this.allowDuplicate = allowDuplicate;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("allowFederatedDelete")
  public Boolean isAllowFederatedDelete() {
    return allowFederatedDelete;
  }
  public void setAllowFederatedDelete(Boolean allowFederatedDelete) {
    this.allowFederatedDelete = allowFederatedDelete;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("allowMissionFederation")
  public Boolean isAllowMissionFederation() {
    return allowMissionFederation;
  }
  public void setAllowMissionFederation(Boolean allowMissionFederation) {
    this.allowMissionFederation = allowMissionFederation;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("allowDataFeedFederation")
  public Boolean isAllowDataFeedFederation() {
    return allowDataFeedFederation;
  }
  public void setAllowDataFeedFederation(Boolean allowDataFeedFederation) {
    this.allowDataFeedFederation = allowDataFeedFederation;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("enableMissionFederationDisruptionTolerance")
  public Boolean isEnableMissionFederationDisruptionTolerance() {
    return enableMissionFederationDisruptionTolerance;
  }
  public void setEnableMissionFederationDisruptionTolerance(Boolean enableMissionFederationDisruptionTolerance) {
    this.enableMissionFederationDisruptionTolerance = enableMissionFederationDisruptionTolerance;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("missionFederationDisruptionToleranceRecencySeconds")
  public Long getMissionFederationDisruptionToleranceRecencySeconds() {
    return missionFederationDisruptionToleranceRecencySeconds;
  }
  public void setMissionFederationDisruptionToleranceRecencySeconds(Long missionFederationDisruptionToleranceRecencySeconds) {
    this.missionFederationDisruptionToleranceRecencySeconds = missionFederationDisruptionToleranceRecencySeconds;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("federateOnlyPublicMissions")
  public Boolean isFederateOnlyPublicMissions() {
    return federateOnlyPublicMissions;
  }
  public void setFederateOnlyPublicMissions(Boolean federateOnlyPublicMissions) {
    this.federateOnlyPublicMissions = federateOnlyPublicMissions;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("enableFederation")
  public Boolean isEnableFederation() {
    return enableFederation;
  }
  public void setEnableFederation(Boolean enableFederation) {
    this.enableFederation = enableFederation;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("federatedGroupMapping")
  public Boolean isFederatedGroupMapping() {
    return federatedGroupMapping;
  }
  public void setFederatedGroupMapping(Boolean federatedGroupMapping) {
    this.federatedGroupMapping = federatedGroupMapping;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("automaticGroupMapping")
  public Boolean isAutomaticGroupMapping() {
    return automaticGroupMapping;
  }
  public void setAutomaticGroupMapping(Boolean automaticGroupMapping) {
    this.automaticGroupMapping = automaticGroupMapping;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("enableDataPackageAndMissionFileFilter")
  public Boolean isEnableDataPackageAndMissionFileFilter() {
    return enableDataPackageAndMissionFileFilter;
  }
  public void setEnableDataPackageAndMissionFileFilter(Boolean enableDataPackageAndMissionFileFilter) {
    this.enableDataPackageAndMissionFileFilter = enableDataPackageAndMissionFileFilter;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("ivoidMyWarrantyAndWantToForwardFederationTraffic")
  public Boolean isIvoidMyWarrantyAndWantToForwardFederationTraffic() {
    return ivoidMyWarrantyAndWantToForwardFederationTraffic;
  }
  public void setIvoidMyWarrantyAndWantToForwardFederationTraffic(Boolean ivoidMyWarrantyAndWantToForwardFederationTraffic) {
    this.ivoidMyWarrantyAndWantToForwardFederationTraffic = ivoidMyWarrantyAndWantToForwardFederationTraffic;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Federation federation = (Federation) o;
    return Objects.equals(federationServer, federation.federationServer) &&
        Objects.equals(federationOutgoing, federation.federationOutgoing) &&
        Objects.equals(missionDisruptionTolerance, federation.missionDisruptionTolerance) &&
        Objects.equals(federate, federation.federate) &&
        Objects.equals(fileFilter, federation.fileFilter) &&
        Objects.equals(federateCA, federation.federateCA) &&
        Objects.equals(allowDuplicate, federation.allowDuplicate) &&
        Objects.equals(allowFederatedDelete, federation.allowFederatedDelete) &&
        Objects.equals(allowMissionFederation, federation.allowMissionFederation) &&
        Objects.equals(allowDataFeedFederation, federation.allowDataFeedFederation) &&
        Objects.equals(enableMissionFederationDisruptionTolerance, federation.enableMissionFederationDisruptionTolerance) &&
        Objects.equals(missionFederationDisruptionToleranceRecencySeconds, federation.missionFederationDisruptionToleranceRecencySeconds) &&
        Objects.equals(federateOnlyPublicMissions, federation.federateOnlyPublicMissions) &&
        Objects.equals(enableFederation, federation.enableFederation) &&
        Objects.equals(federatedGroupMapping, federation.federatedGroupMapping) &&
        Objects.equals(automaticGroupMapping, federation.automaticGroupMapping) &&
        Objects.equals(enableDataPackageAndMissionFileFilter, federation.enableDataPackageAndMissionFileFilter) &&
        Objects.equals(ivoidMyWarrantyAndWantToForwardFederationTraffic, federation.ivoidMyWarrantyAndWantToForwardFederationTraffic);
  }

  @Override
  public int hashCode() {
    return Objects.hash(federationServer, federationOutgoing, missionDisruptionTolerance, federate, fileFilter, federateCA, allowDuplicate, allowFederatedDelete, allowMissionFederation, allowDataFeedFederation, enableMissionFederationDisruptionTolerance, missionFederationDisruptionToleranceRecencySeconds, federateOnlyPublicMissions, enableFederation, federatedGroupMapping, automaticGroupMapping, enableDataPackageAndMissionFileFilter, ivoidMyWarrantyAndWantToForwardFederationTraffic);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Federation {\n");
    
    sb.append("    federationServer: ").append(toIndentedString(federationServer)).append("\n");
    sb.append("    federationOutgoing: ").append(toIndentedString(federationOutgoing)).append("\n");
    sb.append("    missionDisruptionTolerance: ").append(toIndentedString(missionDisruptionTolerance)).append("\n");
    sb.append("    federate: ").append(toIndentedString(federate)).append("\n");
    sb.append("    fileFilter: ").append(toIndentedString(fileFilter)).append("\n");
    sb.append("    federateCA: ").append(toIndentedString(federateCA)).append("\n");
    sb.append("    allowDuplicate: ").append(toIndentedString(allowDuplicate)).append("\n");
    sb.append("    allowFederatedDelete: ").append(toIndentedString(allowFederatedDelete)).append("\n");
    sb.append("    allowMissionFederation: ").append(toIndentedString(allowMissionFederation)).append("\n");
    sb.append("    allowDataFeedFederation: ").append(toIndentedString(allowDataFeedFederation)).append("\n");
    sb.append("    enableMissionFederationDisruptionTolerance: ").append(toIndentedString(enableMissionFederationDisruptionTolerance)).append("\n");
    sb.append("    missionFederationDisruptionToleranceRecencySeconds: ").append(toIndentedString(missionFederationDisruptionToleranceRecencySeconds)).append("\n");
    sb.append("    federateOnlyPublicMissions: ").append(toIndentedString(federateOnlyPublicMissions)).append("\n");
    sb.append("    enableFederation: ").append(toIndentedString(enableFederation)).append("\n");
    sb.append("    federatedGroupMapping: ").append(toIndentedString(federatedGroupMapping)).append("\n");
    sb.append("    automaticGroupMapping: ").append(toIndentedString(automaticGroupMapping)).append("\n");
    sb.append("    enableDataPackageAndMissionFileFilter: ").append(toIndentedString(enableDataPackageAndMissionFileFilter)).append("\n");
    sb.append("    ivoidMyWarrantyAndWantToForwardFederationTraffic: ").append(toIndentedString(ivoidMyWarrantyAndWantToForwardFederationTraffic)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
