package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class Vbm   {
  private Boolean enabled = null;  private Boolean disableSASharing = null;  private Boolean disableChatSharing = null;  private Boolean returnCopsWithPublicMissions = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("enabled")
  public Boolean isEnabled() {
    return enabled;
  }
  public void setEnabled(Boolean enabled) {
    this.enabled = enabled;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("disableSASharing")
  public Boolean isDisableSASharing() {
    return disableSASharing;
  }
  public void setDisableSASharing(Boolean disableSASharing) {
    this.disableSASharing = disableSASharing;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("disableChatSharing")
  public Boolean isDisableChatSharing() {
    return disableChatSharing;
  }
  public void setDisableChatSharing(Boolean disableChatSharing) {
    this.disableChatSharing = disableChatSharing;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("returnCopsWithPublicMissions")
  public Boolean isReturnCopsWithPublicMissions() {
    return returnCopsWithPublicMissions;
  }
  public void setReturnCopsWithPublicMissions(Boolean returnCopsWithPublicMissions) {
    this.returnCopsWithPublicMissions = returnCopsWithPublicMissions;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Vbm vbm = (Vbm) o;
    return Objects.equals(enabled, vbm.enabled) &&
        Objects.equals(disableSASharing, vbm.disableSASharing) &&
        Objects.equals(disableChatSharing, vbm.disableChatSharing) &&
        Objects.equals(returnCopsWithPublicMissions, vbm.returnCopsWithPublicMissions);
  }

  @Override
  public int hashCode() {
    return Objects.hash(enabled, disableSASharing, disableChatSharing, returnCopsWithPublicMissions);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Vbm {\n");
    
    sb.append("    enabled: ").append(toIndentedString(enabled)).append("\n");
    sb.append("    disableSASharing: ").append(toIndentedString(disableSASharing)).append("\n");
    sb.append("    disableChatSharing: ").append(toIndentedString(disableChatSharing)).append("\n");
    sb.append("    returnCopsWithPublicMissions: ").append(toIndentedString(returnCopsWithPublicMissions)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
