package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import io.swagger.model.Filter;
import java.util.List;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class DataFeed   {
  private List<String> filtergroup = new ArrayList<String>();  private Filter filter = null;  /**
   * Gets or Sets auth
   */
  public enum AuthEnum {
    LDAP("LDAP"),
    FILE("FILE"),
    ANONYMOUS("ANONYMOUS"),
    X_509("X_509");
    private String value;

    AuthEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }
  }
  private AuthEnum auth = null;  private Boolean authRequired = null;  private String name = null;  private String protocol = null;  private Integer port = null;  private String group = null;  private String iface = null;  private Boolean archive = null;  private Boolean anongroup = null;  private Boolean archiveOnly = null;  private Integer coreVersion = null;  private Integer syncCacheRetentionSeconds = null;  private Integer maxMessageReadSizeBytes = null;  private String coreVersion2TlsVersions = null;  private Boolean federated = null;  private String uuid = null;  private String type = null;  private List<String> tag = new ArrayList<String>();  private Boolean sync = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("filtergroup")
  public List<String> getFiltergroup() {
    return filtergroup;
  }
  public void setFiltergroup(List<String> filtergroup) {
    this.filtergroup = filtergroup;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("filter")
  public Filter getFilter() {
    return filter;
  }
  public void setFilter(Filter filter) {
    this.filter = filter;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("auth")
  public AuthEnum getAuth() {
    return auth;
  }
  public void setAuth(AuthEnum auth) {
    this.auth = auth;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("authRequired")
  public Boolean isAuthRequired() {
    return authRequired;
  }
  public void setAuthRequired(Boolean authRequired) {
    this.authRequired = authRequired;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("name")
  public String getName() {
    return name;
  }
  public void setName(String name) {
    this.name = name;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("protocol")
  public String getProtocol() {
    return protocol;
  }
  public void setProtocol(String protocol) {
    this.protocol = protocol;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("port")
  public Integer getPort() {
    return port;
  }
  public void setPort(Integer port) {
    this.port = port;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("group")
  public String getGroup() {
    return group;
  }
  public void setGroup(String group) {
    this.group = group;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("iface")
  public String getIface() {
    return iface;
  }
  public void setIface(String iface) {
    this.iface = iface;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("archive")
  public Boolean isArchive() {
    return archive;
  }
  public void setArchive(Boolean archive) {
    this.archive = archive;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("anongroup")
  public Boolean isAnongroup() {
    return anongroup;
  }
  public void setAnongroup(Boolean anongroup) {
    this.anongroup = anongroup;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("archiveOnly")
  public Boolean isArchiveOnly() {
    return archiveOnly;
  }
  public void setArchiveOnly(Boolean archiveOnly) {
    this.archiveOnly = archiveOnly;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("coreVersion")
  public Integer getCoreVersion() {
    return coreVersion;
  }
  public void setCoreVersion(Integer coreVersion) {
    this.coreVersion = coreVersion;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("syncCacheRetentionSeconds")
  public Integer getSyncCacheRetentionSeconds() {
    return syncCacheRetentionSeconds;
  }
  public void setSyncCacheRetentionSeconds(Integer syncCacheRetentionSeconds) {
    this.syncCacheRetentionSeconds = syncCacheRetentionSeconds;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("maxMessageReadSizeBytes")
  public Integer getMaxMessageReadSizeBytes() {
    return maxMessageReadSizeBytes;
  }
  public void setMaxMessageReadSizeBytes(Integer maxMessageReadSizeBytes) {
    this.maxMessageReadSizeBytes = maxMessageReadSizeBytes;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("coreVersion2TlsVersions")
  public String getCoreVersion2TlsVersions() {
    return coreVersion2TlsVersions;
  }
  public void setCoreVersion2TlsVersions(String coreVersion2TlsVersions) {
    this.coreVersion2TlsVersions = coreVersion2TlsVersions;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("federated")
  public Boolean isFederated() {
    return federated;
  }
  public void setFederated(Boolean federated) {
    this.federated = federated;
  }

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("uuid")
  @NotNull
  public String getUuid() {
    return uuid;
  }
  public void setUuid(String uuid) {
    this.uuid = uuid;
  }

  /**
   **/
  
  @Schema(required = true, description = "")
  @JsonProperty("type")
  @NotNull
  public String getType() {
    return type;
  }
  public void setType(String type) {
    this.type = type;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("tag")
  public List<String> getTag() {
    return tag;
  }
  public void setTag(List<String> tag) {
    this.tag = tag;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("sync")
  public Boolean isSync() {
    return sync;
  }
  public void setSync(Boolean sync) {
    this.sync = sync;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    DataFeed dataFeed = (DataFeed) o;
    return Objects.equals(filtergroup, dataFeed.filtergroup) &&
        Objects.equals(filter, dataFeed.filter) &&
        Objects.equals(auth, dataFeed.auth) &&
        Objects.equals(authRequired, dataFeed.authRequired) &&
        Objects.equals(name, dataFeed.name) &&
        Objects.equals(protocol, dataFeed.protocol) &&
        Objects.equals(port, dataFeed.port) &&
        Objects.equals(group, dataFeed.group) &&
        Objects.equals(iface, dataFeed.iface) &&
        Objects.equals(archive, dataFeed.archive) &&
        Objects.equals(anongroup, dataFeed.anongroup) &&
        Objects.equals(archiveOnly, dataFeed.archiveOnly) &&
        Objects.equals(coreVersion, dataFeed.coreVersion) &&
        Objects.equals(syncCacheRetentionSeconds, dataFeed.syncCacheRetentionSeconds) &&
        Objects.equals(maxMessageReadSizeBytes, dataFeed.maxMessageReadSizeBytes) &&
        Objects.equals(coreVersion2TlsVersions, dataFeed.coreVersion2TlsVersions) &&
        Objects.equals(federated, dataFeed.federated) &&
        Objects.equals(uuid, dataFeed.uuid) &&
        Objects.equals(type, dataFeed.type) &&
        Objects.equals(tag, dataFeed.tag) &&
        Objects.equals(sync, dataFeed.sync);
  }

  @Override
  public int hashCode() {
    return Objects.hash(filtergroup, filter, auth, authRequired, name, protocol, port, group, iface, archive, anongroup, archiveOnly, coreVersion, syncCacheRetentionSeconds, maxMessageReadSizeBytes, coreVersion2TlsVersions, federated, uuid, type, tag, sync);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class DataFeed {\n");
    
    sb.append("    filtergroup: ").append(toIndentedString(filtergroup)).append("\n");
    sb.append("    filter: ").append(toIndentedString(filter)).append("\n");
    sb.append("    auth: ").append(toIndentedString(auth)).append("\n");
    sb.append("    authRequired: ").append(toIndentedString(authRequired)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    protocol: ").append(toIndentedString(protocol)).append("\n");
    sb.append("    port: ").append(toIndentedString(port)).append("\n");
    sb.append("    group: ").append(toIndentedString(group)).append("\n");
    sb.append("    iface: ").append(toIndentedString(iface)).append("\n");
    sb.append("    archive: ").append(toIndentedString(archive)).append("\n");
    sb.append("    anongroup: ").append(toIndentedString(anongroup)).append("\n");
    sb.append("    archiveOnly: ").append(toIndentedString(archiveOnly)).append("\n");
    sb.append("    coreVersion: ").append(toIndentedString(coreVersion)).append("\n");
    sb.append("    syncCacheRetentionSeconds: ").append(toIndentedString(syncCacheRetentionSeconds)).append("\n");
    sb.append("    maxMessageReadSizeBytes: ").append(toIndentedString(maxMessageReadSizeBytes)).append("\n");
    sb.append("    coreVersion2TlsVersions: ").append(toIndentedString(coreVersion2TlsVersions)).append("\n");
    sb.append("    federated: ").append(toIndentedString(federated)).append("\n");
    sb.append("    uuid: ").append(toIndentedString(uuid)).append("\n");
    sb.append("    type: ").append(toIndentedString(type)).append("\n");
    sb.append("    tag: ").append(toIndentedString(tag)).append("\n");
    sb.append("    sync: ").append(toIndentedString(sync)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
