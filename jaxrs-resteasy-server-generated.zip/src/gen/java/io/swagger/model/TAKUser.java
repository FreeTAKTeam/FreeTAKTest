package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class TAKUser   {
  private Long id = null;  private String userName = null;  private String emailAddress = null;  private String firstName = null;  private String lastName = null;  private String phoneNumber = null;  private String organization = null;  private String token = null;  private String state = null;  private String groupVector = null;  private Boolean activated = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("id")
  public Long getId() {
    return id;
  }
  public void setId(Long id) {
    this.id = id;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("userName")
  public String getUserName() {
    return userName;
  }
  public void setUserName(String userName) {
    this.userName = userName;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("emailAddress")
  public String getEmailAddress() {
    return emailAddress;
  }
  public void setEmailAddress(String emailAddress) {
    this.emailAddress = emailAddress;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("firstName")
  public String getFirstName() {
    return firstName;
  }
  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("lastName")
  public String getLastName() {
    return lastName;
  }
  public void setLastName(String lastName) {
    this.lastName = lastName;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("phoneNumber")
  public String getPhoneNumber() {
    return phoneNumber;
  }
  public void setPhoneNumber(String phoneNumber) {
    this.phoneNumber = phoneNumber;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("organization")
  public String getOrganization() {
    return organization;
  }
  public void setOrganization(String organization) {
    this.organization = organization;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("token")
  public String getToken() {
    return token;
  }
  public void setToken(String token) {
    this.token = token;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("state")
  public String getState() {
    return state;
  }
  public void setState(String state) {
    this.state = state;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("groupVector")
  public String getGroupVector() {
    return groupVector;
  }
  public void setGroupVector(String groupVector) {
    this.groupVector = groupVector;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("activated")
  public Boolean isActivated() {
    return activated;
  }
  public void setActivated(Boolean activated) {
    this.activated = activated;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    TAKUser taKUser = (TAKUser) o;
    return Objects.equals(id, taKUser.id) &&
        Objects.equals(userName, taKUser.userName) &&
        Objects.equals(emailAddress, taKUser.emailAddress) &&
        Objects.equals(firstName, taKUser.firstName) &&
        Objects.equals(lastName, taKUser.lastName) &&
        Objects.equals(phoneNumber, taKUser.phoneNumber) &&
        Objects.equals(organization, taKUser.organization) &&
        Objects.equals(token, taKUser.token) &&
        Objects.equals(state, taKUser.state) &&
        Objects.equals(groupVector, taKUser.groupVector) &&
        Objects.equals(activated, taKUser.activated);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, userName, emailAddress, firstName, lastName, phoneNumber, organization, token, state, groupVector, activated);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class TAKUser {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    userName: ").append(toIndentedString(userName)).append("\n");
    sb.append("    emailAddress: ").append(toIndentedString(emailAddress)).append("\n");
    sb.append("    firstName: ").append(toIndentedString(firstName)).append("\n");
    sb.append("    lastName: ").append(toIndentedString(lastName)).append("\n");
    sb.append("    phoneNumber: ").append(toIndentedString(phoneNumber)).append("\n");
    sb.append("    organization: ").append(toIndentedString(organization)).append("\n");
    sb.append("    token: ").append(toIndentedString(token)).append("\n");
    sb.append("    state: ").append(toIndentedString(state)).append("\n");
    sb.append("    groupVector: ").append(toIndentedString(groupVector)).append("\n");
    sb.append("    activated: ").append(toIndentedString(activated)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
