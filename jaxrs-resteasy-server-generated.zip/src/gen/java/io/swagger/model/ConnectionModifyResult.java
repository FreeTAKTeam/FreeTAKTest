package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class ConnectionModifyResult   {
  private String displayMessage = null;  private Integer httpStatusCode = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("displayMessage")
  public String getDisplayMessage() {
    return displayMessage;
  }
  public void setDisplayMessage(String displayMessage) {
    this.displayMessage = displayMessage;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("httpStatusCode")
  public Integer getHttpStatusCode() {
    return httpStatusCode;
  }
  public void setHttpStatusCode(Integer httpStatusCode) {
    this.httpStatusCode = httpStatusCode;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ConnectionModifyResult connectionModifyResult = (ConnectionModifyResult) o;
    return Objects.equals(displayMessage, connectionModifyResult.displayMessage) &&
        Objects.equals(httpStatusCode, connectionModifyResult.httpStatusCode);
  }

  @Override
  public int hashCode() {
    return Objects.hash(displayMessage, httpStatusCode);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ConnectionModifyResult {\n");
    
    sb.append("    displayMessage: ").append(toIndentedString(displayMessage)).append("\n");
    sb.append("    httpStatusCode: ").append(toIndentedString(httpStatusCode)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
