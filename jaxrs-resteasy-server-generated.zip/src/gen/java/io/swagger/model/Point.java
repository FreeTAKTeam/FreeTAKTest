package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.Coordinate;
import io.swagger.model.CoordinateSequence;
import io.swagger.model.Envelope;
import io.swagger.model.Geometry;
import io.swagger.model.GeometryFactory;
import io.swagger.model.Point;
import io.swagger.model.PrecisionModel;
import java.util.List;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class Point   {
  private Geometry envelope = null;  private GeometryFactory factory = null;  private Object userData = null;  private List<Coordinate> coordinates = new ArrayList<Coordinate>();  private Boolean empty = null;  private Integer dimension = null;  private String geometryType = null;  private Coordinate coordinate = null;  private Integer numPoints = null;  private Boolean simple = null;  private Geometry boundary = null;  private Integer boundaryDimension = null;  private CoordinateSequence coordinateSequence = null;  private Double x = null;  private Double y = null;  private Double length = null;  private Boolean valid = null;  private Integer srid = null;  private Integer numGeometries = null;  private PrecisionModel precisionModel = null;  private Boolean rectangle = null;  private Double area = null;  private Point centroid = null;  private Point interiorPoint = null;  private Envelope envelopeInternal = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("envelope")
  public Geometry getEnvelope() {
    return envelope;
  }
  public void setEnvelope(Geometry envelope) {
    this.envelope = envelope;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("factory")
  public GeometryFactory getFactory() {
    return factory;
  }
  public void setFactory(GeometryFactory factory) {
    this.factory = factory;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("userData")
  public Object getUserData() {
    return userData;
  }
  public void setUserData(Object userData) {
    this.userData = userData;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("coordinates")
  public List<Coordinate> getCoordinates() {
    return coordinates;
  }
  public void setCoordinates(List<Coordinate> coordinates) {
    this.coordinates = coordinates;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("empty")
  public Boolean isEmpty() {
    return empty;
  }
  public void setEmpty(Boolean empty) {
    this.empty = empty;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("dimension")
  public Integer getDimension() {
    return dimension;
  }
  public void setDimension(Integer dimension) {
    this.dimension = dimension;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("geometryType")
  public String getGeometryType() {
    return geometryType;
  }
  public void setGeometryType(String geometryType) {
    this.geometryType = geometryType;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("coordinate")
  public Coordinate getCoordinate() {
    return coordinate;
  }
  public void setCoordinate(Coordinate coordinate) {
    this.coordinate = coordinate;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("numPoints")
  public Integer getNumPoints() {
    return numPoints;
  }
  public void setNumPoints(Integer numPoints) {
    this.numPoints = numPoints;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("simple")
  public Boolean isSimple() {
    return simple;
  }
  public void setSimple(Boolean simple) {
    this.simple = simple;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("boundary")
  public Geometry getBoundary() {
    return boundary;
  }
  public void setBoundary(Geometry boundary) {
    this.boundary = boundary;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("boundaryDimension")
  public Integer getBoundaryDimension() {
    return boundaryDimension;
  }
  public void setBoundaryDimension(Integer boundaryDimension) {
    this.boundaryDimension = boundaryDimension;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("coordinateSequence")
  public CoordinateSequence getCoordinateSequence() {
    return coordinateSequence;
  }
  public void setCoordinateSequence(CoordinateSequence coordinateSequence) {
    this.coordinateSequence = coordinateSequence;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("x")
  public Double getX() {
    return x;
  }
  public void setX(Double x) {
    this.x = x;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("y")
  public Double getY() {
    return y;
  }
  public void setY(Double y) {
    this.y = y;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("length")
  public Double getLength() {
    return length;
  }
  public void setLength(Double length) {
    this.length = length;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("valid")
  public Boolean isValid() {
    return valid;
  }
  public void setValid(Boolean valid) {
    this.valid = valid;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("srid")
  public Integer getSrid() {
    return srid;
  }
  public void setSrid(Integer srid) {
    this.srid = srid;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("numGeometries")
  public Integer getNumGeometries() {
    return numGeometries;
  }
  public void setNumGeometries(Integer numGeometries) {
    this.numGeometries = numGeometries;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("precisionModel")
  public PrecisionModel getPrecisionModel() {
    return precisionModel;
  }
  public void setPrecisionModel(PrecisionModel precisionModel) {
    this.precisionModel = precisionModel;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("rectangle")
  public Boolean isRectangle() {
    return rectangle;
  }
  public void setRectangle(Boolean rectangle) {
    this.rectangle = rectangle;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("area")
  public Double getArea() {
    return area;
  }
  public void setArea(Double area) {
    this.area = area;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("centroid")
  public Point getCentroid() {
    return centroid;
  }
  public void setCentroid(Point centroid) {
    this.centroid = centroid;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("interiorPoint")
  public Point getInteriorPoint() {
    return interiorPoint;
  }
  public void setInteriorPoint(Point interiorPoint) {
    this.interiorPoint = interiorPoint;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("envelopeInternal")
  public Envelope getEnvelopeInternal() {
    return envelopeInternal;
  }
  public void setEnvelopeInternal(Envelope envelopeInternal) {
    this.envelopeInternal = envelopeInternal;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Point point = (Point) o;
    return Objects.equals(envelope, point.envelope) &&
        Objects.equals(factory, point.factory) &&
        Objects.equals(userData, point.userData) &&
        Objects.equals(coordinates, point.coordinates) &&
        Objects.equals(empty, point.empty) &&
        Objects.equals(dimension, point.dimension) &&
        Objects.equals(geometryType, point.geometryType) &&
        Objects.equals(coordinate, point.coordinate) &&
        Objects.equals(numPoints, point.numPoints) &&
        Objects.equals(simple, point.simple) &&
        Objects.equals(boundary, point.boundary) &&
        Objects.equals(boundaryDimension, point.boundaryDimension) &&
        Objects.equals(coordinateSequence, point.coordinateSequence) &&
        Objects.equals(x, point.x) &&
        Objects.equals(y, point.y) &&
        Objects.equals(length, point.length) &&
        Objects.equals(valid, point.valid) &&
        Objects.equals(srid, point.srid) &&
        Objects.equals(numGeometries, point.numGeometries) &&
        Objects.equals(precisionModel, point.precisionModel) &&
        Objects.equals(rectangle, point.rectangle) &&
        Objects.equals(area, point.area) &&
        Objects.equals(centroid, point.centroid) &&
        Objects.equals(interiorPoint, point.interiorPoint) &&
        Objects.equals(envelopeInternal, point.envelopeInternal);
  }

  @Override
  public int hashCode() {
    return Objects.hash(envelope, factory, userData, coordinates, empty, dimension, geometryType, coordinate, numPoints, simple, boundary, boundaryDimension, coordinateSequence, x, y, length, valid, srid, numGeometries, precisionModel, rectangle, area, centroid, interiorPoint, envelopeInternal);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Point {\n");
    
    sb.append("    envelope: ").append(toIndentedString(envelope)).append("\n");
    sb.append("    factory: ").append(toIndentedString(factory)).append("\n");
    sb.append("    userData: ").append(toIndentedString(userData)).append("\n");
    sb.append("    coordinates: ").append(toIndentedString(coordinates)).append("\n");
    sb.append("    empty: ").append(toIndentedString(empty)).append("\n");
    sb.append("    dimension: ").append(toIndentedString(dimension)).append("\n");
    sb.append("    geometryType: ").append(toIndentedString(geometryType)).append("\n");
    sb.append("    coordinate: ").append(toIndentedString(coordinate)).append("\n");
    sb.append("    numPoints: ").append(toIndentedString(numPoints)).append("\n");
    sb.append("    simple: ").append(toIndentedString(simple)).append("\n");
    sb.append("    boundary: ").append(toIndentedString(boundary)).append("\n");
    sb.append("    boundaryDimension: ").append(toIndentedString(boundaryDimension)).append("\n");
    sb.append("    coordinateSequence: ").append(toIndentedString(coordinateSequence)).append("\n");
    sb.append("    x: ").append(toIndentedString(x)).append("\n");
    sb.append("    y: ").append(toIndentedString(y)).append("\n");
    sb.append("    length: ").append(toIndentedString(length)).append("\n");
    sb.append("    valid: ").append(toIndentedString(valid)).append("\n");
    sb.append("    srid: ").append(toIndentedString(srid)).append("\n");
    sb.append("    numGeometries: ").append(toIndentedString(numGeometries)).append("\n");
    sb.append("    precisionModel: ").append(toIndentedString(precisionModel)).append("\n");
    sb.append("    rectangle: ").append(toIndentedString(rectangle)).append("\n");
    sb.append("    area: ").append(toIndentedString(area)).append("\n");
    sb.append("    centroid: ").append(toIndentedString(centroid)).append("\n");
    sb.append("    interiorPoint: ").append(toIndentedString(interiorPoint)).append("\n");
    sb.append("    envelopeInternal: ").append(toIndentedString(envelopeInternal)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
