package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.ExternalMissionData;
import io.swagger.model.LogEntry;
import io.swagger.model.MapLayer;
import io.swagger.model.MissionAddResource;
import io.swagger.model.MissionAddString;
import io.swagger.model.MissionChange;
import io.swagger.model.MissionFeed;
import io.swagger.model.MissionRole;
import java.util.Date;
import java.util.List;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class Mission   {
  private String name = null;  private String description = null;  private String chatRoom = null;  private String baseLayer = null;  private String bbox = null;  private String boundingPolygon = null;  private String path = null;  private String classification = null;  private String tool = null;  private List<String> keywords = new ArrayList<String>();  private String creatorUid = null;  private Date createTime = null;  private Date lastEdited = null;  private List<String> groups = new ArrayList<String>();  private List<ExternalMissionData> externalData = new ArrayList<ExternalMissionData>();  private List<MissionFeed> feeds = new ArrayList<MissionFeed>();  private List<MapLayer> mapLayers = new ArrayList<MapLayer>();  private MissionRole defaultRole = null;  private MissionRole ownerRole = null;  private Boolean inviteOnly = null;  private List<MissionChange> missionChanges = new ArrayList<MissionChange>();  private List<LogEntry> logs = new ArrayList<LogEntry>();  private Long expiration = null;  private List<MissionAddString> uids = new ArrayList<MissionAddString>();  private List<MissionAddResource> contents = new ArrayList<MissionAddResource>();  private String token = null;  private Boolean passwordProtected = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("name")
  public String getName() {
    return name;
  }
  public void setName(String name) {
    this.name = name;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("description")
  public String getDescription() {
    return description;
  }
  public void setDescription(String description) {
    this.description = description;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("chatRoom")
  public String getChatRoom() {
    return chatRoom;
  }
  public void setChatRoom(String chatRoom) {
    this.chatRoom = chatRoom;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("baseLayer")
  public String getBaseLayer() {
    return baseLayer;
  }
  public void setBaseLayer(String baseLayer) {
    this.baseLayer = baseLayer;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("bbox")
  public String getBbox() {
    return bbox;
  }
  public void setBbox(String bbox) {
    this.bbox = bbox;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("boundingPolygon")
  public String getBoundingPolygon() {
    return boundingPolygon;
  }
  public void setBoundingPolygon(String boundingPolygon) {
    this.boundingPolygon = boundingPolygon;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("path")
  public String getPath() {
    return path;
  }
  public void setPath(String path) {
    this.path = path;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("classification")
  public String getClassification() {
    return classification;
  }
  public void setClassification(String classification) {
    this.classification = classification;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("tool")
  public String getTool() {
    return tool;
  }
  public void setTool(String tool) {
    this.tool = tool;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("keywords")
  public List<String> getKeywords() {
    return keywords;
  }
  public void setKeywords(List<String> keywords) {
    this.keywords = keywords;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("creatorUid")
  public String getCreatorUid() {
    return creatorUid;
  }
  public void setCreatorUid(String creatorUid) {
    this.creatorUid = creatorUid;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("createTime")
  public Date getCreateTime() {
    return createTime;
  }
  public void setCreateTime(Date createTime) {
    this.createTime = createTime;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("lastEdited")
  public Date getLastEdited() {
    return lastEdited;
  }
  public void setLastEdited(Date lastEdited) {
    this.lastEdited = lastEdited;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("groups")
  public List<String> getGroups() {
    return groups;
  }
  public void setGroups(List<String> groups) {
    this.groups = groups;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("externalData")
  public List<ExternalMissionData> getExternalData() {
    return externalData;
  }
  public void setExternalData(List<ExternalMissionData> externalData) {
    this.externalData = externalData;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("feeds")
  public List<MissionFeed> getFeeds() {
    return feeds;
  }
  public void setFeeds(List<MissionFeed> feeds) {
    this.feeds = feeds;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("mapLayers")
  public List<MapLayer> getMapLayers() {
    return mapLayers;
  }
  public void setMapLayers(List<MapLayer> mapLayers) {
    this.mapLayers = mapLayers;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("defaultRole")
  public MissionRole getDefaultRole() {
    return defaultRole;
  }
  public void setDefaultRole(MissionRole defaultRole) {
    this.defaultRole = defaultRole;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("ownerRole")
  public MissionRole getOwnerRole() {
    return ownerRole;
  }
  public void setOwnerRole(MissionRole ownerRole) {
    this.ownerRole = ownerRole;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("inviteOnly")
  public Boolean isInviteOnly() {
    return inviteOnly;
  }
  public void setInviteOnly(Boolean inviteOnly) {
    this.inviteOnly = inviteOnly;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("missionChanges")
  public List<MissionChange> getMissionChanges() {
    return missionChanges;
  }
  public void setMissionChanges(List<MissionChange> missionChanges) {
    this.missionChanges = missionChanges;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("logs")
  public List<LogEntry> getLogs() {
    return logs;
  }
  public void setLogs(List<LogEntry> logs) {
    this.logs = logs;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("expiration")
  public Long getExpiration() {
    return expiration;
  }
  public void setExpiration(Long expiration) {
    this.expiration = expiration;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("uids")
  public List<MissionAddString> getUids() {
    return uids;
  }
  public void setUids(List<MissionAddString> uids) {
    this.uids = uids;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("contents")
  public List<MissionAddResource> getContents() {
    return contents;
  }
  public void setContents(List<MissionAddResource> contents) {
    this.contents = contents;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("token")
  public String getToken() {
    return token;
  }
  public void setToken(String token) {
    this.token = token;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("passwordProtected")
  public Boolean isPasswordProtected() {
    return passwordProtected;
  }
  public void setPasswordProtected(Boolean passwordProtected) {
    this.passwordProtected = passwordProtected;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Mission mission = (Mission) o;
    return Objects.equals(name, mission.name) &&
        Objects.equals(description, mission.description) &&
        Objects.equals(chatRoom, mission.chatRoom) &&
        Objects.equals(baseLayer, mission.baseLayer) &&
        Objects.equals(bbox, mission.bbox) &&
        Objects.equals(boundingPolygon, mission.boundingPolygon) &&
        Objects.equals(path, mission.path) &&
        Objects.equals(classification, mission.classification) &&
        Objects.equals(tool, mission.tool) &&
        Objects.equals(keywords, mission.keywords) &&
        Objects.equals(creatorUid, mission.creatorUid) &&
        Objects.equals(createTime, mission.createTime) &&
        Objects.equals(lastEdited, mission.lastEdited) &&
        Objects.equals(groups, mission.groups) &&
        Objects.equals(externalData, mission.externalData) &&
        Objects.equals(feeds, mission.feeds) &&
        Objects.equals(mapLayers, mission.mapLayers) &&
        Objects.equals(defaultRole, mission.defaultRole) &&
        Objects.equals(ownerRole, mission.ownerRole) &&
        Objects.equals(inviteOnly, mission.inviteOnly) &&
        Objects.equals(missionChanges, mission.missionChanges) &&
        Objects.equals(logs, mission.logs) &&
        Objects.equals(expiration, mission.expiration) &&
        Objects.equals(uids, mission.uids) &&
        Objects.equals(contents, mission.contents) &&
        Objects.equals(token, mission.token) &&
        Objects.equals(passwordProtected, mission.passwordProtected);
  }

  @Override
  public int hashCode() {
    return Objects.hash(name, description, chatRoom, baseLayer, bbox, boundingPolygon, path, classification, tool, keywords, creatorUid, createTime, lastEdited, groups, externalData, feeds, mapLayers, defaultRole, ownerRole, inviteOnly, missionChanges, logs, expiration, uids, contents, token, passwordProtected);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Mission {\n");
    
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    description: ").append(toIndentedString(description)).append("\n");
    sb.append("    chatRoom: ").append(toIndentedString(chatRoom)).append("\n");
    sb.append("    baseLayer: ").append(toIndentedString(baseLayer)).append("\n");
    sb.append("    bbox: ").append(toIndentedString(bbox)).append("\n");
    sb.append("    boundingPolygon: ").append(toIndentedString(boundingPolygon)).append("\n");
    sb.append("    path: ").append(toIndentedString(path)).append("\n");
    sb.append("    classification: ").append(toIndentedString(classification)).append("\n");
    sb.append("    tool: ").append(toIndentedString(tool)).append("\n");
    sb.append("    keywords: ").append(toIndentedString(keywords)).append("\n");
    sb.append("    creatorUid: ").append(toIndentedString(creatorUid)).append("\n");
    sb.append("    createTime: ").append(toIndentedString(createTime)).append("\n");
    sb.append("    lastEdited: ").append(toIndentedString(lastEdited)).append("\n");
    sb.append("    groups: ").append(toIndentedString(groups)).append("\n");
    sb.append("    externalData: ").append(toIndentedString(externalData)).append("\n");
    sb.append("    feeds: ").append(toIndentedString(feeds)).append("\n");
    sb.append("    mapLayers: ").append(toIndentedString(mapLayers)).append("\n");
    sb.append("    defaultRole: ").append(toIndentedString(defaultRole)).append("\n");
    sb.append("    ownerRole: ").append(toIndentedString(ownerRole)).append("\n");
    sb.append("    inviteOnly: ").append(toIndentedString(inviteOnly)).append("\n");
    sb.append("    missionChanges: ").append(toIndentedString(missionChanges)).append("\n");
    sb.append("    logs: ").append(toIndentedString(logs)).append("\n");
    sb.append("    expiration: ").append(toIndentedString(expiration)).append("\n");
    sb.append("    uids: ").append(toIndentedString(uids)).append("\n");
    sb.append("    contents: ").append(toIndentedString(contents)).append("\n");
    sb.append("    token: ").append(toIndentedString(token)).append("\n");
    sb.append("    passwordProtected: ").append(toIndentedString(passwordProtected)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
