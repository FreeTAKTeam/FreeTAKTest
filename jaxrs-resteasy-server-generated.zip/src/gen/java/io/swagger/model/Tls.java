package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.Crl;
import java.util.List;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class Tls   {
  private List<Crl> crl = new ArrayList<Crl>();  private String keystore = null;  private String keystoreFile = null;  private String keystorePass = null;  private String truststore = null;  private String truststoreFile = null;  private String truststorePass = null;  private String context = null;  private String keymanager = null;  private Boolean allow128Cipher = null;  private Boolean allowNonSuiteB = null;  private Boolean enableOCSP = null;  private String responderUrl = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("crl")
  public List<Crl> getCrl() {
    return crl;
  }
  public void setCrl(List<Crl> crl) {
    this.crl = crl;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("keystore")
  public String getKeystore() {
    return keystore;
  }
  public void setKeystore(String keystore) {
    this.keystore = keystore;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("keystoreFile")
  public String getKeystoreFile() {
    return keystoreFile;
  }
  public void setKeystoreFile(String keystoreFile) {
    this.keystoreFile = keystoreFile;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("keystorePass")
  public String getKeystorePass() {
    return keystorePass;
  }
  public void setKeystorePass(String keystorePass) {
    this.keystorePass = keystorePass;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("truststore")
  public String getTruststore() {
    return truststore;
  }
  public void setTruststore(String truststore) {
    this.truststore = truststore;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("truststoreFile")
  public String getTruststoreFile() {
    return truststoreFile;
  }
  public void setTruststoreFile(String truststoreFile) {
    this.truststoreFile = truststoreFile;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("truststorePass")
  public String getTruststorePass() {
    return truststorePass;
  }
  public void setTruststorePass(String truststorePass) {
    this.truststorePass = truststorePass;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("context")
  public String getContext() {
    return context;
  }
  public void setContext(String context) {
    this.context = context;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("keymanager")
  public String getKeymanager() {
    return keymanager;
  }
  public void setKeymanager(String keymanager) {
    this.keymanager = keymanager;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("allow128Cipher")
  public Boolean isAllow128Cipher() {
    return allow128Cipher;
  }
  public void setAllow128Cipher(Boolean allow128Cipher) {
    this.allow128Cipher = allow128Cipher;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("allowNonSuiteB")
  public Boolean isAllowNonSuiteB() {
    return allowNonSuiteB;
  }
  public void setAllowNonSuiteB(Boolean allowNonSuiteB) {
    this.allowNonSuiteB = allowNonSuiteB;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("enableOCSP")
  public Boolean isEnableOCSP() {
    return enableOCSP;
  }
  public void setEnableOCSP(Boolean enableOCSP) {
    this.enableOCSP = enableOCSP;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("responderUrl")
  public String getResponderUrl() {
    return responderUrl;
  }
  public void setResponderUrl(String responderUrl) {
    this.responderUrl = responderUrl;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Tls tls = (Tls) o;
    return Objects.equals(crl, tls.crl) &&
        Objects.equals(keystore, tls.keystore) &&
        Objects.equals(keystoreFile, tls.keystoreFile) &&
        Objects.equals(keystorePass, tls.keystorePass) &&
        Objects.equals(truststore, tls.truststore) &&
        Objects.equals(truststoreFile, tls.truststoreFile) &&
        Objects.equals(truststorePass, tls.truststorePass) &&
        Objects.equals(context, tls.context) &&
        Objects.equals(keymanager, tls.keymanager) &&
        Objects.equals(allow128Cipher, tls.allow128Cipher) &&
        Objects.equals(allowNonSuiteB, tls.allowNonSuiteB) &&
        Objects.equals(enableOCSP, tls.enableOCSP) &&
        Objects.equals(responderUrl, tls.responderUrl);
  }

  @Override
  public int hashCode() {
    return Objects.hash(crl, keystore, keystoreFile, keystorePass, truststore, truststoreFile, truststorePass, context, keymanager, allow128Cipher, allowNonSuiteB, enableOCSP, responderUrl);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Tls {\n");
    
    sb.append("    crl: ").append(toIndentedString(crl)).append("\n");
    sb.append("    keystore: ").append(toIndentedString(keystore)).append("\n");
    sb.append("    keystoreFile: ").append(toIndentedString(keystoreFile)).append("\n");
    sb.append("    keystorePass: ").append(toIndentedString(keystorePass)).append("\n");
    sb.append("    truststore: ").append(toIndentedString(truststore)).append("\n");
    sb.append("    truststoreFile: ").append(toIndentedString(truststoreFile)).append("\n");
    sb.append("    truststorePass: ").append(toIndentedString(truststorePass)).append("\n");
    sb.append("    context: ").append(toIndentedString(context)).append("\n");
    sb.append("    keymanager: ").append(toIndentedString(keymanager)).append("\n");
    sb.append("    allow128Cipher: ").append(toIndentedString(allow128Cipher)).append("\n");
    sb.append("    allowNonSuiteB: ").append(toIndentedString(allowNonSuiteB)).append("\n");
    sb.append("    enableOCSP: ").append(toIndentedString(enableOCSP)).append("\n");
    sb.append("    responderUrl: ").append(toIndentedString(responderUrl)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
