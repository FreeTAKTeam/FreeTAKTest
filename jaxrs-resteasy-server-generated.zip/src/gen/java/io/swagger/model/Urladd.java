package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class Urladd   {
  private Boolean thumburl = null;  private Boolean fullurl = null;  private String script = null;  private String vidscript = null;  private String host = null;  private Boolean overwriteurl = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("thumburl")
  public Boolean isThumburl() {
    return thumburl;
  }
  public void setThumburl(Boolean thumburl) {
    this.thumburl = thumburl;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("fullurl")
  public Boolean isFullurl() {
    return fullurl;
  }
  public void setFullurl(Boolean fullurl) {
    this.fullurl = fullurl;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("script")
  public String getScript() {
    return script;
  }
  public void setScript(String script) {
    this.script = script;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("vidscript")
  public String getVidscript() {
    return vidscript;
  }
  public void setVidscript(String vidscript) {
    this.vidscript = vidscript;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("host")
  public String getHost() {
    return host;
  }
  public void setHost(String host) {
    this.host = host;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("overwriteurl")
  public Boolean isOverwriteurl() {
    return overwriteurl;
  }
  public void setOverwriteurl(Boolean overwriteurl) {
    this.overwriteurl = overwriteurl;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Urladd urladd = (Urladd) o;
    return Objects.equals(thumburl, urladd.thumburl) &&
        Objects.equals(fullurl, urladd.fullurl) &&
        Objects.equals(script, urladd.script) &&
        Objects.equals(vidscript, urladd.vidscript) &&
        Objects.equals(host, urladd.host) &&
        Objects.equals(overwriteurl, urladd.overwriteurl);
  }

  @Override
  public int hashCode() {
    return Objects.hash(thumburl, fullurl, script, vidscript, host, overwriteurl);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Urladd {\n");
    
    sb.append("    thumburl: ").append(toIndentedString(thumburl)).append("\n");
    sb.append("    fullurl: ").append(toIndentedString(fullurl)).append("\n");
    sb.append("    script: ").append(toIndentedString(script)).append("\n");
    sb.append("    vidscript: ").append(toIndentedString(vidscript)).append("\n");
    sb.append("    host: ").append(toIndentedString(host)).append("\n");
    sb.append("    overwriteurl: ").append(toIndentedString(overwriteurl)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
