package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.Mission;
import java.util.List;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class Federate   {
  private List<String> inboundGroupMapping = new ArrayList<String>();  private List<String> inboundGroup = new ArrayList<String>();  private List<String> outboundGroup = new ArrayList<String>();  private Boolean missionFederateDefault = true;  private List<Mission> mission = new ArrayList<Mission>();  private String id = null;  private String name = null;  private String notes = null;  private Boolean shareAlerts = null;  private Boolean archive = null;  private Boolean federatedGroupMapping = null;  private Boolean automaticGroupMapping = null;

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("inboundGroupMapping")
  public List<String> getInboundGroupMapping() {
    return inboundGroupMapping;
  }
  public void setInboundGroupMapping(List<String> inboundGroupMapping) {
    this.inboundGroupMapping = inboundGroupMapping;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("inboundGroup")
  public List<String> getInboundGroup() {
    return inboundGroup;
  }
  public void setInboundGroup(List<String> inboundGroup) {
    this.inboundGroup = inboundGroup;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("outboundGroup")
  public List<String> getOutboundGroup() {
    return outboundGroup;
  }
  public void setOutboundGroup(List<String> outboundGroup) {
    this.outboundGroup = outboundGroup;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("missionFederateDefault")
  public Boolean isMissionFederateDefault() {
    return missionFederateDefault;
  }
  public void setMissionFederateDefault(Boolean missionFederateDefault) {
    this.missionFederateDefault = missionFederateDefault;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("mission")
  public List<Mission> getMission() {
    return mission;
  }
  public void setMission(List<Mission> mission) {
    this.mission = mission;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("id")
  public String getId() {
    return id;
  }
  public void setId(String id) {
    this.id = id;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("name")
  public String getName() {
    return name;
  }
  public void setName(String name) {
    this.name = name;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("notes")
  public String getNotes() {
    return notes;
  }
  public void setNotes(String notes) {
    this.notes = notes;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("shareAlerts")
  public Boolean isShareAlerts() {
    return shareAlerts;
  }
  public void setShareAlerts(Boolean shareAlerts) {
    this.shareAlerts = shareAlerts;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("archive")
  public Boolean isArchive() {
    return archive;
  }
  public void setArchive(Boolean archive) {
    this.archive = archive;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("federatedGroupMapping")
  public Boolean isFederatedGroupMapping() {
    return federatedGroupMapping;
  }
  public void setFederatedGroupMapping(Boolean federatedGroupMapping) {
    this.federatedGroupMapping = federatedGroupMapping;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("automaticGroupMapping")
  public Boolean isAutomaticGroupMapping() {
    return automaticGroupMapping;
  }
  public void setAutomaticGroupMapping(Boolean automaticGroupMapping) {
    this.automaticGroupMapping = automaticGroupMapping;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Federate federate = (Federate) o;
    return Objects.equals(inboundGroupMapping, federate.inboundGroupMapping) &&
        Objects.equals(inboundGroup, federate.inboundGroup) &&
        Objects.equals(outboundGroup, federate.outboundGroup) &&
        Objects.equals(missionFederateDefault, federate.missionFederateDefault) &&
        Objects.equals(mission, federate.mission) &&
        Objects.equals(id, federate.id) &&
        Objects.equals(name, federate.name) &&
        Objects.equals(notes, federate.notes) &&
        Objects.equals(shareAlerts, federate.shareAlerts) &&
        Objects.equals(archive, federate.archive) &&
        Objects.equals(federatedGroupMapping, federate.federatedGroupMapping) &&
        Objects.equals(automaticGroupMapping, federate.automaticGroupMapping);
  }

  @Override
  public int hashCode() {
    return Objects.hash(inboundGroupMapping, inboundGroup, outboundGroup, missionFederateDefault, mission, id, name, notes, shareAlerts, archive, federatedGroupMapping, automaticGroupMapping);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Federate {\n");
    
    sb.append("    inboundGroupMapping: ").append(toIndentedString(inboundGroupMapping)).append("\n");
    sb.append("    inboundGroup: ").append(toIndentedString(inboundGroup)).append("\n");
    sb.append("    outboundGroup: ").append(toIndentedString(outboundGroup)).append("\n");
    sb.append("    missionFederateDefault: ").append(toIndentedString(missionFederateDefault)).append("\n");
    sb.append("    mission: ").append(toIndentedString(mission)).append("\n");
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    notes: ").append(toIndentedString(notes)).append("\n");
    sb.append("    shareAlerts: ").append(toIndentedString(shareAlerts)).append("\n");
    sb.append("    archive: ").append(toIndentedString(archive)).append("\n");
    sb.append("    federatedGroupMapping: ").append(toIndentedString(federatedGroupMapping)).append("\n");
    sb.append("    automaticGroupMapping: ").append(toIndentedString(automaticGroupMapping)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
