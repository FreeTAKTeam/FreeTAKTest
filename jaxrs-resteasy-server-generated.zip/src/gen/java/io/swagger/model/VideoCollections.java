package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.VideoConnection;
import java.util.List;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class VideoCollections   {
  private List<VideoConnection> videoConnections = new ArrayList<VideoConnection>();

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("videoConnections")
  public List<VideoConnection> getVideoConnections() {
    return videoConnections;
  }
  public void setVideoConnections(List<VideoConnection> videoConnections) {
    this.videoConnections = videoConnections;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    VideoCollections videoCollections = (VideoCollections) o;
    return Objects.equals(videoConnections, videoCollections.videoConnections);
  }

  @Override
  public int hashCode() {
    return Objects.hash(videoConnections);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class VideoCollections {\n");
    
    sb.append("    videoConnections: ").append(toIndentedString(videoConnections)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
