package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import java.util.Date;
import java.util.List;
import javax.validation.constraints.*;
import io.swagger.v3.oas.annotations.media.Schema;


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class MissionAddString   {
  private String data = null;  private Date timestamp = null;  private String creatorUid = null;  private List<String> keywords = new ArrayList<String>();

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("data")
  public String getData() {
    return data;
  }
  public void setData(String data) {
    this.data = data;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("timestamp")
  public Date getTimestamp() {
    return timestamp;
  }
  public void setTimestamp(Date timestamp) {
    this.timestamp = timestamp;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("creatorUid")
  public String getCreatorUid() {
    return creatorUid;
  }
  public void setCreatorUid(String creatorUid) {
    this.creatorUid = creatorUid;
  }

  /**
   **/
  
  @Schema(description = "")
  @JsonProperty("keywords")
  public List<String> getKeywords() {
    return keywords;
  }
  public void setKeywords(List<String> keywords) {
    this.keywords = keywords;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    MissionAddString missionAddString = (MissionAddString) o;
    return Objects.equals(data, missionAddString.data) &&
        Objects.equals(timestamp, missionAddString.timestamp) &&
        Objects.equals(creatorUid, missionAddString.creatorUid) &&
        Objects.equals(keywords, missionAddString.keywords);
  }

  @Override
  public int hashCode() {
    return Objects.hash(data, timestamp, creatorUid, keywords);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class MissionAddString {\n");
    
    sb.append("    data: ").append(toIndentedString(data)).append("\n");
    sb.append("    timestamp: ").append(toIndentedString(timestamp)).append("\n");
    sb.append("    creatorUid: ").append(toIndentedString(creatorUid)).append("\n");
    sb.append("    keywords: ").append(toIndentedString(keywords)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}
