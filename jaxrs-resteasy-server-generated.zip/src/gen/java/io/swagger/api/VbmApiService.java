package io.swagger.api;

import io.swagger.api.*;
import io.swagger.model.*;

import io.swagger.model.VBMConfigurationModel;

import java.util.List;
import io.swagger.api.NotFoundException;

import java.io.InputStream;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;

@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public interface VbmApiService {
      Response getVBMConfiguration(SecurityContext securityContext)
      throws NotFoundException;
      Response setVBMConfiguration(VBMConfigurationModel body,SecurityContext securityContext)
      throws NotFoundException;
}
