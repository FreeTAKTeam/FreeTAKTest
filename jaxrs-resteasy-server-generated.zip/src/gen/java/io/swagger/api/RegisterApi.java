package io.swagger.api;

import io.swagger.model.*;
import io.swagger.api.RegisterApiService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;

import io.swagger.model.TAKUser;

import java.util.Map;
import java.util.List;
import io.swagger.api.NotFoundException;

import java.io.InputStream;

import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import javax.ws.rs.*;
import javax.inject.Inject;

import javax.validation.constraints.*;
@Path("/register")


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class RegisterApi  {

    @Inject RegisterApiService service;

    @GET
    @Path("/token/{token}")
    
    
    @Operation(summary = "", description = "", tags={ "registration-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK") })
    public Response confirm( @PathParam("token") String token,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.confirm(token,securityContext);
    }
    @GET
    @Path("/admin/users")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "registration-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", array = @ArraySchema(schema = @Schema(implementation = TAKUser.class)))) })
    public Response getAllUsers1(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getAllUsers1(securityContext);
    }
    @POST
    @Path("/admin/invite")
    
    
    @Operation(summary = "", description = "", tags={ "registration-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK") })
    public Response invite( @NotNull  @QueryParam("emailAddress") String emailAddress,  @DefaultValue("["__ANON__"]") @QueryParam("group") List<String> group,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.invite(emailAddress,group,securityContext);
    }
    @POST
    @Path("/user")
    
    
    @Operation(summary = "", description = "", tags={ "registration-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK") })
    public Response signUp( @NotNull  @QueryParam("emailAddress") String emailAddress, @NotNull  @QueryParam("token") String token,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.signUp(emailAddress,token,securityContext);
    }
}
