package io.swagger.api;

import io.swagger.model.*;
import io.swagger.api.UserManagementApiService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;

import io.swagger.model.GroupNameModel;
import io.swagger.model.NewUserModel;
import io.swagger.model.SimpleGroupWithUsersModel;
import io.swagger.model.SimpleUserGroupModel;
import io.swagger.model.UserGenerationInBulkModel;
import io.swagger.model.UserPasswordModel;
import io.swagger.model.UsernameModel;

import java.util.Map;
import java.util.List;
import io.swagger.api.NotFoundException;

import java.io.InputStream;

import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import javax.ws.rs.*;
import javax.inject.Inject;

import javax.validation.constraints.*;
@Path("/user-management")


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class UserManagementApi  {

    @Inject UserManagementApiService service;

    @PUT
    @Path("/api/change-user-password")
    @Consumes({ "application/json" })
    
    @Operation(summary = "", description = "", tags={ "file-user-account-management-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK") })
    public Response changeUserPassword(@Parameter(description = "" ,required=true) UserPasswordModel body,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.changeUserPassword(body,securityContext);
    }
    @POST
    @Path("/api/new-users")
    @Consumes({ "application/json" })
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "file-user-account-management-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", array = @ArraySchema(schema = @Schema(implementation = UserPasswordModel.class)))) })
    public Response createFileUsersInBulk(@Parameter(description = "" ,required=true) UserGenerationInBulkModel body,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.createFileUsersInBulk(body,securityContext);
    }
    @POST
    @Path("/api/new-user")
    @Consumes({ "application/json" })
    
    @Operation(summary = "", description = "", tags={ "file-user-account-management-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK") })
    public Response createOrUpdateFileUser(@Parameter(description = "" ,required=true) NewUserModel body,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.createOrUpdateFileUser(body,securityContext);
    }
    @DELETE
    @Path("/api/delete-user/{username}")
    
    
    @Operation(summary = "", description = "", tags={ "file-user-account-management-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK") })
    public Response deleteUser( @PathParam("username") String username,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.deleteUser(username,securityContext);
    }
    @GET
    @Path("/api/list-groupnames")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "file-user-account-management-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", array = @ArraySchema(schema = @Schema(implementation = GroupNameModel.class)))) })
    public Response getAllGroupNames(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getAllGroupNames(securityContext);
    }
    @GET
    @Path("/api/list-users")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "file-user-account-management-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", array = @ArraySchema(schema = @Schema(implementation = UsernameModel.class)))) })
    public Response getAllUsers(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getAllUsers(securityContext);
    }
    @GET
    @Path("/api/get-groups-for-user/{username}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "file-user-account-management-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = SimpleUserGroupModel.class))) })
    public Response getGroupsForUsers( @PathParam("username") String username,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getGroupsForUsers(username,securityContext);
    }
    @GET
    @Path("/api/users-in-group/{group}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "file-user-account-management-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = SimpleGroupWithUsersModel.class))) })
    public Response getUsersInGroup( @PathParam("group") String group,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getUsersInGroup(group,securityContext);
    }
    @PUT
    @Path("/api/update-groups")
    @Consumes({ "application/json" })
    
    @Operation(summary = "", description = "", tags={ "file-user-account-management-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK") })
    public Response updateGroupsForUser(@Parameter(description = "" ,required=true) SimpleUserGroupModel body,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.updateGroupsForUser(body,securityContext);
    }
}
