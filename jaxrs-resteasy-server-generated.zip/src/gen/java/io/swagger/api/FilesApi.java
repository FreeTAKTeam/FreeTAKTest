package io.swagger.api;

import io.swagger.model.*;
import io.swagger.api.FilesApiService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;

import io.swagger.model.FileConfigurationModel;

import java.util.Map;
import java.util.List;
import io.swagger.api.NotFoundException;

import java.io.InputStream;

import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import javax.ws.rs.*;
import javax.inject.Inject;

import javax.validation.constraints.*;
@Path("/files")


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class FilesApi  {

    @Inject FilesApiService service;

    @GET
    @Path("/api/config")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "file-configuration-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = FileConfigurationModel.class))) })
    public Response getFileConfiguration(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getFileConfiguration(securityContext);
    }
    @POST
    @Path("/api/config")
    @Consumes({ "application/json" })
    
    @Operation(summary = "", description = "", tags={ "file-configuration-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK") })
    public Response setFileConfiguration(@Parameter(description = "" ,required=true) FileConfigurationModel body,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.setFileConfiguration(body,securityContext);
    }
}
