package io.swagger.api;

import io.swagger.api.*;
import io.swagger.model.*;

import io.swagger.model.ApiCitrapBody;
import io.swagger.model.ApiFederatecertificatesBody;
import io.swagger.model.ApiIconsetBody;
import io.swagger.model.ApiResponseAuthenticationConfigInfo;
import io.swagger.model.ApiResponseBoolean;
import io.swagger.model.ApiResponseCaveat;
import io.swagger.model.ApiResponseClassification;
import io.swagger.model.ApiResponseCollectionGroup;
import io.swagger.model.ApiResponseCollectionInjectorConfig;
import io.swagger.model.ApiResponseCollectionMapLayer;
import io.swagger.model.ApiResponseCollectionPluginInfo;
import io.swagger.model.ApiResponseCollectionString;
import io.swagger.model.ApiResponseConnectionModifyResult;
import io.swagger.model.ApiResponseConnectionStatus;
import io.swagger.model.ApiResponseDataFeed;
import io.swagger.model.ApiResponseEntryIntegerInteger;
import io.swagger.model.ApiResponseEntryStringString;
import io.swagger.model.ApiResponseExternalMissionData;
import io.swagger.model.ApiResponseFederate;
import io.swagger.model.ApiResponseFederateMissionPerConnectionSettings;
import io.swagger.model.ApiResponseFederationConfigInfo;
import io.swagger.model.ApiResponseFederationOutgoing;
import io.swagger.model.ApiResponseGroup;
import io.swagger.model.ApiResponseInput;
import io.swagger.model.ApiResponseInputMetric;
import io.swagger.model.ApiResponseInteger;
import io.swagger.model.ApiResponseListCaveat;
import io.swagger.model.ApiResponseListCertificateSummary;
import io.swagger.model.ApiResponseListClassification;
import io.swagger.model.ApiResponseListClientEndpoint;
import io.swagger.model.ApiResponseListConnectionInfoSummary;
import io.swagger.model.ApiResponseListCotSearch;
import io.swagger.model.ApiResponseListDataFeed;
import io.swagger.model.ApiResponseListEntryStringString;
import io.swagger.model.ApiResponseListFederateCAGroupAssociation;
import io.swagger.model.ApiResponseListFederateGroupAssociation;
import io.swagger.model.ApiResponseListLogEntry;
import io.swagger.model.ApiResponseListMission;
import io.swagger.model.ApiResponseListMissionChange;
import io.swagger.model.ApiResponseListMissionInvitation;
import io.swagger.model.ApiResponseListMissionSubscription;
import io.swagger.model.ApiResponseListProfile;
import io.swagger.model.ApiResponseListProfileDirectory;
import io.swagger.model.ApiResponseListProfileFile;
import io.swagger.model.ApiResponseListRepeatable;
import io.swagger.model.ApiResponseListResource;
import io.swagger.model.ApiResponseListString;
import io.swagger.model.ApiResponseListTakCert;
import io.swagger.model.ApiResponseListTokenResult;
import io.swagger.model.ApiResponseListUIDResult;
import io.swagger.model.ApiResponseLogEntry;
import io.swagger.model.ApiResponseLong;
import io.swagger.model.ApiResponseMapLayer;
import io.swagger.model.ApiResponseMapStringCollectionString;
import io.swagger.model.ApiResponseMapStringInteger;
import io.swagger.model.ApiResponseMapStringString;
import io.swagger.model.ApiResponseMessagingConfigInfo;
import io.swagger.model.ApiResponseMission;
import io.swagger.model.ApiResponseMissionArchiveConfig;
import io.swagger.model.ApiResponseMissionRole;
import io.swagger.model.ApiResponseMissionSubscription;
import io.swagger.model.ApiResponseNavigableSetResource;
import io.swagger.model.ApiResponseProfile;
import io.swagger.model.ApiResponseProfileFile;
import io.swagger.model.ApiResponseQos;
import io.swagger.model.ApiResponseSecurityConfigInfo;
import io.swagger.model.ApiResponseServerConfig;
import io.swagger.model.ApiResponseSetCopHierarchyNode;
import io.swagger.model.ApiResponseSetInjectorConfig;
import io.swagger.model.ApiResponseSetMission;
import io.swagger.model.ApiResponseSetMissionChange;
import io.swagger.model.ApiResponseSetMissionInvitation;
import io.swagger.model.ApiResponseSetString;
import io.swagger.model.ApiResponseSetSubscriptionInfo;
import io.swagger.model.ApiResponseSortedSetFederate;
import io.swagger.model.ApiResponseSortedSetInputMetric;
import io.swagger.model.ApiResponseSortedSetLdapGroup;
import io.swagger.model.ApiResponseSortedSetOutgoingConnectionSummary;
import io.swagger.model.ApiResponseSortedSetRemoteContact;
import io.swagger.model.ApiResponseSortedSetUser;
import io.swagger.model.ApiResponseString;
import io.swagger.model.ApiResponseSubscriptionInfo;
import io.swagger.model.ApiResponseTakCert;
import io.swagger.model.ApiResponseUserGroups;
import io.swagger.model.AuthenticationConfigInfo;
import io.swagger.model.CitrapIdBody;
import io.swagger.model.Classification;
import io.swagger.model.ContentsMissionpackageBody;
import io.swagger.model.DataFeed;
import java.util.Date;
import io.swagger.model.ExternalMissionData;
import io.swagger.model.Federate;
import io.swagger.model.FederateCAGroupAssociation;
import io.swagger.model.FederateGroupAssociation;
import io.swagger.model.FederateMissionPerConnectionSettings;
import io.swagger.model.FederationConfigInfo;
import io.swagger.model.FederationOutgoing;
import io.swagger.model.Filter;
import io.swagger.model.Group;
import io.swagger.model.IdAttachmentBody;
import io.swagger.model.InjectorConfig;
import io.swagger.model.Input;
import io.swagger.model.LogEntry;
import io.swagger.model.MapLayer;
import io.swagger.model.MessagingConfigInfo;
import io.swagger.model.MissionArchiveConfig;
import io.swagger.model.MissionContent;
import io.swagger.model.MissionSubscription;
import io.swagger.model.MissionsNameBody;
import io.swagger.model.ModelConfiguration;
import io.swagger.model.NameFileBody;
import io.swagger.model.NameSubmitBody;
import io.swagger.model.NameSubmitBody1;
import io.swagger.model.Profile;
import io.swagger.model.PropertiesUidBody;
import io.swagger.model.RemoteSubscription;
import io.swagger.model.SecurityConfigInfo;
import io.swagger.model.SubmitResultBody;
import io.swagger.model.TmpStaticSub;
import io.swagger.model.UidFilenameBody;
import io.swagger.model.VersionInfo;
import io.swagger.model.VideoCollections;
import io.swagger.model.VideoConnection;

import java.util.List;
import io.swagger.api.NotFoundException;

import java.io.InputStream;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;

@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public interface MartiApiService {
      Response addAttachment(IdAttachmentBody body,String clientUid,String id,SecurityContext securityContext)
      throws NotFoundException;
      Response addContentKeyword(List<String> body,String name,String hash,String creatorUid,SecurityContext securityContext)
      throws NotFoundException;
      Response addEditChecklistTask(String body,String clientUid,String checklistUid,String taskUid,SecurityContext securityContext)
      throws NotFoundException;
      Response addEditTemplateTask(String body,String clientUid,String templateUid,String taskUid,SecurityContext securityContext)
      throws NotFoundException;
      Response addFederateCAGroup(FederateCAGroupAssociation body,SecurityContext securityContext)
      throws NotFoundException;
      Response addFederateGroup(FederateGroupAssociation body,SecurityContext securityContext)
      throws NotFoundException;
      Response addFederateGroupMap(String federateId,String remoteGroup,String localGroup,SecurityContext securityContext)
      throws NotFoundException;
      Response addFeed(String missionName,String creatorUid,String dataFeedUid,String filterBbox,String filterType,String filterCallsign,SecurityContext securityContext)
      throws NotFoundException;
      Response addFile(NameFileBody body,String filename,String name,SecurityContext securityContext)
      throws NotFoundException;
      Response addMissionContent(MissionContent body,String name,String creatorUid,SecurityContext securityContext)
      throws NotFoundException;
      Response addMissionPackage(ContentsMissionpackageBody body,String creatorUid,String name,SecurityContext securityContext)
      throws NotFoundException;
      Response addMissionReferenceToChecklist(String checklistUid,String missionName,String clientUid,String password,SecurityContext securityContext)
      throws NotFoundException;
      Response addSubscription(TmpStaticSub body,SecurityContext securityContext)
      throws NotFoundException;
      Response addUidKeyword(List<String> body,String name,String uid,String creatorUid,SecurityContext securityContext)
      throws NotFoundException;
      Response changeAllPluginStartedStatus(Boolean status,SecurityContext securityContext)
      throws NotFoundException;
      Response changeConnectionStatus(String name,Boolean newStatus,SecurityContext securityContext)
      throws NotFoundException;
      Response changePluginArchiveSetting(String name,Boolean archiveEnabled,SecurityContext securityContext)
      throws NotFoundException;
      Response changePluginEnabledSetting(String name,Boolean status,SecurityContext securityContext)
      throws NotFoundException;
      Response changePluginStartedStatus(String name,Boolean status,SecurityContext securityContext)
      throws NotFoundException;
      Response clearAllProperty(String uid,SecurityContext securityContext)
      throws NotFoundException;
      Response clearContentKeywords(String name,String hash,String creatorUid,SecurityContext securityContext)
      throws NotFoundException;
      Response clearDisruptionData(SecurityContext securityContext)
      throws NotFoundException;
      Response clearKeywords(String name,String creatorUid,SecurityContext securityContext)
      throws NotFoundException;
      Response clearParent(String childName,SecurityContext securityContext)
      throws NotFoundException;
      Response clearProperty(String uid,String key,SecurityContext securityContext)
      throws NotFoundException;
      Response clearUidKeywords(String name,String uid,String creatorUid,SecurityContext securityContext)
      throws NotFoundException;
      Response copyMission(String missionName,String creatorUid,String copyName,String copyPath,String defaultRole,String password,SecurityContext securityContext)
      throws NotFoundException;
      Response createChecklist(String body,String clientUid,String defaultRole,SecurityContext securityContext)
      throws NotFoundException;
      Response createDataFeed(DataFeed body,SecurityContext securityContext)
      throws NotFoundException;
      Response createInput(Input body,SecurityContext securityContext)
      throws NotFoundException;
      Response createMapLayer(MapLayer body,String creatorUid,String missionName,SecurityContext securityContext)
      throws NotFoundException;
      Response createMapLayer1(MapLayer body,SecurityContext securityContext)
      throws NotFoundException;
      Response createMission(String name,MissionsNameBody body,String creatorUid,List<String> group,String description,String chatRoom,String baseLayer,String bbox,List<String> boundingPolygon,String path,String classification,String tool,String password,String defaultRole,Long expiration,Boolean inviteOnly,SecurityContext securityContext)
      throws NotFoundException;
      Response createMissionSubscription(String missionName,String uid,String topic,String password,Long secago,Date start,Date end,SecurityContext securityContext)
      throws NotFoundException;
      Response createOutgoingConnection(FederationOutgoing body,SecurityContext securityContext)
      throws NotFoundException;
      Response createProfile(String name,List<String> group,SecurityContext securityContext)
      throws NotFoundException;
      Response createVideoConnection(VideoCollections body,SecurityContext securityContext)
      throws NotFoundException;
      Response deleteCaveat(String name,SecurityContext securityContext)
      throws NotFoundException;
      Response deleteCertificates(String ids,SecurityContext securityContext)
      throws NotFoundException;
      Response deleteChecklist(String checklistUid,String clientUid,SecurityContext securityContext)
      throws NotFoundException;
      Response deleteChecklistTask(String checklistUid,String taskUid,String clientUid,SecurityContext securityContext)
      throws NotFoundException;
      Response deleteClassification(String level,SecurityContext securityContext)
      throws NotFoundException;
      Response deleteDataFeed(String name,SecurityContext securityContext)
      throws NotFoundException;
      Response deleteDirectories(String name,SecurityContext securityContext)
      throws NotFoundException;
      Response deleteExternalMissionData(String name,String id,String notes,String creatorUid,SecurityContext securityContext)
      throws NotFoundException;
      Response deleteFederate(String federateId,SecurityContext securityContext)
      throws NotFoundException;
      Response deleteFederateCertificateCA(String fingerprint,SecurityContext securityContext)
      throws NotFoundException;
      Response deleteFile(String name,Long id,SecurityContext securityContext)
      throws NotFoundException;
      Response deleteFilter(String clientUid,SecurityContext securityContext)
      throws NotFoundException;
      Response deleteFromPlugin(String name,Map<String, String> allRequestParams,SecurityContext securityContext)
      throws NotFoundException;
      Response deleteInjector(String uid,String toInject,SecurityContext securityContext)
      throws NotFoundException;
      Response deleteInput(String name,SecurityContext securityContext)
      throws NotFoundException;
      Response deleteLogEntry(String id,SecurityContext securityContext)
      throws NotFoundException;
      Response deleteMapLayer(String missionName,String creatorUid,String uid,SecurityContext securityContext)
      throws NotFoundException;
      Response deleteMapLayer1(String uid,SecurityContext securityContext)
      throws NotFoundException;
      Response deleteMission(String name,String creatorUid,Boolean deepDelete,SecurityContext securityContext)
      throws NotFoundException;
      Response deleteMissionSubscription(String missionName,String uid,String topic,Boolean disconnectOnly,SecurityContext securityContext)
      throws NotFoundException;
      Response deleteOutgoingConnection(String name,SecurityContext securityContext)
      throws NotFoundException;
      Response deleteProfile(Long id,SecurityContext securityContext)
      throws NotFoundException;
      Response deleteReport(String id,String clientUid,SecurityContext securityContext)
      throws NotFoundException;
      Response deleteSubscription(String uid,SecurityContext securityContext)
      throws NotFoundException;
      Response deleteTemplate(String templateUid,String clientUid,SecurityContext securityContext)
      throws NotFoundException;
      Response deleteTemplateTask(String templateUid,String taskUid,String clientUid,SecurityContext securityContext)
      throws NotFoundException;
      Response deleteVideoConnection(String uid,SecurityContext securityContext)
      throws NotFoundException;
      Response deviceGetProfileDirectoryContent(String toolName,List<String> relativePath,String clientUid,Long syncSecago,SecurityContext securityContext)
      throws NotFoundException;
      Response disableStoreForwardChat(SecurityContext securityContext)
      throws NotFoundException;
      Response downloadCertificate(String hash,SecurityContext securityContext)
      throws NotFoundException;
      Response downloadCertificates(String ids,SecurityContext securityContext)
      throws NotFoundException;
      Response enableDOS(Boolean body,SecurityContext securityContext)
      throws NotFoundException;
      Response enableDelivery(Boolean body,SecurityContext securityContext)
      throws NotFoundException;
      Response enableRead(Boolean body,SecurityContext securityContext)
      throws NotFoundException;
      Response enableStoreForwardChat(SecurityContext securityContext)
      throws NotFoundException;
      Response getAccessToken(SecurityContext securityContext)
      throws NotFoundException;
      Response getActive(SecurityContext securityContext)
      throws NotFoundException;
      Response getActiveConnections(SecurityContext securityContext)
      throws NotFoundException;
      Response getActiveDOSRateLimit(SecurityContext securityContext)
      throws NotFoundException;
      Response getActiveDeliveryRateLimit(SecurityContext securityContext)
      throws NotFoundException;
      Response getActiveReadRateLimit(SecurityContext securityContext)
      throws NotFoundException;
      Response getAll(Boolean expired,SecurityContext securityContext)
      throws NotFoundException;
      Response getAll1(String username,SecurityContext securityContext)
      throws NotFoundException;
      Response getAllCaveat(SecurityContext securityContext)
      throws NotFoundException;
      Response getAllClassifications(SecurityContext securityContext)
      throws NotFoundException;
      Response getAllContacts(String sortBy,String direction,Boolean noFederates,SecurityContext securityContext)
      throws NotFoundException;
      Response getAllCopMissions(String path,Integer offset,Integer size,SecurityContext securityContext)
      throws NotFoundException;
      Response getAllCotEvents(String uid,Long secago,Date start,Date end,SecurityContext securityContext)
      throws NotFoundException;
      Response getAllCotInjectors(SecurityContext securityContext)
      throws NotFoundException;
      Response getAllGroups(Boolean useCache,Boolean sendLatestSA,SecurityContext securityContext)
      throws NotFoundException;
      Response getAllIconUrlsForIconset(String uid,SecurityContext securityContext)
      throws NotFoundException;
      Response getAllIconsetUids(SecurityContext securityContext)
      throws NotFoundException;
      Response getAllLogEntries(SecurityContext securityContext)
      throws NotFoundException;
      Response getAllMapLayers(SecurityContext securityContext)
      throws NotFoundException;
      Response getAllMissionInvitations(String clientUid,SecurityContext securityContext)
      throws NotFoundException;
      Response getAllMissionInvitationsWithPasswords(String clientUid,SecurityContext securityContext)
      throws NotFoundException;
      Response getAllMissionSubscriptions(SecurityContext securityContext)
      throws NotFoundException;
      Response getAllMissions(Boolean passwordProtected,Boolean defaultRole,String tool,SecurityContext securityContext)
      throws NotFoundException;
      Response getAllPluginInfo(SecurityContext securityContext)
      throws NotFoundException;
      Response getAllProfile(SecurityContext securityContext)
      throws NotFoundException;
      Response getAllPropertyForUid(String uid,SecurityContext securityContext)
      throws NotFoundException;
      Response getAllPropertyKeys(SecurityContext securityContext)
      throws NotFoundException;
      Response getAllSearches(SecurityContext securityContext)
      throws NotFoundException;
      Response getAllSubscriptions(String sortBy,String direction,Integer page,Integer limit,SecurityContext securityContext)
      throws NotFoundException;
      Response getAllUsers2(SecurityContext securityContext)
      throws NotFoundException;
      Response getAuthConfig(SecurityContext securityContext)
      throws NotFoundException;
      Response getCachedCoreConfig(SecurityContext securityContext)
      throws NotFoundException;
      Response getCachedInputConfig(SecurityContext securityContext)
      throws NotFoundException;
      Response getCertificate(String hash,SecurityContext securityContext)
      throws NotFoundException;
      Response getChecklist(String checklistUid,String clientUid,Long secago,String token,SecurityContext securityContext)
      throws NotFoundException;
      Response getChecklist1(String clientUid,SecurityContext securityContext)
      throws NotFoundException;
      Response getChecklistStatus(String checklistUid,String token,String clientUid,SecurityContext securityContext)
      throws NotFoundException;
      Response getChecklistTask(String checklistUid,String taskUid,String clientUid,SecurityContext securityContext)
      throws NotFoundException;
      Response getChildren(String name,SecurityContext securityContext)
      throws NotFoundException;
      Response getClassificationForLevel(String level,SecurityContext securityContext)
      throws NotFoundException;
      Response getClientEndpoints(Long secAgo,String showCurrentlyConnectedClients,String showMostRecentOnly,SecurityContext securityContext)
      throws NotFoundException;
      Response getConfig(SecurityContext securityContext)
      throws NotFoundException;
      Response getConfigInfo(SecurityContext securityContext)
      throws NotFoundException;
      Response getConnectionStatus(String name,SecurityContext securityContext)
      throws NotFoundException;
      Response getConnectionTimeProfiles(Long syncSecago,String clientUid,SecurityContext securityContext)
      throws NotFoundException;
      Response getCoreConfig(SecurityContext securityContext)
      throws NotFoundException;
      Response getCotEvent(String uid,SecurityContext securityContext)
      throws NotFoundException;
      Response getCotEvents(List<String> uids,SecurityContext securityContext)
      throws NotFoundException;
      Response getCotEventsByTimeAndBbox(Date start,Date end,Double left,Double bottom,Double right,Double top,SecurityContext securityContext)
      throws NotFoundException;
      Response getDataFeed(String name,SecurityContext securityContext)
      throws NotFoundException;
      Response getDataFeeds(SecurityContext securityContext)
      throws NotFoundException;
      Response getDatabaseCotCounts(SecurityContext securityContext)
      throws NotFoundException;
      Response getDate(SecurityContext securityContext)
      throws NotFoundException;
      Response getDirectories(String name,SecurityContext securityContext)
      throws NotFoundException;
      Response getEnrollmentTimeProfiles(String clientUid,SecurityContext securityContext)
      throws NotFoundException;
      Response getExpired(SecurityContext securityContext)
      throws NotFoundException;
      Response getFederateCAGroups(String caId,SecurityContext securityContext)
      throws NotFoundException;
      Response getFederateCertificates(SecurityContext securityContext)
      throws NotFoundException;
      Response getFederateContacts(String federateId,SecurityContext securityContext)
      throws NotFoundException;
      Response getFederateDetails(String id,SecurityContext securityContext)
      throws NotFoundException;
      Response getFederateGroups(String federateId,SecurityContext securityContext)
      throws NotFoundException;
      Response getFederateGroupsMap(String federateId,SecurityContext securityContext)
      throws NotFoundException;
      Response getFederateRemoteGroups(String federateId,SecurityContext securityContext)
      throws NotFoundException;
      Response getFederates(SecurityContext securityContext)
      throws NotFoundException;
      Response getFederationConfig(SecurityContext securityContext)
      throws NotFoundException;
      Response getFile(String uid,String filename,SecurityContext securityContext)
      throws NotFoundException;
      Response getFile1(String name,Long id,SecurityContext securityContext)
      throws NotFoundException;
      Response getFiles(String name,SecurityContext securityContext)
      throws NotFoundException;
      Response getGroup(String name,String direction,SecurityContext securityContext)
      throws NotFoundException;
      Response getGroupCacheEnabled(SecurityContext securityContext)
      throws NotFoundException;
      Response getGroupPrefix(SecurityContext securityContext)
      throws NotFoundException;
      Response getHierarchy(SecurityContext securityContext)
      throws NotFoundException;
      Response getHome(SecurityContext securityContext)
      throws NotFoundException;
      Response getIcon(String uid,String group,String name,SecurityContext securityContext)
      throws NotFoundException;
      Response getIconImage(String iconsetpath,String cotType,Boolean medevac,String groupName,String role,Long color,Boolean relative,SecurityContext securityContext)
      throws NotFoundException;
      Response getIconUrl(String iconsetpath,String cotType,Boolean medevac,String groupName,String role,Long color,Boolean relative,SecurityContext securityContext)
      throws NotFoundException;
      Response getInputMetric(String name,SecurityContext securityContext)
      throws NotFoundException;
      Response getInputMetrics(Boolean excludeDataFeeds,SecurityContext securityContext)
      throws NotFoundException;
      Response getKml(String name,Boolean download,SecurityContext securityContext)
      throws NotFoundException;
      Response getLatestMissionCotEvents(String name,SecurityContext securityContext)
      throws NotFoundException;
      Response getLdapGroupMembers(List<String> groupNameFilter,SecurityContext securityContext)
      throws NotFoundException;
      Response getLdapGroups(String groupNameFilter,SecurityContext securityContext)
      throws NotFoundException;
      Response getList(SecurityContext securityContext)
      throws NotFoundException;
      Response getLogEntry(String missionName,Long secago,Date start,Date end,SecurityContext securityContext)
      throws NotFoundException;
      Response getMapLayerForUid(String uid,SecurityContext securityContext)
      throws NotFoundException;
      Response getMission(String name,String password,Boolean changes,Boolean logs,Long secago,Date start,Date end,SecurityContext securityContext)
      throws NotFoundException;
      Response getMissionArchive(SecurityContext securityContext)
      throws NotFoundException;
      Response getMissionArchive1(String name,SecurityContext securityContext)
      throws NotFoundException;
      Response getMissionArchiveConfig(SecurityContext securityContext)
      throws NotFoundException;
      Response getMissionChanges(String name,Long secago,Date start,Date end,Boolean squashed,SecurityContext securityContext)
      throws NotFoundException;
      Response getMissionInvitations(String missionName,SecurityContext securityContext)
      throws NotFoundException;
      Response getMissionRoleFromToken(String missionName,SecurityContext securityContext)
      throws NotFoundException;
      Response getMissionSubscriptionRoles(String missionName,SecurityContext securityContext)
      throws NotFoundException;
      Response getMissionSubscriptions(String missionName,SecurityContext securityContext)
      throws NotFoundException;
      Response getNextInSequence(String key,SecurityContext securityContext)
      throws NotFoundException;
      Response getNodeId(SecurityContext securityContext)
      throws NotFoundException;
      Response getNum(SecurityContext securityContext)
      throws NotFoundException;
      Response getOneCotInjector(String uid,SecurityContext securityContext)
      throws NotFoundException;
      Response getOneLogEntry(String id,SecurityContext securityContext)
      throws NotFoundException;
      Response getOutgoingConnection(String name,SecurityContext securityContext)
      throws NotFoundException;
      Response getOutgoingConnections(SecurityContext securityContext)
      throws NotFoundException;
      Response getParent(String name,SecurityContext securityContext)
      throws NotFoundException;
      Response getPeriod(SecurityContext securityContext)
      throws NotFoundException;
      Response getProfile(String name,SecurityContext securityContext)
      throws NotFoundException;
      Response getProfileMp(String name,SecurityContext securityContext)
      throws NotFoundException;
      Response getPropertyForUid(String uid,String key,SecurityContext securityContext)
      throws NotFoundException;
      Response getQosConf(SecurityContext securityContext)
      throws NotFoundException;
      Response getReadOnlyAccessToken(String missionName,String password,SecurityContext securityContext)
      throws NotFoundException;
      Response getReplaced(SecurityContext securityContext)
      throws NotFoundException;
      Response getReport(String id,String clientUid,SecurityContext securityContext)
      throws NotFoundException;
      Response getResource(String hash,SecurityContext securityContext)
      throws NotFoundException;
      Response getRetentionPolicy(SecurityContext securityContext)
      throws NotFoundException;
      Response getRetentionServiceSchedule(SecurityContext securityContext)
      throws NotFoundException;
      Response getRevoked(SecurityContext securityContext)
      throws NotFoundException;
      Response getSearch(String id,SecurityContext securityContext)
      throws NotFoundException;
      Response getSecConfig(SecurityContext securityContext)
      throws NotFoundException;
      Response getSubscriptionForUser(String missionName,String uid,SecurityContext securityContext)
      throws NotFoundException;
      Response getTemplate(String templateUid,String clientUid,SecurityContext securityContext)
      throws NotFoundException;
      Response getTemplateTask(String templateUid,String taskUid,String clientUid,SecurityContext securityContext)
      throws NotFoundException;
      Response getToolProfiles(String toolName,String clientUid,Long syncSecago,SecurityContext securityContext)
      throws NotFoundException;
      Response getUIDResults(String startDate,String endDate,SecurityContext securityContext)
      throws NotFoundException;
      Response getUser(String connectionId,SecurityContext securityContext)
      throws NotFoundException;
      Response getUserRoles(SecurityContext securityContext)
      throws NotFoundException;
      Response getValidDirectories(SecurityContext securityContext)
      throws NotFoundException;
      Response getVer(SecurityContext securityContext)
      throws NotFoundException;
      Response getVersion(SecurityContext securityContext)
      throws NotFoundException;
      Response getVersionConfig(SecurityContext securityContext)
      throws NotFoundException;
      Response getVersionInfo(SecurityContext securityContext)
      throws NotFoundException;
      Response getVideoCollections(String protocol,SecurityContext securityContext)
      throws NotFoundException;
      Response getVideoConnection(String uid,SecurityContext securityContext)
      throws NotFoundException;
      Response groupsUpdated(String username,SecurityContext securityContext)
      throws NotFoundException;
      Response headProfileMp(String name,SecurityContext securityContext)
      throws NotFoundException;
      Response inviteToMission(String name,String type,String invitee,String creatorUid,String role,SecurityContext securityContext)
      throws NotFoundException;
      Response isAdmin(SecurityContext securityContext)
      throws NotFoundException;
      Response isSecure(SecurityContext securityContext)
      throws NotFoundException;
      Response isStoreForwardChatEnabled(SecurityContext securityContext)
      throws NotFoundException;
      Response makeKeyStore(String cn,String password,SecurityContext securityContext)
      throws NotFoundException;
      Response modifyAuthConfig(AuthenticationConfigInfo body,SecurityContext securityContext)
      throws NotFoundException;
      Response modifyConfigInfo(MessagingConfigInfo body,SecurityContext securityContext)
      throws NotFoundException;
      Response modifyDataFeed(DataFeed body,String name,SecurityContext securityContext)
      throws NotFoundException;
      Response modifyFederationConfig(FederationConfigInfo body,SecurityContext securityContext)
      throws NotFoundException;
      Response modifyInput(Input body,String id,SecurityContext securityContext)
      throws NotFoundException;
      Response modifySecConfig(SecurityConfigInfo body,SecurityContext securityContext)
      throws NotFoundException;
      Response newCaveat(String name,SecurityContext securityContext)
      throws NotFoundException;
      Response newClassification(String level,SecurityContext securityContext)
      throws NotFoundException;
      Response notifyExternalDataChanged(String body,String creatorUid,String notes,String name,String id,SecurityContext securityContext)
      throws NotFoundException;
      Response postIconsetZip(ApiIconsetBody body,SecurityContext securityContext)
      throws NotFoundException;
      Response postLogEntry(LogEntry body,SecurityContext securityContext)
      throws NotFoundException;
      Response postReport(ApiCitrapBody body,String clientUid,SecurityContext securityContext)
      throws NotFoundException;
      Response postTemplate(String clientUid,String callsign,String name,String description,SecurityContext securityContext)
      throws NotFoundException;
      Response putCotInjector(InjectorConfig body,SecurityContext securityContext)
      throws NotFoundException;
      Response putFile(UidFilenameBody body,String uid,String filename,SecurityContext securityContext)
      throws NotFoundException;
      Response putReport(CitrapIdBody body,String clientUid,String id,SecurityContext securityContext)
      throws NotFoundException;
      Response remove(String uid,SecurityContext securityContext)
      throws NotFoundException;
      Response removeFederateCAGroup(String caId,String group,String direction,SecurityContext securityContext)
      throws NotFoundException;
      Response removeFederateGroup(String federateId,String group,String direction,SecurityContext securityContext)
      throws NotFoundException;
      Response removeFederateGroupMap(String federateId,String remoteGroup,String localGroup,SecurityContext securityContext)
      throws NotFoundException;
      Response removeFeed(String missionName,String uid,String creatorUid,SecurityContext securityContext)
      throws NotFoundException;
      Response removeKeyword(String name,String keyword,String creatorUid,SecurityContext securityContext)
      throws NotFoundException;
      Response removeMissionContent(String name,String hash,String uid,String creatorUid,SecurityContext securityContext)
      throws NotFoundException;
      Response removeMissionReferenceFromChecklist(String checklistUid,String missionName,String clientUid,SecurityContext securityContext)
      throws NotFoundException;
      Response removePassword(String name,String creatorUid,SecurityContext securityContext)
      throws NotFoundException;
      Response requestFromPlugin(String name,Map<String, String> allRequestParams,SecurityContext securityContext)
      throws NotFoundException;
      Response restoreMissionFromArchive(Integer body,SecurityContext securityContext)
      throws NotFoundException;
      Response results(String name,SecurityContext securityContext)
      throws NotFoundException;
      Response revokeCertificate(String hash,SecurityContext securityContext)
      throws NotFoundException;
      Response revokeCertificates(String ids,SecurityContext securityContext)
      throws NotFoundException;
      Response revokeToken(String token,SecurityContext securityContext)
      throws NotFoundException;
      Response revokeTokens(String tokens,SecurityContext securityContext)
      throws NotFoundException;
      Response saveFederateCertificateCA(ApiFederatecertificatesBody body,SecurityContext securityContext)
      throws NotFoundException;
      Response saveFederateGroupConfiguration(SecurityContext securityContext)
      throws NotFoundException;
      Response scheduleMissionExpiration(String name,Long time,SecurityContext securityContext)
      throws NotFoundException;
      Response scheduleResourceExpiration(String name,Long time,SecurityContext securityContext)
      throws NotFoundException;
      Response searchReports(String keywords,String bbox,String startTime,String endTime,String maxReportCount,String type,String callsign,String subscribe,String clientUid,SecurityContext securityContext)
      throws NotFoundException;
      Response searchSync(String box,String circle,Date startTime,Date endTime,Double minAltitude,Double maxAltitude,String filename,List<String> keyword,String mimetype,String name,String uid,String hash,String mission,String tool,SecurityContext securityContext)
      throws NotFoundException;
      Response sendMissionArchive(String name,SecurityContext securityContext)
      throws NotFoundException;
      Response sendMissionInvites(String name,String creatorUid,SecurityContext securityContext)
      throws NotFoundException;
      Response sendProfile(List<String> body,String name,SecurityContext securityContext)
      throws NotFoundException;
      Response setActiveGroups(List<Integer> body,String clientUid,SecurityContext securityContext)
      throws NotFoundException;
      Response setActiveGroups1(List<Group> body,String clientUid,SecurityContext securityContext)
      throws NotFoundException;
      Response setCaveatsForClassification(Classification body,SecurityContext securityContext)
      throws NotFoundException;
      Response setExpiration(String hash,Long expiration,SecurityContext securityContext)
      throws NotFoundException;
      Response setExpiration1(String name,Long expiration,SecurityContext securityContext)
      throws NotFoundException;
      Response setExternalMissionData(ExternalMissionData body,String creatorUid,String name,SecurityContext securityContext)
      throws NotFoundException;
      Response setFilter(Filter body,String clientUid,SecurityContext securityContext)
      throws NotFoundException;
      Response setKeywords(List<String> body,String name,String creatorUid,SecurityContext securityContext)
      throws NotFoundException;
      Response setMetadata(String body,String hash,String metadata,SecurityContext securityContext)
      throws NotFoundException;
      Response setMetadataKeywords(List<String> body,String hash,SecurityContext securityContext)
      throws NotFoundException;
      Response setMissionRole(String missionName,String clientUid,String username,String role,SecurityContext securityContext)
      throws NotFoundException;
      Response setParent(String childName,String parentName,SecurityContext securityContext)
      throws NotFoundException;
      Response setPassword(String name,String password,String creatorUid,SecurityContext securityContext)
      throws NotFoundException;
      Response setPeriod(Integer body,SecurityContext securityContext)
      throws NotFoundException;
      Response setRetentionServiceSchedule(String body,SecurityContext securityContext)
      throws NotFoundException;
      Response setSubscriptionRole(List<MissionSubscription> body,String creatorUid,String missionName,SecurityContext securityContext)
      throws NotFoundException;
      Response signClientCert(String body,String clientUid,String version,SecurityContext securityContext)
      throws NotFoundException;
      Response signClientCertV2(String body,String clientUid,String version,SecurityContext securityContext)
      throws NotFoundException;
      Response startChecklist(String templateUid,String clientUid,String callsign,String name,String description,String startTime,String defaultRole,SecurityContext securityContext)
      throws NotFoundException;
      Response stopChecklist(String checklistUid,String clientUid,SecurityContext securityContext)
      throws NotFoundException;
      Response storeProperty(PropertiesUidBody body,String uid,SecurityContext securityContext)
      throws NotFoundException;
      Response submitToPluginUTF8(NameSubmitBody body,Map<String, String> allRequestParams,String name,SecurityContext securityContext)
      throws NotFoundException;
      Response submitToPluginUTF8WithResult(SubmitResultBody body,Map<String, String> allRequestParams,String name,SecurityContext securityContext)
      throws NotFoundException;
      Response testAuthConfig(SecurityContext securityContext)
      throws NotFoundException;
      Response tlsGetProfileDirectoryContent(String toolName,List<String> relativePath,String clientUid,Long syncSecago,SecurityContext securityContext)
      throws NotFoundException;
      Response toggleIncognito(String uid,SecurityContext securityContext)
      throws NotFoundException;
      Response uninviteFromMission(String name,String type,String invitee,String creatorUid,SecurityContext securityContext)
      throws NotFoundException;
      Response updateDirectories(String name,List<String> directories,SecurityContext securityContext)
      throws NotFoundException;
      Response updateFederateDetails(Federate body,SecurityContext securityContext)
      throws NotFoundException;
      Response updateFederateMissions(FederateMissionPerConnectionSettings body,String federateId,SecurityContext securityContext)
      throws NotFoundException;
      Response updateInPlugin(NameSubmitBody1 body,Map<String, String> allRequestParams,String name,SecurityContext securityContext)
      throws NotFoundException;
      Response updateLogEntry(LogEntry body,SecurityContext securityContext)
      throws NotFoundException;
      Response updateMapLayer(MapLayer body,String creatorUid,String missionName,SecurityContext securityContext)
      throws NotFoundException;
      Response updateMapLayer1(MapLayer body,SecurityContext securityContext)
      throws NotFoundException;
      Response updateMissionArchiveConfig(MissionArchiveConfig body,SecurityContext securityContext)
      throws NotFoundException;
      Response updateProfile(Profile body,String name,SecurityContext securityContext)
      throws NotFoundException;
      Response updateRetentionPolicy(Map<String, Integer> body,SecurityContext securityContext)
      throws NotFoundException;
      Response updateVideoConnection(VideoConnection body,String uid,SecurityContext securityContext)
      throws NotFoundException;
      Response verifyConfig(SecurityContext securityContext)
      throws NotFoundException;
      Response verifyFederationTruststore(SecurityContext securityContext)
      throws NotFoundException;
}
