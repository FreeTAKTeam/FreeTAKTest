package io.swagger.api;

import io.swagger.model.*;
import io.swagger.api.LocateApiService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;


import java.util.Map;
import java.util.List;
import io.swagger.api.NotFoundException;

import java.io.InputStream;

import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import javax.ws.rs.*;
import javax.inject.Inject;

import javax.validation.constraints.*;
@Path("/locate")


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class LocateApi  {

    @Inject LocateApiService service;

    @POST
    @Path("/api")
    
    
    @Operation(summary = "", description = "", tags={ "locate-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK") })
    public Response locate( @NotNull  @QueryParam("latitude") Double latitude, @NotNull  @QueryParam("longitude") Double longitude, @NotNull  @QueryParam("name") String name, @NotNull  @QueryParam("remarks") String remarks,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.locate(latitude,longitude,name,remarks,securityContext);
    }
}
