package io.swagger.api;

import io.swagger.model.*;
import io.swagger.api.MartiApiService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;

import io.swagger.model.ApiCitrapBody;
import io.swagger.model.ApiFederatecertificatesBody;
import io.swagger.model.ApiIconsetBody;
import io.swagger.model.ApiResponseAuthenticationConfigInfo;
import io.swagger.model.ApiResponseBoolean;
import io.swagger.model.ApiResponseCaveat;
import io.swagger.model.ApiResponseClassification;
import io.swagger.model.ApiResponseCollectionGroup;
import io.swagger.model.ApiResponseCollectionInjectorConfig;
import io.swagger.model.ApiResponseCollectionMapLayer;
import io.swagger.model.ApiResponseCollectionPluginInfo;
import io.swagger.model.ApiResponseCollectionString;
import io.swagger.model.ApiResponseConnectionModifyResult;
import io.swagger.model.ApiResponseConnectionStatus;
import io.swagger.model.ApiResponseDataFeed;
import io.swagger.model.ApiResponseEntryIntegerInteger;
import io.swagger.model.ApiResponseEntryStringString;
import io.swagger.model.ApiResponseExternalMissionData;
import io.swagger.model.ApiResponseFederate;
import io.swagger.model.ApiResponseFederateMissionPerConnectionSettings;
import io.swagger.model.ApiResponseFederationConfigInfo;
import io.swagger.model.ApiResponseFederationOutgoing;
import io.swagger.model.ApiResponseGroup;
import io.swagger.model.ApiResponseInput;
import io.swagger.model.ApiResponseInputMetric;
import io.swagger.model.ApiResponseInteger;
import io.swagger.model.ApiResponseListCaveat;
import io.swagger.model.ApiResponseListCertificateSummary;
import io.swagger.model.ApiResponseListClassification;
import io.swagger.model.ApiResponseListClientEndpoint;
import io.swagger.model.ApiResponseListConnectionInfoSummary;
import io.swagger.model.ApiResponseListCotSearch;
import io.swagger.model.ApiResponseListDataFeed;
import io.swagger.model.ApiResponseListEntryStringString;
import io.swagger.model.ApiResponseListFederateCAGroupAssociation;
import io.swagger.model.ApiResponseListFederateGroupAssociation;
import io.swagger.model.ApiResponseListLogEntry;
import io.swagger.model.ApiResponseListMission;
import io.swagger.model.ApiResponseListMissionChange;
import io.swagger.model.ApiResponseListMissionInvitation;
import io.swagger.model.ApiResponseListMissionSubscription;
import io.swagger.model.ApiResponseListProfile;
import io.swagger.model.ApiResponseListProfileDirectory;
import io.swagger.model.ApiResponseListProfileFile;
import io.swagger.model.ApiResponseListRepeatable;
import io.swagger.model.ApiResponseListResource;
import io.swagger.model.ApiResponseListString;
import io.swagger.model.ApiResponseListTakCert;
import io.swagger.model.ApiResponseListTokenResult;
import io.swagger.model.ApiResponseListUIDResult;
import io.swagger.model.ApiResponseLogEntry;
import io.swagger.model.ApiResponseLong;
import io.swagger.model.ApiResponseMapLayer;
import io.swagger.model.ApiResponseMapStringCollectionString;
import io.swagger.model.ApiResponseMapStringInteger;
import io.swagger.model.ApiResponseMapStringString;
import io.swagger.model.ApiResponseMessagingConfigInfo;
import io.swagger.model.ApiResponseMission;
import io.swagger.model.ApiResponseMissionArchiveConfig;
import io.swagger.model.ApiResponseMissionRole;
import io.swagger.model.ApiResponseMissionSubscription;
import io.swagger.model.ApiResponseNavigableSetResource;
import io.swagger.model.ApiResponseProfile;
import io.swagger.model.ApiResponseProfileFile;
import io.swagger.model.ApiResponseQos;
import io.swagger.model.ApiResponseSecurityConfigInfo;
import io.swagger.model.ApiResponseServerConfig;
import io.swagger.model.ApiResponseSetCopHierarchyNode;
import io.swagger.model.ApiResponseSetInjectorConfig;
import io.swagger.model.ApiResponseSetMission;
import io.swagger.model.ApiResponseSetMissionChange;
import io.swagger.model.ApiResponseSetMissionInvitation;
import io.swagger.model.ApiResponseSetString;
import io.swagger.model.ApiResponseSetSubscriptionInfo;
import io.swagger.model.ApiResponseSortedSetFederate;
import io.swagger.model.ApiResponseSortedSetInputMetric;
import io.swagger.model.ApiResponseSortedSetLdapGroup;
import io.swagger.model.ApiResponseSortedSetOutgoingConnectionSummary;
import io.swagger.model.ApiResponseSortedSetRemoteContact;
import io.swagger.model.ApiResponseSortedSetUser;
import io.swagger.model.ApiResponseString;
import io.swagger.model.ApiResponseSubscriptionInfo;
import io.swagger.model.ApiResponseTakCert;
import io.swagger.model.ApiResponseUserGroups;
import io.swagger.model.AuthenticationConfigInfo;
import io.swagger.model.CitrapIdBody;
import io.swagger.model.Classification;
import io.swagger.model.ContentsMissionpackageBody;
import io.swagger.model.DataFeed;
import java.util.Date;
import io.swagger.model.ExternalMissionData;
import io.swagger.model.Federate;
import io.swagger.model.FederateCAGroupAssociation;
import io.swagger.model.FederateGroupAssociation;
import io.swagger.model.FederateMissionPerConnectionSettings;
import io.swagger.model.FederationConfigInfo;
import io.swagger.model.FederationOutgoing;
import io.swagger.model.Filter;
import io.swagger.model.Group;
import io.swagger.model.IdAttachmentBody;
import io.swagger.model.InjectorConfig;
import io.swagger.model.Input;
import io.swagger.model.LogEntry;
import io.swagger.model.MapLayer;
import io.swagger.model.MessagingConfigInfo;
import io.swagger.model.MissionArchiveConfig;
import io.swagger.model.MissionContent;
import io.swagger.model.MissionSubscription;
import io.swagger.model.MissionsNameBody;
import io.swagger.model.ModelConfiguration;
import io.swagger.model.NameFileBody;
import io.swagger.model.NameSubmitBody;
import io.swagger.model.NameSubmitBody1;
import io.swagger.model.Profile;
import io.swagger.model.PropertiesUidBody;
import io.swagger.model.RemoteSubscription;
import io.swagger.model.SecurityConfigInfo;
import io.swagger.model.SubmitResultBody;
import io.swagger.model.TmpStaticSub;
import io.swagger.model.UidFilenameBody;
import io.swagger.model.VersionInfo;
import io.swagger.model.VideoCollections;
import io.swagger.model.VideoConnection;

import java.util.Map;
import java.util.List;
import io.swagger.api.NotFoundException;

import java.io.InputStream;

import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import javax.ws.rs.*;
import javax.inject.Inject;

import javax.validation.constraints.*;
@Path("/Marti")


@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaResteasyServerCodegen", date = "2023-02-27T14:50:33.119384066Z[GMT]")public class MartiApi  {

    @Inject MartiApiService service;

    @POST
    @Path("/api/citrap/{id}/attachment")
    @Consumes({ "application/json" })
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "ci-trap-report-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response addAttachment(@Parameter(description = "" ,required=true) IdAttachmentBody body, @NotNull  @QueryParam("clientUid") String clientUid, @PathParam("id") String id,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.addAttachment(body,clientUid,id,securityContext);
    }
    @PUT
    @Path("/api/missions/{name}/content/{hash}/keywords")
    @Consumes({ "application/json" })
    
    @Operation(summary = "", description = "", tags={ "mission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK") })
    public Response addContentKeyword(@Parameter(description = "" ,required=true) List<String> body, @PathParam("name") String name, @PathParam("hash") String hash,  @QueryParam("creatorUid") String creatorUid,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.addContentKeyword(body,name,hash,creatorUid,securityContext);
    }
    @PUT
    @Path("/api/excheck/checklist/{checklistUid}/task/{taskUid}")
    @Consumes({ "application/json" })
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "ex-check-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response addEditChecklistTask(@Parameter(description = "" ,required=true) String body, @NotNull  @QueryParam("clientUid") String clientUid, @PathParam("checklistUid") String checklistUid, @PathParam("taskUid") String taskUid,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.addEditChecklistTask(body,clientUid,checklistUid,taskUid,securityContext);
    }
    @PUT
    @Path("/api/excheck/template/{templateUid}/task/{taskUid}")
    @Consumes({ "application/json" })
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "ex-check-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response addEditTemplateTask(@Parameter(description = "" ,required=true) String body, @NotNull  @QueryParam("clientUid") String clientUid, @PathParam("templateUid") String templateUid, @PathParam("taskUid") String taskUid,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.addEditTemplateTask(body,clientUid,templateUid,taskUid,securityContext);
    }
    @POST
    @Path("/api/federatecagroups")
    @Consumes({ "application/json" })
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "federation-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseString.class))) })
    public Response addFederateCAGroup(@Parameter(description = "" ,required=true) FederateCAGroupAssociation body,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.addFederateCAGroup(body,securityContext);
    }
    @POST
    @Path("/api/federategroups")
    @Consumes({ "application/json" })
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "federation-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseString.class))) })
    public Response addFederateGroup(@Parameter(description = "" ,required=true) FederateGroupAssociation body,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.addFederateGroup(body,securityContext);
    }
    @POST
    @Path("/api/federategroupsmap/{federateId}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "federation-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseString.class))) })
    public Response addFederateGroupMap( @PathParam("federateId") String federateId, @NotNull  @QueryParam("remoteGroup") String remoteGroup, @NotNull  @QueryParam("localGroup") String localGroup,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.addFederateGroupMap(federateId,remoteGroup,localGroup,securityContext);
    }
    @POST
    @Path("/api/missions/{missionName}/feed")
    
    
    @Operation(summary = "", description = "", tags={ "mission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK") })
    public Response addFeed( @PathParam("missionName") String missionName, @NotNull  @QueryParam("creatorUid") String creatorUid, @NotNull  @QueryParam("dataFeedUid") String dataFeedUid,  @QueryParam("filterBbox") String filterBbox,  @QueryParam("filterType") String filterType,  @QueryParam("filterCallsign") String filterCallsign,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.addFeed(missionName,creatorUid,dataFeedUid,filterBbox,filterType,filterCallsign,securityContext);
    }
    @PUT
    @Path("/api/device/profile/{name}/file")
    @Consumes({ "application/json" })
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "profile-admin-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseProfileFile.class))) })
    public Response addFile(@Parameter(description = "" ,required=true) NameFileBody body, @NotNull  @QueryParam("filename") String filename, @PathParam("name") String name,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.addFile(body,filename,name,securityContext);
    }
    @PUT
    @Path("/api/missions/{name}/contents")
    @Consumes({ "application/json" })
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "mission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseSetMission.class))) })
    public Response addMissionContent(@Parameter(description = "" ,required=true) MissionContent body, @PathParam("name") String name,  @QueryParam("creatorUid") String creatorUid,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.addMissionContent(body,name,creatorUid,securityContext);
    }
    @PUT
    @Path("/api/missions/{name}/contents/missionpackage")
    @Consumes({ "application/json" })
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "mission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseListMissionChange.class))) })
    public Response addMissionPackage(@Parameter(description = "" ,required=true) ContentsMissionpackageBody body, @NotNull  @QueryParam("creatorUid") String creatorUid, @PathParam("name") String name,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.addMissionPackage(body,creatorUid,name,securityContext);
    }
    @PUT
    @Path("/api/excheck/checklist/{checklistUid}/mission/{missionName}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "ex-check-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response addMissionReferenceToChecklist( @PathParam("checklistUid") String checklistUid, @PathParam("missionName") String missionName, @NotNull  @QueryParam("clientUid") String clientUid,  @QueryParam("password") String password,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.addMissionReferenceToChecklist(checklistUid,missionName,clientUid,password,securityContext);
    }
    @POST
    @Path("/api/subscriptions/add")
    @Consumes({ "application/json" })
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "subscription-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseSubscriptionInfo.class))) })
    public Response addSubscription(@Parameter(description = "" ,required=true) TmpStaticSub body,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.addSubscription(body,securityContext);
    }
    @PUT
    @Path("/api/missions/{name}/uid/{uid}/keywords")
    @Consumes({ "application/json" })
    
    @Operation(summary = "", description = "", tags={ "mission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK") })
    public Response addUidKeyword(@Parameter(description = "" ,required=true) List<String> body, @PathParam("name") String name, @PathParam("uid") String uid,  @QueryParam("creatorUid") String creatorUid,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.addUidKeyword(body,name,uid,creatorUid,securityContext);
    }
    @POST
    @Path("/api/plugins/info/all/started")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "plugin-manager-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseBoolean.class))) })
    public Response changeAllPluginStartedStatus( @NotNull  @QueryParam("status") Boolean status,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.changeAllPluginStartedStatus(status,securityContext);
    }
    @POST
    @Path("/api/outgoingconnectionstatus/{name}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "federation-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseBoolean.class))) })
    public Response changeConnectionStatus( @PathParam("name") String name, @NotNull  @QueryParam("newStatus") Boolean newStatus,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.changeConnectionStatus(name,newStatus,securityContext);
    }
    @POST
    @Path("/api/plugins/info/archive")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "plugin-manager-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseBoolean.class))) })
    public Response changePluginArchiveSetting( @NotNull  @QueryParam("name") String name, @NotNull  @QueryParam("archiveEnabled") Boolean archiveEnabled,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.changePluginArchiveSetting(name,archiveEnabled,securityContext);
    }
    @POST
    @Path("/api/plugins/info/enabled")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "plugin-manager-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseBoolean.class))) })
    public Response changePluginEnabledSetting( @NotNull  @QueryParam("name") String name, @NotNull  @QueryParam("status") Boolean status,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.changePluginEnabledSetting(name,status,securityContext);
    }
    @POST
    @Path("/api/plugins/info/started")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "plugin-manager-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseBoolean.class))) })
    public Response changePluginStartedStatus( @NotNull  @QueryParam("name") String name, @NotNull  @QueryParam("status") Boolean status,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.changePluginStartedStatus(name,status,securityContext);
    }
    @DELETE
    @Path("/api/properties/{uid}/all")
    
    
    @Operation(summary = "", description = "", tags={ "properties-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK") })
    public Response clearAllProperty( @PathParam("uid") String uid,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.clearAllProperty(uid,securityContext);
    }
    @DELETE
    @Path("/api/missions/{name}/content/{hash}/keywords")
    
    
    @Operation(summary = "", description = "", tags={ "mission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK") })
    public Response clearContentKeywords( @PathParam("name") String name, @PathParam("hash") String hash,  @QueryParam("creatorUid") String creatorUid,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.clearContentKeywords(name,hash,creatorUid,securityContext);
    }
    @GET
    @Path("/api/clearFederationEvents")
    
    
    @Operation(summary = "", description = "", tags={ "federation-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK") })
    public Response clearDisruptionData(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.clearDisruptionData(securityContext);
    }
    @DELETE
    @Path("/api/missions/{name}/keywords")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "mission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseSetMission.class))) })
    public Response clearKeywords( @PathParam("name") String name,  @QueryParam("creatorUid") String creatorUid,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.clearKeywords(name,creatorUid,securityContext);
    }
    @DELETE
    @Path("/api/missions/{childName}/parent")
    
    
    @Operation(summary = "", description = "", tags={ "mission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK") })
    public Response clearParent( @PathParam("childName") String childName,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.clearParent(childName,securityContext);
    }
    @DELETE
    @Path("/api/properties/{uid}/{key}")
    
    
    @Operation(summary = "", description = "", tags={ "properties-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK") })
    public Response clearProperty( @PathParam("uid") String uid, @PathParam("key") String key,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.clearProperty(uid,key,securityContext);
    }
    @DELETE
    @Path("/api/missions/{name}/uid/{uid}/keywords")
    
    
    @Operation(summary = "", description = "", tags={ "mission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK") })
    public Response clearUidKeywords( @PathParam("name") String name, @PathParam("uid") String uid,  @QueryParam("creatorUid") String creatorUid,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.clearUidKeywords(name,uid,creatorUid,securityContext);
    }
    @PUT
    @Path("/api/missions/{missionName}/copy")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "mission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseSetMission.class))) })
    public Response copyMission( @PathParam("missionName") String missionName, @NotNull  @QueryParam("creatorUid") String creatorUid, @NotNull  @QueryParam("copyName") String copyName,  @QueryParam("copyPath") String copyPath,  @QueryParam("defaultRole") String defaultRole,  @QueryParam("password") String password,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.copyMission(missionName,creatorUid,copyName,copyPath,defaultRole,password,securityContext);
    }
    @POST
    @Path("/api/excheck/checklist")
    @Consumes({ "application/json" })
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "ex-check-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response createChecklist(@Parameter(description = "" ,required=true) String body, @NotNull  @QueryParam("clientUid") String clientUid,  @QueryParam("defaultRole") String defaultRole,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.createChecklist(body,clientUid,defaultRole,securityContext);
    }
    @POST
    @Path("/api/datafeeds")
    @Consumes({ "application/json" })
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "submission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseDataFeed.class))) })
    public Response createDataFeed(@Parameter(description = "" ,required=true) DataFeed body,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.createDataFeed(body,securityContext);
    }
    @POST
    @Path("/api/inputs")
    @Consumes({ "application/json" })
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "submission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseInput.class))) })
    public Response createInput(@Parameter(description = "" ,required=true) Input body,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.createInput(body,securityContext);
    }
    @POST
    @Path("/api/missions/{missionName}/maplayers")
    @Consumes({ "application/json" })
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "mission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseMapLayer.class))) })
    public Response createMapLayer(@Parameter(description = "" ,required=true) MapLayer body, @NotNull  @QueryParam("creatorUid") String creatorUid, @PathParam("missionName") String missionName,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.createMapLayer(body,creatorUid,missionName,securityContext);
    }
    @POST
    @Path("/api/maplayers")
    @Consumes({ "application/json" })
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "map-layers-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseMapLayer.class))) })
    public Response createMapLayer1(@Parameter(description = "" ,required=true) MapLayer body,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.createMapLayer1(body,securityContext);
    }
    @PUT
    @Path("/api/missions/{name}")
    @Consumes({ "application/json" })
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "mission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseSetMission.class))) })
    public Response createMission( @PathParam("name") String name,@Parameter(description = "" ) MissionsNameBody body,  @QueryParam("creatorUid") String creatorUid,  @DefaultValue("["__ANON__"]") @QueryParam("group") List<String> group,  @QueryParam("description") String description,  @QueryParam("chatRoom") String chatRoom,  @QueryParam("baseLayer") String baseLayer,  @QueryParam("bbox") String bbox,  @DefaultValue("[]") @QueryParam("boundingPolygon") List<String> boundingPolygon,  @QueryParam("path") String path,  @QueryParam("classification") String classification,  @DefaultValue("public") @QueryParam("tool") String tool,  @QueryParam("password") String password,  @QueryParam("defaultRole") String defaultRole,  @QueryParam("expiration") Long expiration,  @DefaultValue("false") @QueryParam("inviteOnly") Boolean inviteOnly,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.createMission(name,body,creatorUid,group,description,chatRoom,baseLayer,bbox,boundingPolygon,path,classification,tool,password,defaultRole,expiration,inviteOnly,securityContext);
    }
    @PUT
    @Path("/api/missions/{missionName}/subscription")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "mission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "201", description = "Created", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseMissionSubscription.class))) })
    public Response createMissionSubscription( @PathParam("missionName") String missionName,  @QueryParam("uid") String uid,  @QueryParam("topic") String topic,  @QueryParam("password") String password,  @QueryParam("secago") Long secago,  @QueryParam("start") Date start,  @QueryParam("end") Date end,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.createMissionSubscription(missionName,uid,topic,password,secago,start,end,securityContext);
    }
    @POST
    @Path("/api/outgoingconnections")
    @Consumes({ "application/json" })
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "federation-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseFederationOutgoing.class))) })
    public Response createOutgoingConnection(@Parameter(description = "" ,required=true) FederationOutgoing body,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.createOutgoingConnection(body,securityContext);
    }
    @POST
    @Path("/api/device/profile/{name}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "profile-admin-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response createProfile( @PathParam("name") String name,  @DefaultValue("[]") @QueryParam("group") List<String> group,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.createProfile(name,group,securityContext);
    }
    @POST
    @Path("/api/video")
    @Consumes({ "application/json" })
    
    @Operation(summary = "", description = "", tags={ "video-connection-manager-v-2" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK") })
    public Response createVideoConnection(@Parameter(description = "" ,required=true) VideoCollections body,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.createVideoConnection(body,securityContext);
    }
    @DELETE
    @Path("/api/caveat/{name}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "classification-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseLong.class))) })
    public Response deleteCaveat( @PathParam("name") String name,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.deleteCaveat(name,securityContext);
    }
    @DELETE
    @Path("/api/certadmin/cert/delete/{ids}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "cert-manager-admin-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response deleteCertificates( @PathParam("ids") String ids,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.deleteCertificates(ids,securityContext);
    }
    @DELETE
    @Path("/api/excheck/checklist/{checklistUid}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "ex-check-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response deleteChecklist( @PathParam("checklistUid") String checklistUid, @NotNull  @QueryParam("clientUid") String clientUid,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.deleteChecklist(checklistUid,clientUid,securityContext);
    }
    @DELETE
    @Path("/api/excheck/checklist/{checklistUid}/task/{taskUid}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "ex-check-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response deleteChecklistTask( @PathParam("checklistUid") String checklistUid, @PathParam("taskUid") String taskUid, @NotNull  @QueryParam("clientUid") String clientUid,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.deleteChecklistTask(checklistUid,taskUid,clientUid,securityContext);
    }
    @DELETE
    @Path("/api/classification/{level}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "classification-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseLong.class))) })
    public Response deleteClassification( @PathParam("level") String level,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.deleteClassification(level,securityContext);
    }
    @DELETE
    @Path("/api/datafeeds/{name}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "submission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseDataFeed.class))) })
    public Response deleteDataFeed( @PathParam("name") String name,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.deleteDataFeed(name,securityContext);
    }
    @DELETE
    @Path("/api/device/profile/{name}/directories")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "profile-admin-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response deleteDirectories( @PathParam("name") String name,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.deleteDirectories(name,securityContext);
    }
    @DELETE
    @Path("/api/missions/{name}/externaldata/{id}")
    
    
    @Operation(summary = "", description = "", tags={ "mission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK") })
    public Response deleteExternalMissionData( @PathParam("name") String name, @PathParam("id") String id, @NotNull  @QueryParam("notes") String notes, @NotNull  @QueryParam("creatorUid") String creatorUid,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.deleteExternalMissionData(name,id,notes,creatorUid,securityContext);
    }
    @DELETE
    @Path("/api/federatedetails/{federateId}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "federation-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseBoolean.class))) })
    public Response deleteFederate( @PathParam("federateId") String federateId,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.deleteFederate(federateId,securityContext);
    }
    @DELETE
    @Path("/api/federatecertificates/{fingerprint}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "federation-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseString.class))) })
    public Response deleteFederateCertificateCA( @PathParam("fingerprint") String fingerprint,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.deleteFederateCertificateCA(fingerprint,securityContext);
    }
    @DELETE
    @Path("/api/device/profile/{name}/file/{id}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "profile-admin-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response deleteFile( @PathParam("name") String name, @PathParam("id") Long id,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.deleteFile(name,id,securityContext);
    }
    @DELETE
    @Path("/api/subscriptions/{clientUid}/filter")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "subscription-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response deleteFilter( @PathParam("clientUid") String clientUid,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.deleteFilter(clientUid,securityContext);
    }
    @DELETE
    @Path("/api/plugins/{name}/submit")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "plugin-data-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseString.class))) })
    public Response deleteFromPlugin( @PathParam("name") String name, @NotNull  @QueryParam("allRequestParams") Map<String, String> allRequestParams,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.deleteFromPlugin(name,allRequestParams,securityContext);
    }
    @DELETE
    @Path("/api/injectors/cot/uid")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "injection-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseSetInjectorConfig.class))) })
    public Response deleteInjector( @NotNull  @QueryParam("uid") String uid, @NotNull  @QueryParam("toInject") String toInject,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.deleteInjector(uid,toInject,securityContext);
    }
    @DELETE
    @Path("/api/inputs/{name}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "submission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseInput.class))) })
    public Response deleteInput( @PathParam("name") String name,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.deleteInput(name,securityContext);
    }
    @DELETE
    @Path("/api/missions/logs/entries/{id}")
    
    
    @Operation(summary = "", description = "", tags={ "mission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK") })
    public Response deleteLogEntry( @PathParam("id") String id,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.deleteLogEntry(id,securityContext);
    }
    @DELETE
    @Path("/api/missions/{missionName}/maplayers/{uid}")
    
    
    @Operation(summary = "", description = "", tags={ "mission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK") })
    public Response deleteMapLayer( @PathParam("missionName") String missionName, @NotNull  @QueryParam("creatorUid") String creatorUid, @PathParam("uid") String uid,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.deleteMapLayer(missionName,creatorUid,uid,securityContext);
    }
    @DELETE
    @Path("/api/maplayers/{uid}")
    
    
    @Operation(summary = "", description = "", tags={ "map-layers-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK") })
    public Response deleteMapLayer1( @PathParam("uid") String uid,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.deleteMapLayer1(uid,securityContext);
    }
    @DELETE
    @Path("/api/missions/{name}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "mission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseSetMission.class))) })
    public Response deleteMission( @PathParam("name") String name,  @QueryParam("creatorUid") String creatorUid,  @DefaultValue("false") @QueryParam("deepDelete") Boolean deepDelete,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.deleteMission(name,creatorUid,deepDelete,securityContext);
    }
    @DELETE
    @Path("/api/missions/{missionName}/subscription")
    
    
    @Operation(summary = "", description = "", tags={ "mission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK") })
    public Response deleteMissionSubscription( @PathParam("missionName") String missionName,  @QueryParam("uid") String uid,  @QueryParam("topic") String topic,  @DefaultValue("true") @QueryParam("disconnectOnly") Boolean disconnectOnly,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.deleteMissionSubscription(missionName,uid,topic,disconnectOnly,securityContext);
    }
    @DELETE
    @Path("/api/outgoingconnections/{name}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "federation-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseBoolean.class))) })
    public Response deleteOutgoingConnection( @PathParam("name") String name,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.deleteOutgoingConnection(name,securityContext);
    }
    @DELETE
    @Path("/api/device/profile/{id}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "profile-admin-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response deleteProfile( @PathParam("id") Long id,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.deleteProfile(id,securityContext);
    }
    @DELETE
    @Path("/api/citrap/{id}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "ci-trap-report-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response deleteReport( @PathParam("id") String id, @NotNull  @QueryParam("clientUid") String clientUid,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.deleteReport(id,clientUid,securityContext);
    }
    @DELETE
    @Path("/api/subscriptions/delete/{uid}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "subscription-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseString.class))) })
    public Response deleteSubscription( @PathParam("uid") String uid,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.deleteSubscription(uid,securityContext);
    }
    @DELETE
    @Path("/api/excheck/template/{templateUid}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "ex-check-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response deleteTemplate( @PathParam("templateUid") String templateUid, @NotNull  @QueryParam("clientUid") String clientUid,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.deleteTemplate(templateUid,clientUid,securityContext);
    }
    @DELETE
    @Path("/api/excheck/template/{templateUid}/task/{taskUid}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "ex-check-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response deleteTemplateTask( @PathParam("templateUid") String templateUid, @PathParam("taskUid") String taskUid, @NotNull  @QueryParam("clientUid") String clientUid,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.deleteTemplateTask(templateUid,taskUid,clientUid,securityContext);
    }
    @DELETE
    @Path("/api/video/{uid}")
    
    
    @Operation(summary = "", description = "", tags={ "video-connection-manager-v-2" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK") })
    public Response deleteVideoConnection( @PathParam("uid") String uid,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.deleteVideoConnection(uid,securityContext);
    }
    @GET
    @Path("/api/device/profile/tool/{toolName}/file")
    
    
    @Operation(summary = "", description = "", tags={ "profile-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK") })
    public Response deviceGetProfileDirectoryContent( @PathParam("toolName") String toolName, @NotNull  @QueryParam("relativePath") List<String> relativePath, @NotNull  @QueryParam("clientUid") String clientUid,  @DefaultValue("-1") @QueryParam("syncSecago") Long syncSecago,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.deviceGetProfileDirectoryContent(toolName,relativePath,clientUid,syncSecago,securityContext);
    }
    @PUT
    @Path("/api/inputs/storeForwardChat/disable")
    
    
    @Operation(summary = "", description = "", tags={ "submission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK") })
    public Response disableStoreForwardChat(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.disableStoreForwardChat(securityContext);
    }
    @GET
    @Path("/api/certadmin/cert/{hash}/download")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "cert-manager-admin-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response downloadCertificate( @PathParam("hash") String hash,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.downloadCertificate(hash,securityContext);
    }
    @GET
    @Path("/api/certadmin/cert/download/{ids}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "cert-manager-admin-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", array = @ArraySchema(schema = @Schema(implementation = byte[].class)))) })
    public Response downloadCertificates( @PathParam("ids") String ids,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.downloadCertificates(ids,securityContext);
    }
    @PUT
    @Path("/api/qos/dos/enable")
    @Consumes({ "application/json" })
    
    @Operation(summary = "", description = "", tags={ "qo-s-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK") })
    public Response enableDOS(@Parameter(description = "" ,required=true) Boolean body,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.enableDOS(body,securityContext);
    }
    @PUT
    @Path("/api/qos/delivery/enable")
    @Consumes({ "application/json" })
    
    @Operation(summary = "", description = "", tags={ "qo-s-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK") })
    public Response enableDelivery(@Parameter(description = "" ,required=true) Boolean body,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.enableDelivery(body,securityContext);
    }
    @PUT
    @Path("/api/qos/read/enable")
    @Consumes({ "application/json" })
    
    @Operation(summary = "", description = "", tags={ "qo-s-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK") })
    public Response enableRead(@Parameter(description = "" ,required=true) Boolean body,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.enableRead(body,securityContext);
    }
    @PUT
    @Path("/api/inputs/storeForwardChat/enable")
    
    
    @Operation(summary = "", description = "", tags={ "submission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK") })
    public Response enableStoreForwardChat(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.enableStoreForwardChat(securityContext);
    }
    @GET
    @Path("/api/token/access")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "token-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseString.class))) })
    public Response getAccessToken(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getAccessToken(securityContext);
    }
    @GET
    @Path("/api/certadmin/cert/active")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "cert-manager-admin-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseListTakCert.class))) })
    public Response getActive(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getActive(securityContext);
    }
    @GET
    @Path("/api/activeconnections")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "federation-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseListConnectionInfoSummary.class))) })
    public Response getActiveConnections(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getActiveConnections(securityContext);
    }
    @GET
    @Path("/api/qos/ratelimit/dos/active")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "qo-s-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseEntryIntegerInteger.class))) })
    public Response getActiveDOSRateLimit(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getActiveDOSRateLimit(securityContext);
    }
    @GET
    @Path("/api/qos/ratelimit/delivery/active")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "qo-s-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseEntryIntegerInteger.class))) })
    public Response getActiveDeliveryRateLimit(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getActiveDeliveryRateLimit(securityContext);
    }
    @GET
    @Path("/api/qos/ratelimit/read/active")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "qo-s-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseEntryIntegerInteger.class))) })
    public Response getActiveReadRateLimit(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getActiveReadRateLimit(securityContext);
    }
    @GET
    @Path("/api/token")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "token-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseListTokenResult.class))) })
    public Response getAll(  @DefaultValue("false") @QueryParam("expired") Boolean expired,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getAll(expired,securityContext);
    }
    @GET
    @Path("/api/certadmin/cert")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "cert-manager-admin-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseListTakCert.class))) })
    public Response getAll1(  @QueryParam("username") String username,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getAll1(username,securityContext);
    }
    @GET
    @Path("/api/caveat")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "classification-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseListCaveat.class))) })
    public Response getAllCaveat(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getAllCaveat(securityContext);
    }
    @GET
    @Path("/api/classification")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "classification-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseListClassification.class))) })
    public Response getAllClassifications(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getAllClassifications(securityContext);
    }
    @GET
    @Path("/api/contacts/all")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "contacts-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", array = @ArraySchema(schema = @Schema(implementation = RemoteSubscription.class)))) })
    public Response getAllContacts(  @DefaultValue("CALLSIGN") @QueryParam("sortBy") String sortBy,  @DefaultValue("ASCENDING") @QueryParam("direction") String direction,  @DefaultValue("false") @QueryParam("noFederates") Boolean noFederates,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getAllContacts(sortBy,direction,noFederates,securityContext);
    }
    @GET
    @Path("/api/cops")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "cop-view-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseListMission.class))) })
    public Response getAllCopMissions(  @QueryParam("path") String path,  @QueryParam("offset") Integer offset,  @QueryParam("size") Integer size,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getAllCopMissions(path,offset,size,securityContext);
    }
    @GET
    @Path("/api/cot/xml/{uid}/all")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "cot-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response getAllCotEvents( @PathParam("uid") String uid,  @QueryParam("secago") Long secago,  @QueryParam("start") Date start,  @QueryParam("end") Date end,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getAllCotEvents(uid,secago,start,end,securityContext);
    }
    @GET
    @Path("/api/injectors/cot/uid")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "injection-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseSetInjectorConfig.class))) })
    public Response getAllCotInjectors(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getAllCotInjectors(securityContext);
    }
    @GET
    @Path("/api/groups/all")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "groups-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseCollectionGroup.class))) })
    public Response getAllGroups(  @DefaultValue("false") @QueryParam("useCache") Boolean useCache,  @DefaultValue("false") @QueryParam("sendLatestSA") Boolean sendLatestSA,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getAllGroups(useCache,sendLatestSA,securityContext);
    }
    @GET
    @Path("/api/iconseturl/{uid}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "iconset-icon-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseListString.class))) })
    public Response getAllIconUrlsForIconset( @PathParam("uid") String uid,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getAllIconUrlsForIconset(uid,securityContext);
    }
    @GET
    @Path("/api/iconset/all/uid")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "iconset-icon-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseSetString.class))) })
    public Response getAllIconsetUids(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getAllIconsetUids(securityContext);
    }
    @GET
    @Path("/api/missions/all/logs")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "mission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseListLogEntry.class))) })
    public Response getAllLogEntries(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getAllLogEntries(securityContext);
    }
    @GET
    @Path("/api/maplayers/all")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "map-layers-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseCollectionMapLayer.class))) })
    public Response getAllMapLayers(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getAllMapLayers(securityContext);
    }
    @GET
    @Path("/api/missions/all/invitations")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "mission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseSetString.class))) })
    public Response getAllMissionInvitations(  @QueryParam("clientUid") String clientUid,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getAllMissionInvitations(clientUid,securityContext);
    }
    @GET
    @Path("/api/missions/invitations")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "mission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseSetMissionInvitation.class))) })
    public Response getAllMissionInvitationsWithPasswords( @NotNull  @QueryParam("clientUid") String clientUid,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getAllMissionInvitationsWithPasswords(clientUid,securityContext);
    }
    @GET
    @Path("/api/missions/all/subscriptions")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "mission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseListEntryStringString.class))) })
    public Response getAllMissionSubscriptions(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getAllMissionSubscriptions(securityContext);
    }
    @GET
    @Path("/api/missions")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "mission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseListMission.class))) })
    public Response getAllMissions(  @DefaultValue("false") @QueryParam("passwordProtected") Boolean passwordProtected,  @DefaultValue("false") @QueryParam("defaultRole") Boolean defaultRole,  @QueryParam("tool") String tool,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getAllMissions(passwordProtected,defaultRole,tool,securityContext);
    }
    @GET
    @Path("/api/plugins/info/all")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "plugin-manager-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseCollectionPluginInfo.class))) })
    public Response getAllPluginInfo(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getAllPluginInfo(securityContext);
    }
    @GET
    @Path("/api/device/profile")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "profile-admin-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseListProfile.class))) })
    public Response getAllProfile(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getAllProfile(securityContext);
    }
    @GET
    @Path("/api/properties/{uid}/all")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "properties-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseMapStringCollectionString.class))) })
    public Response getAllPropertyForUid( @PathParam("uid") String uid,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getAllPropertyForUid(uid,securityContext);
    }
    @GET
    @Path("/api/properties/uids")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "properties-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseCollectionString.class))) })
    public Response getAllPropertyKeys(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getAllPropertyKeys(securityContext);
    }
    @GET
    @Path("/api")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "cot-query-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseListCotSearch.class))) })
    public Response getAllSearches(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getAllSearches(securityContext);
    }
    @GET
    @Path("/api/subscriptions/all")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "subscription-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseSetSubscriptionInfo.class))) })
    public Response getAllSubscriptions(  @DefaultValue("CALLSIGN") @QueryParam("sortBy") String sortBy,  @DefaultValue("ASCENDING") @QueryParam("direction") String direction,  @DefaultValue("-1") @QueryParam("page") Integer page,  @DefaultValue("-1") @QueryParam("limit") Integer limit,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getAllSubscriptions(sortBy,direction,page,limit,securityContext);
    }
    @GET
    @Path("/api/users/all")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "groups-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseSortedSetUser.class))) })
    public Response getAllUsers2(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getAllUsers2(securityContext);
    }
    @GET
    @Path("/api/authentication/config")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "security-authentication-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseAuthenticationConfigInfo.class))) })
    public Response getAuthConfig(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getAuthConfig(securityContext);
    }
    @GET
    @Path("/api/cachedConfig")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "config-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ModelConfiguration.class))) })
    public Response getCachedCoreConfig(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getCachedCoreConfig(securityContext);
    }
    @GET
    @Path("/api/cachedInputConfig")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "config-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", array = @ArraySchema(schema = @Schema(implementation = Input.class)))) })
    public Response getCachedInputConfig(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getCachedInputConfig(securityContext);
    }
    @GET
    @Path("/api/certadmin/cert/{hash}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "cert-manager-admin-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseTakCert.class))) })
    public Response getCertificate( @PathParam("hash") String hash,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getCertificate(hash,securityContext);
    }
    @GET
    @Path("/api/excheck/checklist/{checklistUid}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "ex-check-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response getChecklist( @PathParam("checklistUid") String checklistUid,  @QueryParam("clientUid") String clientUid,  @QueryParam("secago") Long secago,  @QueryParam("token") String token,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getChecklist(checklistUid,clientUid,secago,token,securityContext);
    }
    @GET
    @Path("/api/excheck/checklist/active")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "ex-check-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response getChecklist1( @NotNull  @QueryParam("clientUid") String clientUid,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getChecklist1(clientUid,securityContext);
    }
    @GET
    @Path("/api/excheck/checklist/{checklistUid}/status")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "ex-check-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response getChecklistStatus( @PathParam("checklistUid") String checklistUid,  @QueryParam("token") String token,  @QueryParam("clientUid") String clientUid,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getChecklistStatus(checklistUid,token,clientUid,securityContext);
    }
    @GET
    @Path("/api/excheck/checklist/{checklistUid}/task/{taskUid}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "ex-check-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response getChecklistTask( @PathParam("checklistUid") String checklistUid, @PathParam("taskUid") String taskUid, @NotNull  @QueryParam("clientUid") String clientUid,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getChecklistTask(checklistUid,taskUid,clientUid,securityContext);
    }
    @GET
    @Path("/api/missions/{name}/children")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "mission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseSetMission.class))) })
    public Response getChildren( @PathParam("name") String name,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getChildren(name,securityContext);
    }
    @GET
    @Path("/api/classification/{level}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "classification-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseClassification.class))) })
    public Response getClassificationForLevel( @PathParam("level") String level,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getClassificationForLevel(level,securityContext);
    }
    @GET
    @Path("/api/clientEndPoints")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "contact-manager-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseListClientEndpoint.class))) })
    public Response getClientEndpoints(  @DefaultValue("0") @QueryParam("secAgo") Long secAgo,  @DefaultValue("false") @QueryParam("showCurrentlyConnectedClients") String showCurrentlyConnectedClients,  @DefaultValue("false") @QueryParam("showMostRecentOnly") String showMostRecentOnly,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getClientEndpoints(secAgo,showCurrentlyConnectedClients,showMostRecentOnly,securityContext);
    }
    @GET
    @Path("/api/tls/config")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "cert-manager-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response getConfig(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getConfig(securityContext);
    }
    @GET
    @Path("/api/inputs/config")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "submission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseMessagingConfigInfo.class))) })
    public Response getConfigInfo(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getConfigInfo(securityContext);
    }
    @GET
    @Path("/api/outgoingconnectionstatus/{name}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "federation-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseConnectionStatus.class))) })
    public Response getConnectionStatus( @PathParam("name") String name,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getConnectionStatus(name,securityContext);
    }
    @GET
    @Path("/api/device/profile/connection")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "profile-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", array = @ArraySchema(schema = @Schema(implementation = byte[].class)))) })
    public Response getConnectionTimeProfiles( @NotNull  @QueryParam("syncSecago") Long syncSecago, @NotNull  @QueryParam("clientUid") String clientUid,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getConnectionTimeProfiles(syncSecago,clientUid,securityContext);
    }
    @GET
    @Path("/api/config")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "config-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ModelConfiguration.class))) })
    public Response getCoreConfig(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getCoreConfig(securityContext);
    }
    @GET
    @Path("/api/cot/xml/{uid}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "cot-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response getCotEvent( @PathParam("uid") String uid,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getCotEvent(uid,securityContext);
    }
    @GET
    @Path("/api/cot")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "cot-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response getCotEvents( @NotNull  @QueryParam("uids") List<String> uids,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getCotEvents(uids,securityContext);
    }
    @GET
    @Path("/api/cot/sa")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "cot-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response getCotEventsByTimeAndBbox( @NotNull  @QueryParam("start") Date start, @NotNull  @QueryParam("end") Date end,  @QueryParam("left") Double left,  @QueryParam("bottom") Double bottom,  @QueryParam("right") Double right,  @QueryParam("top") Double top,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getCotEventsByTimeAndBbox(start,end,left,bottom,right,top,securityContext);
    }
    @GET
    @Path("/api/datafeeds/{name}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "submission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseDataFeed.class))) })
    public Response getDataFeed( @PathParam("name") String name,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getDataFeed(name,securityContext);
    }
    @GET
    @Path("/api/datafeeds")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "submission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseListDataFeed.class))) })
    public Response getDataFeeds(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getDataFeeds(securityContext);
    }
    @GET
    @Path("/api/database/cotCount")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "submission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseMapStringInteger.class))) })
    public Response getDatabaseCotCounts(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getDatabaseCotCounts(securityContext);
    }
    @GET
    @Path("/api/cot/search/date")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "cot-query-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = Date.class))) })
    public Response getDate(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getDate(securityContext);
    }
    @GET
    @Path("/api/device/profile/{name}/directories")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "profile-admin-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseListProfileDirectory.class))) })
    public Response getDirectories( @PathParam("name") String name,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getDirectories(name,securityContext);
    }
    @GET
    @Path("/api/tls/profile/enrollment")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "profile-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", array = @ArraySchema(schema = @Schema(implementation = byte[].class)))) })
    public Response getEnrollmentTimeProfiles( @NotNull  @QueryParam("clientUid") String clientUid,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getEnrollmentTimeProfiles(clientUid,securityContext);
    }
    @GET
    @Path("/api/certadmin/cert/expired")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "cert-manager-admin-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseListTakCert.class))) })
    public Response getExpired(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getExpired(securityContext);
    }
    @GET
    @Path("/api/federatecagroups/{caId}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "federation-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseListFederateCAGroupAssociation.class))) })
    public Response getFederateCAGroups( @PathParam("caId") String caId,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getFederateCAGroups(caId,securityContext);
    }
    @GET
    @Path("/api/federatecertificates")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "federation-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseListCertificateSummary.class))) })
    public Response getFederateCertificates(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getFederateCertificates(securityContext);
    }
    @GET
    @Path("/api/federatecontacts/{federateId}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "federation-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseSortedSetRemoteContact.class))) })
    public Response getFederateContacts( @PathParam("federateId") String federateId,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getFederateContacts(federateId,securityContext);
    }
    @GET
    @Path("/api/federatedetails/{id}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "federation-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseFederate.class))) })
    public Response getFederateDetails( @PathParam("id") String id,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getFederateDetails(id,securityContext);
    }
    @GET
    @Path("/api/federategroups/{federateId}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "federation-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseListFederateGroupAssociation.class))) })
    public Response getFederateGroups( @PathParam("federateId") String federateId,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getFederateGroups(federateId,securityContext);
    }
    @GET
    @Path("/api/federategroupsmap/{federateId}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "federation-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseMapStringString.class))) })
    public Response getFederateGroupsMap( @PathParam("federateId") String federateId,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getFederateGroupsMap(federateId,securityContext);
    }
    @GET
    @Path("/api/federateremotegroups/{federateId}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "federation-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseListString.class))) })
    public Response getFederateRemoteGroups( @PathParam("federateId") String federateId,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getFederateRemoteGroups(federateId,securityContext);
    }
    @GET
    @Path("/api/federates")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "federation-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseSortedSetFederate.class))) })
    public Response getFederates(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getFederates(securityContext);
    }
    @GET
    @Path("/api/federationconfig")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "federation-config-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseFederationConfigInfo.class))) })
    public Response getFederationConfig(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getFederationConfig(securityContext);
    }
    @GET
    @Path("/api/xmpp/transfer/{uid}/{filename}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "xmpp-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response getFile( @PathParam("uid") String uid, @PathParam("filename") String filename,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getFile(uid,filename,securityContext);
    }
    @GET
    @Path("/api/device/profile/{name}/file/{id}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "profile-admin-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", array = @ArraySchema(schema = @Schema(implementation = byte[].class)))) })
    public Response getFile1( @PathParam("name") String name, @PathParam("id") Long id,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getFile1(name,id,securityContext);
    }
    @GET
    @Path("/api/device/profile/{name}/files")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "profile-admin-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseListProfileFile.class))) })
    public Response getFiles( @PathParam("name") String name,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getFiles(name,securityContext);
    }
    @GET
    @Path("/api/groups/{name}/{direction}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "groups-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseGroup.class))) })
    public Response getGroup( @PathParam("name") String name, @PathParam("direction") String direction,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getGroup(name,direction,securityContext);
    }
    @GET
    @Path("/api/groups/groupCacheEnabled")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "groups-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseBoolean.class))) })
    public Response getGroupCacheEnabled(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getGroupCacheEnabled(securityContext);
    }
    @GET
    @Path("/api/groupprefix")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "ldap-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseString.class))) })
    public Response getGroupPrefix(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getGroupPrefix(securityContext);
    }
    @GET
    @Path("/api/cops/hierarchy")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "cop-view-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseSetCopHierarchyNode.class))) })
    public Response getHierarchy(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getHierarchy(securityContext);
    }
    @GET
    @Path("/api/home")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "home-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response getHome(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getHome(securityContext);
    }
    @GET
    @Path("/api/icon/{uid}/{group}/{name}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "iconset-icon-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", array = @ArraySchema(schema = @Schema(implementation = byte[].class)))) })
    public Response getIcon( @PathParam("uid") String uid, @PathParam("group") String group, @PathParam("name") String name,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getIcon(uid,group,name,securityContext);
    }
    @GET
    @Path("/api/iconimage")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "iconset-icon-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", array = @ArraySchema(schema = @Schema(implementation = byte[].class)))) })
    public Response getIconImage(  @QueryParam("iconsetpath") String iconsetpath,  @QueryParam("cotType") String cotType,  @QueryParam("medevac") Boolean medevac,  @QueryParam("groupName") String groupName,  @QueryParam("role") String role,  @QueryParam("color") Long color,  @QueryParam("relative") Boolean relative,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getIconImage(iconsetpath,cotType,medevac,groupName,role,color,relative,securityContext);
    }
    @GET
    @Path("/api/iconurl")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "iconset-icon-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response getIconUrl(  @QueryParam("iconsetpath") String iconsetpath,  @QueryParam("cotType") String cotType,  @QueryParam("medevac") Boolean medevac,  @QueryParam("groupName") String groupName,  @QueryParam("role") String role,  @QueryParam("color") Long color,  @QueryParam("relative") Boolean relative,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getIconUrl(iconsetpath,cotType,medevac,groupName,role,color,relative,securityContext);
    }
    @GET
    @Path("/api/inputs/{name}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "submission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseInputMetric.class))) })
    public Response getInputMetric( @PathParam("name") String name,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getInputMetric(name,securityContext);
    }
    @GET
    @Path("/api/inputs")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "submission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseSortedSetInputMetric.class))) })
    public Response getInputMetrics(  @DefaultValue("false") @QueryParam("excludeDataFeeds") Boolean excludeDataFeeds,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getInputMetrics(excludeDataFeeds,securityContext);
    }
    @GET
    @Path("/api/missions/{name}/kml")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "mission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response getKml( @PathParam("name") String name,  @DefaultValue("false") @QueryParam("download") Boolean download,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getKml(name,download,securityContext);
    }
    @GET
    @Path("/api/missions/{name}/cot")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "mission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response getLatestMissionCotEvents( @PathParam("name") String name,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getLatestMissionCotEvents(name,securityContext);
    }
    @GET
    @Path("/api/groups/members")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "ldap-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseInteger.class))) })
    public Response getLdapGroupMembers( @NotNull  @QueryParam("groupNameFilter") List<String> groupNameFilter,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getLdapGroupMembers(groupNameFilter,securityContext);
    }
    @GET
    @Path("/api/groups")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "ldap-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseSortedSetLdapGroup.class))) })
    public Response getLdapGroups( @NotNull  @QueryParam("groupNameFilter") String groupNameFilter,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getLdapGroups(groupNameFilter,securityContext);
    }
    @GET
    @Path("/api/repeater/list")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "repeater-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseListRepeatable.class))) })
    public Response getList(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getList(securityContext);
    }
    @GET
    @Path("/api/missions/{missionName}/log")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "mission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseListLogEntry.class))) })
    public Response getLogEntry( @PathParam("missionName") String missionName,  @QueryParam("secago") Long secago,  @QueryParam("start") Date start,  @QueryParam("end") Date end,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getLogEntry(missionName,secago,start,end,securityContext);
    }
    @GET
    @Path("/api/maplayers/{uid}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "map-layers-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseMapLayer.class))) })
    public Response getMapLayerForUid( @PathParam("uid") String uid,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getMapLayerForUid(uid,securityContext);
    }
    @GET
    @Path("/api/missions/{name}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "mission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseSetMission.class))) })
    public Response getMission( @PathParam("name") String name,  @QueryParam("password") String password,  @DefaultValue("false") @QueryParam("changes") Boolean changes,  @DefaultValue("false") @QueryParam("logs") Boolean logs,  @QueryParam("secago") Long secago,  @QueryParam("start") Date start,  @QueryParam("end") Date end,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getMission(name,password,changes,logs,secago,start,end,securityContext);
    }
    @GET
    @Path("/api/retention/missionarchive")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "retention-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseString.class))) })
    public Response getMissionArchive(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getMissionArchive(securityContext);
    }
    @GET
    @Path("/api/missions/{name}/archive")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "mission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", array = @ArraySchema(schema = @Schema(implementation = byte[].class)))) })
    public Response getMissionArchive1( @PathParam("name") String name,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getMissionArchive1(name,securityContext);
    }
    @GET
    @Path("/api/retention/missionarchiveconfig")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "retention-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseMissionArchiveConfig.class))) })
    public Response getMissionArchiveConfig(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getMissionArchiveConfig(securityContext);
    }
    @GET
    @Path("/api/missions/{name}/changes")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "mission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseSetMissionChange.class))) })
    public Response getMissionChanges( @PathParam("name") String name,  @QueryParam("secago") Long secago,  @QueryParam("start") Date start,  @QueryParam("end") Date end,  @DefaultValue("true") @QueryParam("squashed") Boolean squashed,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getMissionChanges(name,secago,start,end,squashed,securityContext);
    }
    @GET
    @Path("/api/missions/{missionName}/invitations")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "mission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseListMissionInvitation.class))) })
    public Response getMissionInvitations( @PathParam("missionName") String missionName,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getMissionInvitations(missionName,securityContext);
    }
    @GET
    @Path("/api/missions/{missionName}/role")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "mission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseMissionRole.class))) })
    public Response getMissionRoleFromToken( @PathParam("missionName") String missionName,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getMissionRoleFromToken(missionName,securityContext);
    }
    @GET
    @Path("/api/missions/{missionName}/subscriptions/roles")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "mission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseListMissionSubscription.class))) })
    public Response getMissionSubscriptionRoles( @PathParam("missionName") String missionName,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getMissionSubscriptionRoles(missionName,securityContext);
    }
    @GET
    @Path("/api/missions/{missionName}/subscriptions")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "mission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseListString.class))) })
    public Response getMissionSubscriptions( @PathParam("missionName") String missionName,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getMissionSubscriptions(missionName,securityContext);
    }
    @GET
    @Path("/api/sync/sequence/{key}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "sequence-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response getNextInSequence( @PathParam("key") String key,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getNextInSequence(key,securityContext);
    }
    @GET
    @Path("/api/node/id")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "version-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response getNodeId(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getNodeId(securityContext);
    }
    @GET
    @Path("/api/fednum")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "federation-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = Integer.class))) })
    public Response getNum(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getNum(securityContext);
    }
    @GET
    @Path("/api/injectors/cot/uid/{uid}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "injection-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseCollectionInjectorConfig.class))) })
    public Response getOneCotInjector( @PathParam("uid") String uid,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getOneCotInjector(uid,securityContext);
    }
    @GET
    @Path("/api/missions/logs/entries/{id}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "mission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseListLogEntry.class))) })
    public Response getOneLogEntry( @PathParam("id") String id,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getOneLogEntry(id,securityContext);
    }
    @GET
    @Path("/api/outgoingconnections/{name}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "federation-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseFederationOutgoing.class))) })
    public Response getOutgoingConnection( @PathParam("name") String name,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getOutgoingConnection(name,securityContext);
    }
    @GET
    @Path("/api/outgoingconnections")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "federation-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseSortedSetOutgoingConnectionSummary.class))) })
    public Response getOutgoingConnections(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getOutgoingConnections(securityContext);
    }
    @GET
    @Path("/api/missions/{name}/parent")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "mission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseMission.class))) })
    public Response getParent( @PathParam("name") String name,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getParent(name,securityContext);
    }
    @GET
    @Path("/api/repeater/period")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "repeater-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseInteger.class))) })
    public Response getPeriod(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getPeriod(securityContext);
    }
    @GET
    @Path("/api/device/profile/{name}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "profile-admin-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseProfile.class))) })
    public Response getProfile( @PathParam("name") String name,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getProfile(name,securityContext);
    }
    @GET
    @Path("/api/device/profile/{name}/missionpackage")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "profile-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", array = @ArraySchema(schema = @Schema(implementation = byte[].class)))) })
    public Response getProfileMp( @PathParam("name") String name,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getProfileMp(name,securityContext);
    }
    @GET
    @Path("/api/properties/{uid}/{key}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "properties-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseCollectionString.class))) })
    public Response getPropertyForUid( @PathParam("uid") String uid, @PathParam("key") String key,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getPropertyForUid(uid,key,securityContext);
    }
    @GET
    @Path("/api/qos/conf")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "qo-s-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseQos.class))) })
    public Response getQosConf(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getQosConf(securityContext);
    }
    @GET
    @Path("/api/missions/{missionName}/token")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "mission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "201", description = "Created", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseString.class))) })
    public Response getReadOnlyAccessToken( @PathParam("missionName") String missionName,  @QueryParam("password") String password,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getReadOnlyAccessToken(missionName,password,securityContext);
    }
    @GET
    @Path("/api/certadmin/cert/replaced")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "cert-manager-admin-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseListTakCert.class))) })
    public Response getReplaced(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getReplaced(securityContext);
    }
    @GET
    @Path("/api/citrap/{id}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "ci-trap-report-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response getReport( @PathParam("id") String id, @NotNull  @QueryParam("clientUid") String clientUid,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getReport(id,clientUid,securityContext);
    }
    @GET
    @Path("/api/resources/{hash}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "mission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseListResource.class))) })
    public Response getResource( @PathParam("hash") String hash,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getResource(hash,securityContext);
    }
    @GET
    @Path("/api/retention/policy")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "retention-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseMapStringInteger.class))) })
    public Response getRetentionPolicy(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getRetentionPolicy(securityContext);
    }
    @GET
    @Path("/api/retention/service/schedule")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "retention-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseString.class))) })
    public Response getRetentionServiceSchedule(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getRetentionServiceSchedule(securityContext);
    }
    @GET
    @Path("/api/certadmin/cert/revoked")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "cert-manager-admin-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseListTakCert.class))) })
    public Response getRevoked(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getRevoked(securityContext);
    }
    @GET
    @Path("/api/cot/search/{id}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "cot-query-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseListCotSearch.class))) })
    public Response getSearch( @PathParam("id") String id,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getSearch(id,securityContext);
    }
    @GET
    @Path("/api/security/config")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "security-authentication-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseSecurityConfigInfo.class))) })
    public Response getSecConfig(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getSecConfig(securityContext);
    }
    @GET
    @Path("/api/missions/{missionName}/subscription")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "mission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseMissionSubscription.class))) })
    public Response getSubscriptionForUser( @PathParam("missionName") String missionName,  @QueryParam("uid") String uid,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getSubscriptionForUser(missionName,uid,securityContext);
    }
    @GET
    @Path("/api/excheck/template/{templateUid}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "ex-check-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response getTemplate( @PathParam("templateUid") String templateUid, @NotNull  @QueryParam("clientUid") String clientUid,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getTemplate(templateUid,clientUid,securityContext);
    }
    @GET
    @Path("/api/excheck/template/{templateUid}/task/{taskUid}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "ex-check-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response getTemplateTask( @PathParam("templateUid") String templateUid, @PathParam("taskUid") String taskUid, @NotNull  @QueryParam("clientUid") String clientUid,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getTemplateTask(templateUid,taskUid,clientUid,securityContext);
    }
    @GET
    @Path("/api/device/profile/tool/{toolName}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "profile-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", array = @ArraySchema(schema = @Schema(implementation = byte[].class)))) })
    public Response getToolProfiles( @PathParam("toolName") String toolName, @NotNull  @QueryParam("clientUid") String clientUid,  @DefaultValue("-1") @QueryParam("syncSecago") Long syncSecago,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getToolProfiles(toolName,clientUid,syncSecago,securityContext);
    }
    @GET
    @Path("/api/uidsearch")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "uid-search-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseListUIDResult.class))) })
    public Response getUIDResults( @NotNull  @QueryParam("startDate") String startDate, @NotNull  @QueryParam("endDate") String endDate,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getUIDResults(startDate,endDate,securityContext);
    }
    @GET
    @Path("/api/users/{connectionId}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "groups-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseUserGroups.class))) })
    public Response getUser( @PathParam("connectionId") String connectionId,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getUser(connectionId,securityContext);
    }
    @GET
    @Path("/api/util/user/roles")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "home-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", array = @ArraySchema(schema = @Schema(implementation = String.class)))) })
    public Response getUserRoles(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getUserRoles(securityContext);
    }
    @GET
    @Path("/api/device/profile/directories")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "profile-admin-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseListString.class))) })
    public Response getValidDirectories(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getValidDirectories(securityContext);
    }
    @GET
    @Path("/api/ver")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "home-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response getVer(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getVer(securityContext);
    }
    @GET
    @Path("/api/version")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "version-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response getVersion(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getVersion(securityContext);
    }
    @GET
    @Path("/api/version/config")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "version-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseServerConfig.class))) })
    public Response getVersionConfig(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getVersionConfig(securityContext);
    }
    @GET
    @Path("/api/version/info")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "version-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = VersionInfo.class))) })
    public Response getVersionInfo(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getVersionInfo(securityContext);
    }
    @GET
    @Path("/api/video")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "video-connection-manager-v-2" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = VideoCollections.class))) })
    public Response getVideoCollections(  @QueryParam("protocol") String protocol,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getVideoCollections(protocol,securityContext);
    }
    @GET
    @Path("/api/video/{uid}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "video-connection-manager-v-2" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = VideoConnection.class))) })
    public Response getVideoConnection( @PathParam("uid") String uid,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.getVideoConnection(uid,securityContext);
    }
    @GET
    @Path("/api/groups/update/{username}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "subscription-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response groupsUpdated( @PathParam("username") String username,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.groupsUpdated(username,securityContext);
    }
    @HEAD
    @Path("/api/device/profile/{name}/missionpackage")
    
    
    @Operation(summary = "", description = "", tags={ "profile-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK") })
    public Response headProfileMp( @PathParam("name") String name,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.headProfileMp(name,securityContext);
    }
    @PUT
    @Path("/api/missions/{name}/invite/{type}/{invitee}")
    
    
    @Operation(summary = "", description = "", tags={ "mission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK") })
    public Response inviteToMission( @PathParam("name") String name, @PathParam("type") String type, @PathParam("invitee") String invitee, @NotNull  @QueryParam("creatorUid") String creatorUid,  @QueryParam("role") String role,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.inviteToMission(name,type,invitee,creatorUid,role,securityContext);
    }
    @GET
    @Path("/api/util/isAdmin")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "home-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = Boolean.class))) })
    public Response isAdmin(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.isAdmin(securityContext);
    }
    @GET
    @Path("/api/security/isSecure")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "security-authentication-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseString.class))) })
    public Response isSecure(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.isSecure(securityContext);
    }
    @GET
    @Path("/api/inputs/storeForwardChat/enabled")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "submission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = Boolean.class))) })
    public Response isStoreForwardChatEnabled(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.isStoreForwardChatEnabled(securityContext);
    }
    @GET
    @Path("/api/tls/makeClientKeyStore")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "cert-manager-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", array = @ArraySchema(schema = @Schema(implementation = byte[].class)))) })
    public Response makeKeyStore(  @QueryParam("cn") String cn,  @DefaultValue("atakatak") @QueryParam("password") String password,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.makeKeyStore(cn,password,securityContext);
    }
    @PUT
    @Path("/api/authentication/config")
    @Consumes({ "application/json" })
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "security-authentication-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseString.class))) })
    public Response modifyAuthConfig(@Parameter(description = "" ,required=true) AuthenticationConfigInfo body,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.modifyAuthConfig(body,securityContext);
    }
    @PUT
    @Path("/api/inputs/config")
    @Consumes({ "application/json" })
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "submission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseString.class))) })
    public Response modifyConfigInfo(@Parameter(description = "" ,required=true) MessagingConfigInfo body,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.modifyConfigInfo(body,securityContext);
    }
    @PUT
    @Path("/api/datafeeds/{name}")
    @Consumes({ "application/json" })
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "submission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseDataFeed.class))) })
    public Response modifyDataFeed(@Parameter(description = "" ,required=true) DataFeed body, @PathParam("name") String name,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.modifyDataFeed(body,name,securityContext);
    }
    @PUT
    @Path("/api/federationconfig")
    @Consumes({ "application/json" })
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "federation-config-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseString.class))) })
    public Response modifyFederationConfig(@Parameter(description = "" ,required=true) FederationConfigInfo body,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.modifyFederationConfig(body,securityContext);
    }
    @PUT
    @Path("/api/inputs/{id}")
    @Consumes({ "application/json" })
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "submission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseConnectionModifyResult.class))) })
    public Response modifyInput(@Parameter(description = "" ,required=true) Input body, @PathParam("id") String id,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.modifyInput(body,id,securityContext);
    }
    @PUT
    @Path("/api/security/config")
    @Consumes({ "application/json" })
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "security-authentication-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseString.class))) })
    public Response modifySecConfig(@Parameter(description = "" ,required=true) SecurityConfigInfo body,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.modifySecConfig(body,securityContext);
    }
    @POST
    @Path("/api/caveat/{name}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "classification-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseCaveat.class))) })
    public Response newCaveat( @PathParam("name") String name,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.newCaveat(name,securityContext);
    }
    @POST
    @Path("/api/classification/{level}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "classification-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseClassification.class))) })
    public Response newClassification( @PathParam("level") String level,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.newClassification(level,securityContext);
    }
    @POST
    @Path("/api/missions/{name}/externaldata/{id}/change")
    @Consumes({ "application/json" })
    
    @Operation(summary = "", description = "", tags={ "mission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK") })
    public Response notifyExternalDataChanged(@Parameter(description = "" ,required=true) String body, @NotNull  @QueryParam("creatorUid") String creatorUid, @NotNull  @QueryParam("notes") String notes, @PathParam("name") String name, @PathParam("id") String id,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.notifyExternalDataChanged(body,creatorUid,notes,name,id,securityContext);
    }
    @POST
    @Path("/api/iconset")
    @Consumes({ "application/json" })
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "iconset-icon-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseString.class))) })
    public Response postIconsetZip(@Parameter(description = "" ) ApiIconsetBody body,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.postIconsetZip(body,securityContext);
    }
    @POST
    @Path("/api/missions/logs/entries")
    @Consumes({ "application/json" })
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "mission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "201", description = "Created", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseLogEntry.class))) })
    public Response postLogEntry(@Parameter(description = "" ,required=true) LogEntry body,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.postLogEntry(body,securityContext);
    }
    @POST
    @Path("/api/citrap")
    @Consumes({ "application/json" })
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "ci-trap-report-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response postReport(@Parameter(description = "" ,required=true) ApiCitrapBody body, @NotNull  @QueryParam("clientUid") String clientUid,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.postReport(body,clientUid,securityContext);
    }
    @POST
    @Path("/api/excheck/template")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "ex-check-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response postTemplate( @NotNull  @QueryParam("clientUid") String clientUid,  @QueryParam("callsign") String callsign,  @QueryParam("name") String name,  @QueryParam("description") String description,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.postTemplate(clientUid,callsign,name,description,securityContext);
    }
    @POST
    @Path("/api/injectors/cot/uid")
    @Consumes({ "application/json" })
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "injection-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseSetInjectorConfig.class))) })
    public Response putCotInjector(@Parameter(description = "" ,required=true) InjectorConfig body,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.putCotInjector(body,securityContext);
    }
    @PUT
    @Path("/api/xmpp/transfer/{uid}/{filename}")
    @Consumes({ "application/json" })
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "xmpp-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response putFile(@Parameter(description = "" ,required=true) UidFilenameBody body, @PathParam("uid") String uid, @PathParam("filename") String filename,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.putFile(body,uid,filename,securityContext);
    }
    @PUT
    @Path("/api/citrap/{id}")
    @Consumes({ "application/json" })
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "ci-trap-report-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response putReport(@Parameter(description = "" ,required=true) CitrapIdBody body, @NotNull  @QueryParam("clientUid") String clientUid, @PathParam("id") String id,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.putReport(body,clientUid,id,securityContext);
    }
    @GET
    @Path("/api/repeater/remove/{uid}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "repeater-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseBoolean.class))) })
    public Response remove( @PathParam("uid") String uid,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.remove(uid,securityContext);
    }
    @DELETE
    @Path("/api/federatecagroups/{caId}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "federation-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseString.class))) })
    public Response removeFederateCAGroup( @PathParam("caId") String caId, @NotNull  @QueryParam("group") String group, @NotNull  @QueryParam("direction") String direction,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.removeFederateCAGroup(caId,group,direction,securityContext);
    }
    @DELETE
    @Path("/api/federategroups/{federateId}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "federation-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseString.class))) })
    public Response removeFederateGroup( @PathParam("federateId") String federateId, @NotNull  @QueryParam("group") String group, @NotNull  @QueryParam("direction") String direction,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.removeFederateGroup(federateId,group,direction,securityContext);
    }
    @DELETE
    @Path("/api/federategroupsmap/{federateId}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "federation-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseString.class))) })
    public Response removeFederateGroupMap( @PathParam("federateId") String federateId, @NotNull  @QueryParam("remoteGroup") String remoteGroup, @NotNull  @QueryParam("localGroup") String localGroup,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.removeFederateGroupMap(federateId,remoteGroup,localGroup,securityContext);
    }
    @DELETE
    @Path("/api/missions/{missionName}/feed/{uid}")
    
    
    @Operation(summary = "", description = "", tags={ "mission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK") })
    public Response removeFeed( @PathParam("missionName") String missionName, @PathParam("uid") String uid, @NotNull  @QueryParam("creatorUid") String creatorUid,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.removeFeed(missionName,uid,creatorUid,securityContext);
    }
    @DELETE
    @Path("/api/missions/{name}/keywords/{keyword}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "mission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseSetMission.class))) })
    public Response removeKeyword( @PathParam("name") String name, @PathParam("keyword") String keyword,  @QueryParam("creatorUid") String creatorUid,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.removeKeyword(name,keyword,creatorUid,securityContext);
    }
    @DELETE
    @Path("/api/missions/{name}/contents")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "mission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseSetMission.class))) })
    public Response removeMissionContent( @PathParam("name") String name,  @QueryParam("hash") String hash,  @QueryParam("uid") String uid,  @QueryParam("creatorUid") String creatorUid,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.removeMissionContent(name,hash,uid,creatorUid,securityContext);
    }
    @DELETE
    @Path("/api/excheck/checklist/{checklistUid}/mission/{missionName}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "ex-check-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response removeMissionReferenceFromChecklist( @PathParam("checklistUid") String checklistUid, @PathParam("missionName") String missionName, @NotNull  @QueryParam("clientUid") String clientUid,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.removeMissionReferenceFromChecklist(checklistUid,missionName,clientUid,securityContext);
    }
    @DELETE
    @Path("/api/missions/{name}/password")
    
    
    @Operation(summary = "", description = "", tags={ "mission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK") })
    public Response removePassword( @PathParam("name") String name,  @QueryParam("creatorUid") String creatorUid,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.removePassword(name,creatorUid,securityContext);
    }
    @GET
    @Path("/api/plugins/{name}/submit")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "plugin-data-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response requestFromPlugin( @PathParam("name") String name, @NotNull  @QueryParam("allRequestParams") Map<String, String> allRequestParams,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.requestFromPlugin(name,allRequestParams,securityContext);
    }
    @POST
    @Path("/api/retention/restoremission")
    @Consumes({ "application/json" })
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "retention-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseString.class))) })
    public Response restoreMissionFromArchive(@Parameter(description = "" ,required=true) Integer body,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.restoreMissionFromArchive(body,securityContext);
    }
    @GET
    @Path("/api/missions/{name}/contacts")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "mission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", array = @ArraySchema(schema = @Schema(implementation = RemoteSubscription.class)))) })
    public Response results( @PathParam("name") String name,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.results(name,securityContext);
    }
    @DELETE
    @Path("/api/certadmin/cert/{hash}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "cert-manager-admin-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseTakCert.class))) })
    public Response revokeCertificate( @PathParam("hash") String hash,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.revokeCertificate(hash,securityContext);
    }
    @DELETE
    @Path("/api/certadmin/cert/revoke/{ids}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "cert-manager-admin-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response revokeCertificates( @PathParam("ids") String ids,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.revokeCertificates(ids,securityContext);
    }
    @DELETE
    @Path("/api/token/{token}")
    
    
    @Operation(summary = "", description = "", tags={ "token-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK") })
    public Response revokeToken( @PathParam("token") String token,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.revokeToken(token,securityContext);
    }
    @DELETE
    @Path("/api/token/revoke/{tokens}")
    
    
    @Operation(summary = "", description = "", tags={ "token-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK") })
    public Response revokeTokens( @PathParam("tokens") String tokens,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.revokeTokens(tokens,securityContext);
    }
    @POST
    @Path("/api/federatecertificates")
    @Consumes({ "application/json" })
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "federation-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseString.class))) })
    public Response saveFederateCertificateCA(@Parameter(description = "" ) ApiFederatecertificatesBody body,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.saveFederateCertificateCA(body,securityContext);
    }
    @POST
    @Path("/api/federategroupconfig")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "federation-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseString.class))) })
    public Response saveFederateGroupConfiguration(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.saveFederateGroupConfiguration(securityContext);
    }
    @PUT
    @Path("/api/retention/mission/{name}/expiry/{time}")
    
    
    @Operation(summary = "", description = "", tags={ "retention-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK") })
    public Response scheduleMissionExpiration( @PathParam("name") String name, @PathParam("time") Long time,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.scheduleMissionExpiration(name,time,securityContext);
    }
    @PUT
    @Path("/api/retention/resource/{name}/expiry/{time}")
    
    
    @Operation(summary = "", description = "", tags={ "retention-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK") })
    public Response scheduleResourceExpiration( @PathParam("name") String name, @PathParam("time") Long time,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.scheduleResourceExpiration(name,time,securityContext);
    }
    @GET
    @Path("/api/citrap")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "ci-trap-report-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response searchReports(  @QueryParam("keywords") String keywords,  @QueryParam("bbox") String bbox,  @QueryParam("startTime") String startTime,  @QueryParam("endTime") String endTime,  @QueryParam("maxReportCount") String maxReportCount,  @QueryParam("type") String type,  @QueryParam("callsign") String callsign,  @QueryParam("subscribe") String subscribe,  @QueryParam("clientUid") String clientUid,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.searchReports(keywords,bbox,startTime,endTime,maxReportCount,type,callsign,subscribe,clientUid,securityContext);
    }
    @GET
    @Path("/api/sync/search")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "mission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseNavigableSetResource.class))) })
    public Response searchSync(  @QueryParam("box") String box,  @QueryParam("circle") String circle,  @QueryParam("startTime") Date startTime,  @QueryParam("endTime") Date endTime,  @QueryParam("minAltitude") Double minAltitude,  @QueryParam("maxAltitude") Double maxAltitude,  @QueryParam("filename") String filename,  @QueryParam("keyword") List<String> keyword,  @QueryParam("mimetype") String mimetype,  @QueryParam("name") String name,  @QueryParam("uid") String uid,  @QueryParam("hash") String hash,  @QueryParam("mission") String mission,  @QueryParam("tool") String tool,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.searchSync(box,circle,startTime,endTime,minAltitude,maxAltitude,filename,keyword,mimetype,name,uid,hash,mission,tool,securityContext);
    }
    @POST
    @Path("/api/missions/{name}/send")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "mission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseSetMission.class))) })
    public Response sendMissionArchive( @PathParam("name") String name,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.sendMissionArchive(name,securityContext);
    }
    @POST
    @Path("/api/missions/{name}/invite")
    
    
    @Operation(summary = "", description = "", tags={ "mission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK") })
    public Response sendMissionInvites( @PathParam("name") String name,  @QueryParam("creatorUid") String creatorUid,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.sendMissionInvites(name,creatorUid,securityContext);
    }
    @POST
    @Path("/api/device/profile/{name}/send")
    @Consumes({ "application/json" })
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "profile-admin-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response sendProfile(@Parameter(description = "" ,required=true) List<String> body, @PathParam("name") String name,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.sendProfile(body,name,securityContext);
    }
    @PUT
    @Path("/api/groups/activebits")
    @Consumes({ "application/json" })
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "subscription-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response setActiveGroups(@Parameter(description = "" ,required=true) List<Integer> body,  @QueryParam("clientUid") String clientUid,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.setActiveGroups(body,clientUid,securityContext);
    }
    @PUT
    @Path("/api/groups/active")
    @Consumes({ "application/json" })
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "subscription-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response setActiveGroups1(@Parameter(description = "" ,required=true) List<Group> body,  @QueryParam("clientUid") String clientUid,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.setActiveGroups1(body,clientUid,securityContext);
    }
    @PUT
    @Path("/api/classification")
    @Consumes({ "application/json" })
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "classification-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseClassification.class))) })
    public Response setCaveatsForClassification(@Parameter(description = "" ,required=true) Classification body,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.setCaveatsForClassification(body,securityContext);
    }
    @PUT
    @Path("/api/sync/metadata/{hash}/expiration")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "metadata-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response setExpiration( @PathParam("hash") String hash, @NotNull  @QueryParam("expiration") Long expiration,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.setExpiration(hash,expiration,securityContext);
    }
    @PUT
    @Path("/api/missions/{name}/expiration")
    
    
    @Operation(summary = "", description = "", tags={ "mission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK") })
    public Response setExpiration1( @PathParam("name") String name,  @QueryParam("expiration") Long expiration,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.setExpiration1(name,expiration,securityContext);
    }
    @POST
    @Path("/api/missions/{name}/externaldata")
    @Consumes({ "application/json" })
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "mission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "201", description = "Created", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseExternalMissionData.class))) })
    public Response setExternalMissionData(@Parameter(description = "" ,required=true) ExternalMissionData body, @NotNull  @QueryParam("creatorUid") String creatorUid, @PathParam("name") String name,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.setExternalMissionData(body,creatorUid,name,securityContext);
    }
    @PUT
    @Path("/api/subscriptions/{clientUid}/filter")
    @Consumes({ "application/xml" })
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "subscription-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response setFilter(@Parameter(description = "" ,required=true) Filter body, @PathParam("clientUid") String clientUid,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.setFilter(body,clientUid,securityContext);
    }
    @PUT
    @Path("/api/missions/{name}/keywords")
    @Consumes({ "application/json" })
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "mission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseSetMission.class))) })
    public Response setKeywords(@Parameter(description = "" ,required=true) List<String> body, @PathParam("name") String name,  @QueryParam("creatorUid") String creatorUid,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.setKeywords(body,name,creatorUid,securityContext);
    }
    @PUT
    @Path("/api/sync/metadata/{hash}/{metadata}")
    @Consumes({ "application/json" })
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "metadata-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response setMetadata(@Parameter(description = "" ,required=true) String body, @PathParam("hash") String hash, @PathParam("metadata") String metadata,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.setMetadata(body,hash,metadata,securityContext);
    }
    @PUT
    @Path("/api/sync/metadata/{hash}/keywords")
    @Consumes({ "application/json" })
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "metadata-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response setMetadataKeywords(@Parameter(description = "" ,required=true) List<String> body, @PathParam("hash") String hash,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.setMetadataKeywords(body,hash,securityContext);
    }
    @PUT
    @Path("/api/missions/{missionName}/role")
    
    
    @Operation(summary = "", description = "", tags={ "mission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK") })
    public Response setMissionRole( @PathParam("missionName") String missionName,  @QueryParam("clientUid") String clientUid,  @QueryParam("username") String username,  @QueryParam("role") String role,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.setMissionRole(missionName,clientUid,username,role,securityContext);
    }
    @PUT
    @Path("/api/missions/{childName}/parent/{parentName}")
    
    
    @Operation(summary = "", description = "", tags={ "mission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK") })
    public Response setParent( @PathParam("childName") String childName, @PathParam("parentName") String parentName,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.setParent(childName,parentName,securityContext);
    }
    @PUT
    @Path("/api/missions/{name}/password")
    
    
    @Operation(summary = "", description = "", tags={ "mission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK") })
    public Response setPassword( @PathParam("name") String name,  @QueryParam("password") String password,  @QueryParam("creatorUid") String creatorUid,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.setPassword(name,password,creatorUid,securityContext);
    }
    @POST
    @Path("/api/repeater/period")
    @Consumes({ "application/json" })
    
    @Operation(summary = "", description = "", tags={ "repeater-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK") })
    public Response setPeriod(@Parameter(description = "" ,required=true) Integer body,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.setPeriod(body,securityContext);
    }
    @PUT
    @Path("/api/retention/service/schedule")
    @Consumes({ "application/json" })
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "retention-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseString.class))) })
    public Response setRetentionServiceSchedule(@Parameter(description = "" ,required=true) String body,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.setRetentionServiceSchedule(body,securityContext);
    }
    @POST
    @Path("/api/missions/{missionName}/subscription")
    @Consumes({ "application/json" })
    
    @Operation(summary = "", description = "", tags={ "mission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK") })
    public Response setSubscriptionRole(@Parameter(description = "" ,required=true) List<MissionSubscription> body, @NotNull  @QueryParam("creatorUid") String creatorUid, @PathParam("missionName") String missionName,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.setSubscriptionRole(body,creatorUid,missionName,securityContext);
    }
    @POST
    @Path("/api/tls/signClient")
    @Consumes({ "application/json" })
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "cert-manager-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", array = @ArraySchema(schema = @Schema(implementation = byte[].class)))) })
    public Response signClientCert(@Parameter(description = "" ,required=true) String body,  @QueryParam("clientUid") String clientUid,  @QueryParam("version") String version,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.signClientCert(body,clientUid,version,securityContext);
    }
    @POST
    @Path("/api/tls/signClient/v2")
    @Consumes({ "application/json" })
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "cert-manager-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response signClientCertV2(@Parameter(description = "" ,required=true) String body,  @QueryParam("clientUid") String clientUid,  @QueryParam("version") String version,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.signClientCertV2(body,clientUid,version,securityContext);
    }
    @POST
    @Path("/api/excheck/{templateUid}/start")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "ex-check-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response startChecklist( @PathParam("templateUid") String templateUid, @NotNull  @QueryParam("clientUid") String clientUid, @NotNull  @QueryParam("callsign") String callsign, @NotNull  @QueryParam("name") String name, @NotNull  @QueryParam("description") String description, @NotNull  @QueryParam("startTime") String startTime,  @QueryParam("defaultRole") String defaultRole,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.startChecklist(templateUid,clientUid,callsign,name,description,startTime,defaultRole,securityContext);
    }
    @POST
    @Path("/api/excheck/{checklistUid}/stop")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "ex-check-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response stopChecklist( @PathParam("checklistUid") String checklistUid, @NotNull  @QueryParam("clientUid") String clientUid,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.stopChecklist(checklistUid,clientUid,securityContext);
    }
    @PUT
    @Path("/api/properties/{uid}")
    @Consumes({ "application/json" })
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "properties-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseEntryStringString.class))) })
    public Response storeProperty(@Parameter(description = "" ,required=true) PropertiesUidBody body, @PathParam("uid") String uid,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.storeProperty(body,uid,securityContext);
    }
    @PUT
    @Path("/api/plugins/{name}/submit")
    @Consumes({ "application/json" })
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "plugin-data-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseString.class))) })
    public Response submitToPluginUTF8(@Parameter(description = "" ,required=true) NameSubmitBody body, @NotNull  @QueryParam("allRequestParams") Map<String, String> allRequestParams, @PathParam("name") String name,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.submitToPluginUTF8(body,allRequestParams,name,securityContext);
    }
    @PUT
    @Path("/api/plugins/{name}/submit/result")
    @Consumes({ "application/json" })
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "plugin-data-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response submitToPluginUTF8WithResult(@Parameter(description = "" ,required=true) SubmitResultBody body, @NotNull  @QueryParam("allRequestParams") Map<String, String> allRequestParams, @PathParam("name") String name,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.submitToPluginUTF8WithResult(body,allRequestParams,name,securityContext);
    }
    @POST
    @Path("/api/authentication/config")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "security-authentication-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseString.class))) })
    public Response testAuthConfig(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.testAuthConfig(securityContext);
    }
    @GET
    @Path("/api/tls/profile/tool/{toolName}/file")
    
    
    @Operation(summary = "", description = "", tags={ "profile-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK") })
    public Response tlsGetProfileDirectoryContent( @PathParam("toolName") String toolName, @NotNull  @QueryParam("relativePath") List<String> relativePath, @NotNull  @QueryParam("clientUid") String clientUid,  @DefaultValue("-1") @QueryParam("syncSecago") Long syncSecago,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.tlsGetProfileDirectoryContent(toolName,relativePath,clientUid,syncSecago,securityContext);
    }
    @POST
    @Path("/api/subscriptions/incognito/{uid}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "subscription-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response toggleIncognito( @PathParam("uid") String uid,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.toggleIncognito(uid,securityContext);
    }
    @DELETE
    @Path("/api/missions/{name}/invite/{type}/{invitee}")
    
    
    @Operation(summary = "", description = "", tags={ "mission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK") })
    public Response uninviteFromMission( @PathParam("name") String name, @PathParam("type") String type, @PathParam("invitee") String invitee, @NotNull  @QueryParam("creatorUid") String creatorUid,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.uninviteFromMission(name,type,invitee,creatorUid,securityContext);
    }
    @PUT
    @Path("/api/device/profile/{name}/directories/{directories}")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "profile-admin-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response updateDirectories( @PathParam("name") String name, @PathParam("directories") List<String> directories,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.updateDirectories(name,directories,securityContext);
    }
    @PUT
    @Path("/api/federatedetails")
    @Consumes({ "application/json" })
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "federation-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseFederate.class))) })
    public Response updateFederateDetails(@Parameter(description = "" ,required=true) Federate body,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.updateFederateDetails(body,securityContext);
    }
    @PUT
    @Path("/api/federatemissions/{federateId}")
    @Consumes({ "application/json" })
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "federation-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseFederateMissionPerConnectionSettings.class))) })
    public Response updateFederateMissions(@Parameter(description = "" ,required=true) FederateMissionPerConnectionSettings body, @PathParam("federateId") String federateId,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.updateFederateMissions(body,federateId,securityContext);
    }
    @POST
    @Path("/api/plugins/{name}/submit")
    @Consumes({ "application/json" })
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "plugin-data-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseString.class))) })
    public Response updateInPlugin(@Parameter(description = "" ,required=true) NameSubmitBody1 body, @NotNull  @QueryParam("allRequestParams") Map<String, String> allRequestParams, @PathParam("name") String name,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.updateInPlugin(body,allRequestParams,name,securityContext);
    }
    @PUT
    @Path("/api/missions/logs/entries")
    @Consumes({ "application/json" })
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "mission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "201", description = "Created", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseLogEntry.class))) })
    public Response updateLogEntry(@Parameter(description = "" ,required=true) LogEntry body,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.updateLogEntry(body,securityContext);
    }
    @PUT
    @Path("/api/missions/{missionName}/maplayers")
    @Consumes({ "application/json" })
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "mission-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseMapLayer.class))) })
    public Response updateMapLayer(@Parameter(description = "" ,required=true) MapLayer body, @NotNull  @QueryParam("creatorUid") String creatorUid, @PathParam("missionName") String missionName,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.updateMapLayer(body,creatorUid,missionName,securityContext);
    }
    @PUT
    @Path("/api/maplayers")
    @Consumes({ "application/json" })
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "map-layers-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseMapLayer.class))) })
    public Response updateMapLayer1(@Parameter(description = "" ,required=true) MapLayer body,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.updateMapLayer1(body,securityContext);
    }
    @PUT
    @Path("/api/retention/missionarchiveconfig")
    @Consumes({ "application/json" })
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "retention-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseMissionArchiveConfig.class))) })
    public Response updateMissionArchiveConfig(@Parameter(description = "" ,required=true) MissionArchiveConfig body,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.updateMissionArchiveConfig(body,securityContext);
    }
    @PUT
    @Path("/api/device/profile/{name}")
    @Consumes({ "application/json" })
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "profile-admin-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = String.class))) })
    public Response updateProfile(@Parameter(description = "" ,required=true) Profile body, @PathParam("name") String name,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.updateProfile(body,name,securityContext);
    }
    @PUT
    @Path("/api/retention/policy")
    @Consumes({ "application/json" })
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "retention-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseMapStringInteger.class))) })
    public Response updateRetentionPolicy(@Parameter(description = "" ,required=true) Map<String, Integer> body,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.updateRetentionPolicy(body,securityContext);
    }
    @PUT
    @Path("/api/video/{uid}")
    @Consumes({ "application/json" })
    
    @Operation(summary = "", description = "", tags={ "video-connection-manager-v-2" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK") })
    public Response updateVideoConnection(@Parameter(description = "" ,required=true) VideoConnection body, @PathParam("uid") String uid,@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.updateVideoConnection(body,uid,securityContext);
    }
    @GET
    @Path("/api/security/verifyConfig")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "security-authentication-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseString.class))) })
    public Response verifyConfig(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.verifyConfig(securityContext);
    }
    @GET
    @Path("/api/federationconfig/verify")
    
    @Produces({ "*/*" })
    @Operation(summary = "", description = "", tags={ "federation-config-api" })
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "OK", content = @Content(mediaType = "*/*", schema = @Schema(implementation = ApiResponseBoolean.class))) })
    public Response verifyFederationTruststore(@Context SecurityContext securityContext)
    throws NotFoundException {
        return service.verifyFederationTruststore(securityContext);
    }
}
